/*
MODA ESTILO | DATOS SINTETICOS PARA SQL SERVER Y POWER BI
Script de demostración AUTOCONTENIDO: ventas y alquileres de vestimenta formal.
Años transaccionales: 2024-2026 (no hay operaciones futuras posteriores al 15/10/2026).
Horarios comerciales: todas las marcas de tiempo entre 08:00 y 18:00.
IMPORTANTE: Ejecutar únicamente en una instancia de pruebas.
Al volver a ejecutar, este archivo borra/recrea solamente las tablas del
esquema dbo y bi dentro de la base dedicada ModaEstilo_BI_Demo.
NO modifica la base original ModaEstilo_Final.
Datos inventados. Precios y montos en soles peruanos (PEN).
Total de alquiler = suma de detalles SIN penalidades.
Penalidades se cobran por separado (tipoOperacion = 'PENALIDAD').
*/
IF DB_ID(N'ModaEstilo_BI_Demo') IS NULL
    CREATE DATABASE ModaEstilo_BI_Demo;
GO
USE ModaEstilo_BI_Demo;
GO
IF SCHEMA_ID(N'bi') IS NULL EXEC(N'CREATE SCHEMA bi');
GO
-- Eliminar vistas primero para poder reiniciar esta BASE DEMO solamente.
DROP VIEW IF EXISTS bi.FactCobranza;
DROP VIEW IF EXISTS bi.FactPago;
DROP VIEW IF EXISTS bi.FactGasto;
DROP VIEW IF EXISTS bi.FactPenalidad;
DROP VIEW IF EXISTS bi.FactAlquiler;
DROP VIEW IF EXISTS bi.FactVenta;
DROP VIEW IF EXISTS bi.DimArticulo;
DROP VIEW IF EXISTS bi.DimCliente;
DROP VIEW IF EXISTS bi.DimTrabajador;
DROP VIEW IF EXISTS bi.DimCategoria;
DROP VIEW IF EXISTS bi.DimCalendario;
GO
DROP TABLE IF EXISTS dbo.Pago;
DROP TABLE IF EXISTS dbo.Gasto;
DROP TABLE IF EXISTS dbo.Penalidad;
DROP TABLE IF EXISTS dbo.Devolucion;
DROP TABLE IF EXISTS dbo.DetalleAlquiler;
DROP TABLE IF EXISTS dbo.DetalleVenta;
DROP TABLE IF EXISTS dbo.Alquiler;
DROP TABLE IF EXISTS dbo.Venta;
DROP TABLE IF EXISTS dbo.Articulo;
DROP TABLE IF EXISTS dbo.Cliente;
DROP TABLE IF EXISTS dbo.Trabajador;
DROP TABLE IF EXISTS dbo.Categoria;
DROP TABLE IF EXISTS dbo.DimFecha;
GO
SET DATEFORMAT ymd;
GO


CREATE TABLE dbo.Categoria (
 idCategoria INT IDENTITY(1,1) PRIMARY KEY,
 nombreCategoria NVARCHAR(100) NOT NULL UNIQUE,
 descripcion NVARCHAR(250)
);
CREATE TABLE dbo.Trabajador (
 idTrabajador INT IDENTITY(1,1) PRIMARY KEY,
 dni CHAR(8) NOT NULL UNIQUE, nombres NVARCHAR(80) NOT NULL,
 apellidos NVARCHAR(100) NOT NULL, cargo NVARCHAR(60) NOT NULL,
 estado NVARCHAR(20) NOT NULL
);
CREATE TABLE dbo.Cliente (
 idCliente INT IDENTITY(1,1) PRIMARY KEY,
 dni CHAR(8) NOT NULL UNIQUE, nombres NVARCHAR(80) NOT NULL,
 apellidos NVARCHAR(100) NOT NULL, telefono VARCHAR(20),
 correo VARCHAR(100), direccion NVARCHAR(200),distrito NVARCHAR(50),
 fechaRegistro DATETIME2(0) NOT NULL
);
CREATE TABLE dbo.Articulo (
 idArticulo INT IDENTITY(1,1) PRIMARY KEY,
 idCategoria INT NOT NULL REFERENCES dbo.Categoria(idCategoria),
 codigo VARCHAR(30) NOT NULL UNIQUE, nombre NVARCHAR(100) NOT NULL,
 talla NVARCHAR(20), color NVARCHAR(50),
 costoCompra DECIMAL(12,2) NOT NULL CHECK(costoCompra>=0),
 precioAlquiler DECIMAL(12,2) NOT NULL CHECK(precioAlquiler>=0),
 precioVenta DECIMAL(12,2) NOT NULL CHECK(precioVenta>=0),
 stock INT NOT NULL CHECK(stock>=0), stockMinimo INT NOT NULL CHECK(stockMinimo>=0),
 estado NVARCHAR(20) NOT NULL
);
CREATE TABLE dbo.Venta (
 idVenta INT IDENTITY(1,1) PRIMARY KEY,
 idCliente INT NOT NULL REFERENCES dbo.Cliente(idCliente),
 idTrabajador INT NOT NULL REFERENCES dbo.Trabajador(idTrabajador),
 fechaVenta DATETIME2(0) NOT NULL,
 tipoComprobante NVARCHAR(30) NOT NULL,canalVenta NVARCHAR(30) NOT NULL,
 estado NVARCHAR(20) NOT NULL,
 total DECIMAL(12,2) NOT NULL CHECK(total>=0)
);
CREATE TABLE dbo.Alquiler (
 idAlquiler INT IDENTITY(1,1) PRIMARY KEY,
 idCliente INT NOT NULL REFERENCES dbo.Cliente(idCliente),
 idTrabajador INT NOT NULL REFERENCES dbo.Trabajador(idTrabajador),
 fechaAlquiler DATETIME2(0) NOT NULL,
 fechaEntrega DATETIME2(0),
 fechaDevolucionProgramada DATETIME2(0) NOT NULL,
 fechaDevolucionReal DATETIME2(0),
 tipoEvento NVARCHAR(50) NOT NULL,canalReserva NVARCHAR(30) NOT NULL,
 estado NVARCHAR(20) NOT NULL,
 observacion NVARCHAR(250), total DECIMAL(12,2) NOT NULL CHECK(total>=0),
 CONSTRAINT CK_Alquiler_FechaLogica CHECK (
   fechaDevolucionProgramada>=fechaAlquiler
   AND (fechaEntrega IS NULL OR fechaEntrega>=fechaAlquiler)
   AND (fechaEntrega IS NULL OR fechaDevolucionProgramada>=fechaEntrega)
   AND (fechaDevolucionReal IS NULL OR (fechaEntrega IS NOT NULL AND fechaDevolucionReal>=fechaEntrega))
 )
);
CREATE TABLE dbo.DetalleVenta (
 idDetalleVenta INT IDENTITY(1,1) PRIMARY KEY,
 idVenta INT NOT NULL REFERENCES dbo.Venta(idVenta),
 idArticulo INT NOT NULL REFERENCES dbo.Articulo(idArticulo),
 cantidad INT NOT NULL CHECK(cantidad>0),
 precioUnitario DECIMAL(12,2) NOT NULL CHECK(precioUnitario>=0),
 costoUnitario DECIMAL(12,2) NOT NULL CHECK(costoUnitario>=0),
 subtotal DECIMAL(12,2) NOT NULL CHECK(subtotal>=0),
 CONSTRAINT UQ_DetalleVenta_Producto UNIQUE(idVenta,idArticulo),
 CONSTRAINT CK_DetalleVenta_Subtotal CHECK(subtotal=cantidad*precioUnitario)
);
CREATE TABLE dbo.DetalleAlquiler (
 idDetalleAlquiler INT IDENTITY(1,1) PRIMARY KEY,
 idAlquiler INT NOT NULL REFERENCES dbo.Alquiler(idAlquiler),
 idArticulo INT NOT NULL REFERENCES dbo.Articulo(idArticulo),
 cantidad INT NOT NULL CHECK(cantidad>0),
 precioUnitario DECIMAL(12,2) NOT NULL CHECK(precioUnitario>=0),
 subtotal DECIMAL(12,2) NOT NULL CHECK(subtotal>=0),
 CONSTRAINT UQ_DetalleAlquiler_Producto UNIQUE(idAlquiler,idArticulo),
 CONSTRAINT CK_DetalleAlquiler_Subtotal CHECK(subtotal=cantidad*precioUnitario)
);
CREATE TABLE dbo.Devolucion (
 idDevolucion INT IDENTITY(1,1) PRIMARY KEY,
 idAlquiler INT NOT NULL UNIQUE REFERENCES dbo.Alquiler(idAlquiler),
 fechaDevolucion DATETIME2(0) NOT NULL,
 estadoArticulo NVARCHAR(40) NOT NULL,
 observaciones NVARCHAR(250)
);
CREATE TABLE dbo.Penalidad (
 idPenalidad INT IDENTITY(1,1) PRIMARY KEY,
 idDevolucion INT NOT NULL REFERENCES dbo.Devolucion(idDevolucion),
 idArticulo INT NULL REFERENCES dbo.Articulo(idArticulo),
 tipoPenalidad NVARCHAR(40) NOT NULL,
 descripcion NVARCHAR(250) NOT NULL,
 diasRetraso INT NOT NULL DEFAULT(0) CHECK(diasRetraso>=0),
 monto DECIMAL(12,2) NOT NULL CHECK(monto>0),
 fechaRegistro DATETIME2(0) NOT NULL,
 estadoPenalidad NVARCHAR(20) NOT NULL,
 CONSTRAINT CK_Penalidad_Tipo CHECK (tipoPenalidad IN (N'Mora',N'Limpieza',N'Reparación',N'Reposición')),
 CONSTRAINT CK_Penalidad_Mora CHECK((tipoPenalidad=N'Mora' AND diasRetraso>0 AND idArticulo IS NULL) OR (tipoPenalidad<>N'Mora' AND diasRetraso=0 AND idArticulo IS NOT NULL))
);
CREATE TABLE dbo.Gasto (
 idGasto INT IDENTITY(1,1) PRIMARY KEY,
 fechaGasto DATETIME2(0) NOT NULL, tipoGasto NVARCHAR(50) NOT NULL,
 descripcion NVARCHAR(250) NOT NULL,
 monto DECIMAL(12,2) NOT NULL CHECK(monto>0),
 idVenta INT NULL REFERENCES dbo.Venta(idVenta),
 idAlquiler INT NULL REFERENCES dbo.Alquiler(idAlquiler),
 CONSTRAINT CK_Gasto_UnaRelacion CHECK(idVenta IS NULL OR idAlquiler IS NULL)
);
CREATE TABLE dbo.Pago (
 idPago INT IDENTITY(1,1) PRIMARY KEY,
 tipoOperacion NVARCHAR(20) NOT NULL,
 idVenta INT NULL REFERENCES dbo.Venta(idVenta),
 idAlquiler INT NULL REFERENCES dbo.Alquiler(idAlquiler),
 idPenalidad INT NULL REFERENCES dbo.Penalidad(idPenalidad),
 fechaPago DATETIME2(0) NOT NULL,
 metodoPago NVARCHAR(30) NOT NULL,
 monto DECIMAL(12,2) NOT NULL CHECK(monto>0),
 estadoPago NVARCHAR(20) NOT NULL,
 CONSTRAINT CK_Pago_Origen CHECK (
  (tipoOperacion=N'VENTA' AND idVenta IS NOT NULL AND idAlquiler IS NULL AND idPenalidad IS NULL)
  OR (tipoOperacion=N'ALQUILER' AND idVenta IS NULL AND idAlquiler IS NOT NULL AND idPenalidad IS NULL)
  OR (tipoOperacion=N'PENALIDAD' AND idVenta IS NULL AND idAlquiler IS NULL AND idPenalidad IS NOT NULL)
 )
);
CREATE TABLE dbo.DimFecha (
 FechaKey INT NOT NULL PRIMARY KEY,
 Fecha DATE NOT NULL UNIQUE, Anio INT NOT NULL, Trimestre INT NOT NULL,
 MesNumero INT NOT NULL, MesNombre NVARCHAR(20) NOT NULL,
 AnioMes CHAR(7) NOT NULL, DiaMes INT NOT NULL,
 DiaSemanaNumero INT NOT NULL, DiaSemanaNombre NVARCHAR(15) NOT NULL,
 EsFinSemana BIT NOT NULL
);
GO

INSERT INTO dbo.Categoria (nombreCategoria, descripcion) VALUES
    (N'Ternos', N'Ternos formales, clásicos y de ceremonia'),
    (N'Vestidos', N'Vestidos de gala, coctel y ceremonia'),
    (N'Camisas', N'Camisas de vestir y para eventos'),
    (N'Blazers y sacos', N'Sacos, blazers y chaquetas de vestir'),
    (N'Pantalones', N'Pantalones de vestir'),
    (N'Accesorios', N'Corbatas, pajaritas, cinturones y complementos'),
    (N'Calzado', N'Zapatos y tacones para ocasiones especiales'),
    (N'Trajes infantiles', N'Ropa formal para niñas y niños'),
    (N'Conjuntos femeninos', N'Conjuntos de dos piezas para eventos');
GO

INSERT INTO dbo.Trabajador (dni, nombres, apellidos, cargo, estado) VALUES
    (N'78000101', N'Carlos', N'Ramírez Torres', N'Administrador', N'Activo'),
    (N'78000102', N'Andrea', N'Flores Ruiz', N'Asesora de ventas', N'Activo'),
    (N'78000103', N'Luis', N'Mendoza Pérez', N'Asesor de ventas', N'Activo'),
    (N'78000104', N'Valeria', N'Soto Rojas', N'Asesora de alquileres', N'Activo'),
    (N'78000105', N'Miguel', N'Castillo León', N'Encargado de almacén', N'Activo'),
    (N'78000106', N'Daniela', N'Paredes Gómez', N'Asesora de ventas', N'Activo'),
    (N'78000107', N'Renzo', N'Vargas Medina', N'Asesor de alquileres', N'Activo');
GO

INSERT INTO dbo.Cliente (dni, nombres, apellidos, telefono, correo, direccion, distrito, fechaRegistro) VALUES
    (N'77000001', N'Fabio', N'Huamán López', N'936633924', N'cliente001@ejemplo.com', N'Jr. Santa Rosa 163, San Miguel, Lima', N'San Miguel', '2023-05-20T15:50:00'),
    (N'77000002', N'Camila', N'Rojas Salcedo', N'915409396', N'cliente002@ejemplo.com', N'Av. Universitaria 216, Chorrillos, Lima', N'Chorrillos', '2023-02-06T08:20:00'),
    (N'77000003', N'Claudia', N'Acosta Vílchez', N'966710527', N'cliente003@ejemplo.com', N'Jr. Las Palmeras 269, Pueblo Libre, Lima', N'Pueblo Libre', '2023-10-27T14:45:00'),
    (N'77000004', N'Daniel', N'Pérez Gómez', N'976794792', N'cliente004@ejemplo.com', N'Av. Primavera 322, Magdalena, Lima', N'Magdalena', '2023-05-31T08:20:00'),
    (N'77000005', N'José', N'Ramírez Torres', N'934155139', N'cliente005@ejemplo.com', N'Jr. Los Álamos 375, Lince, Lima', N'Lince', '2023-11-10T08:30:00'),
    (N'77000006', N'Andrea', N'Arias Benites', N'957149005', N'cliente006@ejemplo.com', N'Av. Los Próceres 428, Cercado de Lima, Lima', N'Cercado de Lima', '2023-03-07T11:30:00'),
    (N'77000007', N'Natalia', N'Sánchez Peña', N'962458431', N'cliente007@ejemplo.com', N'Calle Las Acacias 481, Jesús María, Lima', N'Jesús María', '2023-12-14T10:00:00'),
    (N'77000008', N'Joaquín', N'Mendoza Soto', N'910209063', N'cliente008@ejemplo.com', N'Av. Los Olivos 534, Breña, Lima', N'Breña', '2023-02-24T16:50:00'),
    (N'77000009', N'Valeria', N'Cárdenas Luna', N'932368522', N'cliente009@ejemplo.com', N'Jr. Santa Rosa 587, La Molina, Lima', N'La Molina', '2023-09-06T08:50:00'),
    (N'77000010', N'Maite', N'Palomino Lazo', N'917716534', N'cliente010@ejemplo.com', N'Av. Universitaria 640, San Borja, Lima', N'San Borja', '2023-10-13T09:10:00'),
    (N'77000011', N'Juan', N'Salazar León', N'981606454', N'cliente011@ejemplo.com', N'Jr. Las Palmeras 693, Surco, Lima', N'Surco', '2023-05-09T08:50:00'),
    (N'77000012', N'Frank', N'Quispe Rojas', N'937368661', N'cliente012@ejemplo.com', N'Av. Primavera 746, Comas, Lima', N'Comas', '2023-11-13T15:00:00'),
    (N'77000013', N'Daniela', N'Paredes Ramos', N'985351027', N'cliente013@ejemplo.com', N'Jr. Los Álamos 799, San Isidro, Lima', N'San Isidro', '2023-09-28T10:30:00'),
    (N'77000014', N'Patricia', N'Navarro Ríos', N'960970971', N'cliente014@ejemplo.com', N'Av. Los Próceres 852, Los Olivos, Lima', N'Los Olivos', '2023-06-07T10:15:00'),
    (N'77000015', N'Carlos', N'Vargas Ruiz', N'950958706', N'cliente015@ejemplo.com', N'Calle Las Acacias 905, Miraflores, Lima', N'Miraflores', '2023-03-23T08:00:00'),
    (N'77000016', N'Thiago', N'Medina Chávez', N'979005559', N'cliente016@ejemplo.com', N'Av. Los Olivos 958, San Miguel, Lima', N'San Miguel', '2023-08-17T13:20:00'),
    (N'77000017', N'Gabriela', N'García Gutiérrez', N'992202455', N'cliente017@ejemplo.com', N'Jr. Santa Rosa 1011, Chorrillos, Lima', N'Chorrillos', '2023-08-31T15:50:00'),
    (N'77000018', N'Mateo', N'Flores Campos', N'949624589', N'cliente018@ejemplo.com', N'Av. Universitaria 1064, Pueblo Libre, Lima', N'Pueblo Libre', '2023-02-06T11:00:00'),
    (N'77000019', N'Adrián', N'Castillo Pérez', N'950483155', N'cliente019@ejemplo.com', N'Jr. Las Palmeras 1117, Magdalena, Lima', N'Magdalena', '2023-11-26T10:20:00'),
    (N'77000020', N'Zulema', N'Reyes Gálvez', N'994185657', N'cliente020@ejemplo.com', N'Av. Primavera 1170, Lince, Lima', N'Lince', '2023-10-01T15:45:00'),
    (N'77000021', N'Mariana', N'Zambrano Núñez', N'942842923', N'cliente021@ejemplo.com', N'Jr. Los Álamos 1223, Cercado de Lima, Lima', N'Cercado de Lima', '2023-06-17T17:15:00'),
    (N'77000022', N'Diego', N'Torres Silva', N'998890696', N'cliente022@ejemplo.com', N'Av. Los Próceres 1276, Jesús María, Lima', N'Jesús María', '2023-09-03T08:45:00'),
    (N'77000023', N'Eduardo', N'Flores Díaz', N'926707619', N'cliente023@ejemplo.com', N'Calle Las Acacias 1329, Breña, Lima', N'Breña', '2023-12-06T14:50:00'),
    (N'77000024', N'Lucía', N'Vega Condori', N'924931876', N'cliente024@ejemplo.com', N'Av. Los Olivos 1382, La Molina, Lima', N'La Molina', '2023-11-12T11:10:00'),
    (N'77000025', N'Sofía', N'Guzmán Ponce', N'957425730', N'cliente025@ejemplo.com', N'Jr. Santa Rosa 1435, San Borja, Lima', N'San Borja', '2023-08-25T13:00:00'),
    (N'77000026', N'Renzo', N'Huamán López', N'921564752', N'cliente026@ejemplo.com', N'Av. Universitaria 1488, Surco, Lima', N'Surco', '2023-02-18T17:10:00'),
    (N'77000027', N'Santiago', N'Rojas Salcedo', N'934415918', N'cliente027@ejemplo.com', N'Jr. Las Palmeras 1541, Comas, Lima', N'Comas', '2023-02-11T17:15:00'),
    (N'77000028', N'Micaela', N'Acosta Vílchez', N'960017811', N'cliente028@ejemplo.com', N'Av. Primavera 1594, San Isidro, Lima', N'San Isidro', '2023-07-03T13:10:00'),
    (N'77000029', N'Sebastián', N'Pérez Gómez', N'929910790', N'cliente029@ejemplo.com', N'Jr. Los Álamos 1647, Los Olivos, Lima', N'Los Olivos', '2023-03-14T12:10:00'),
    (N'77000030', N'Alonso', N'Ramírez Torres', N'944144751', N'cliente030@ejemplo.com', N'Av. Los Próceres 1700, Miraflores, Lima', N'Miraflores', '2023-11-16T12:45:00'),
    (N'77000031', N'Katherin', N'Arias Benites', N'953357751', N'cliente031@ejemplo.com', N'Calle Las Acacias 153, San Miguel, Lima', N'San Miguel', '2023-12-07T17:50:00'),
    (N'77000032', N'Rocío', N'Sánchez Peña', N'942720472', N'cliente032@ejemplo.com', N'Av. Los Olivos 206, Chorrillos, Lima', N'Chorrillos', '2023-02-26T13:40:00'),
    (N'77000033', N'Luis', N'Mendoza Soto', N'943160316', N'cliente033@ejemplo.com', N'Jr. Santa Rosa 259, Pueblo Libre, Lima', N'Pueblo Libre', '2023-07-02T09:15:00'),
    (N'77000034', N'Gael', N'Cárdenas Luna', N'992216832', N'cliente034@ejemplo.com', N'Av. Universitaria 312, Magdalena, Lima', N'Magdalena', '2023-04-14T10:45:00'),
    (N'77000035', N'Alejandra', N'Palomino Lazo', N'932626535', N'cliente035@ejemplo.com', N'Jr. Las Palmeras 365, Lince, Lima', N'Lince', '2023-02-28T10:00:00'),
    (N'77000036', N'Diana', N'Salazar León', N'980831068', N'cliente036@ejemplo.com', N'Av. Primavera 418, Cercado de Lima, Lima', N'Cercado de Lima', '2023-04-16T14:30:00'),
    (N'77000037', N'Ángel', N'Quispe Rojas', N'924401955', N'cliente037@ejemplo.com', N'Jr. Los Álamos 471, Jesús María, Lima', N'Jesús María', '2023-08-02T08:15:00'),
    (N'77000038', N'Fernanda', N'Paredes Ramos', N'991661862', N'cliente038@ejemplo.com', N'Av. Los Próceres 524, Breña, Lima', N'Breña', '2023-05-01T15:40:00'),
    (N'77000039', N'Alessia', N'Navarro Ríos', N'961261995', N'cliente039@ejemplo.com', N'Calle Las Acacias 577, La Molina, Lima', N'La Molina', '2023-04-20T14:00:00'),
    (N'77000040', N'Marco', N'Vargas Ruiz', N'953636789', N'cliente040@ejemplo.com', N'Av. Los Olivos 630, San Borja, Lima', N'San Borja', '2023-08-21T09:00:00'),
    (N'77000041', N'Fabio', N'Medina Chávez', N'914486456', N'cliente041@ejemplo.com', N'Jr. Santa Rosa 683, Surco, Lima', N'Surco', '2023-10-30T17:10:00'),
    (N'77000042', N'Camila', N'García Gutiérrez', N'917589515', N'cliente042@ejemplo.com', N'Av. Universitaria 736, Comas, Lima', N'Comas', '2023-08-25T12:20:00'),
    (N'77000043', N'Claudia', N'Flores Campos', N'923823059', N'cliente043@ejemplo.com', N'Jr. Las Palmeras 789, San Isidro, Lima', N'San Isidro', '2023-10-22T14:00:00'),
    (N'77000044', N'Daniel', N'Castillo Pérez', N'926546004', N'cliente044@ejemplo.com', N'Av. Primavera 842, Los Olivos, Lima', N'Los Olivos', '2023-05-15T08:10:00'),
    (N'77000045', N'José', N'Reyes Gálvez', N'997462314', N'cliente045@ejemplo.com', N'Jr. Los Álamos 895, Miraflores, Lima', N'Miraflores', '2023-07-07T15:20:00'),
    (N'77000046', N'Andrea', N'Zambrano Núñez', N'987706950', N'cliente046@ejemplo.com', N'Av. Los Próceres 948, San Miguel, Lima', N'San Miguel', '2023-03-27T16:10:00'),
    (N'77000047', N'Natalia', N'Torres Silva', N'949781917', N'cliente047@ejemplo.com', N'Calle Las Acacias 1001, Chorrillos, Lima', N'Chorrillos', '2023-06-12T10:00:00'),
    (N'77000048', N'Joaquín', N'Flores Díaz', N'981895565', N'cliente048@ejemplo.com', N'Av. Los Olivos 1054, Pueblo Libre, Lima', N'Pueblo Libre', '2023-04-15T15:20:00'),
    (N'77000049', N'Valeria', N'Vega Condori', N'987574048', N'cliente049@ejemplo.com', N'Jr. Santa Rosa 1107, Magdalena, Lima', N'Magdalena', '2023-04-28T09:00:00'),
    (N'77000050', N'Maite', N'Guzmán Ponce', N'943515997', N'cliente050@ejemplo.com', N'Av. Universitaria 1160, Lince, Lima', N'Lince', '2023-10-30T15:30:00'),
    (N'77000051', N'Juan', N'Huamán López', N'918264889', N'cliente051@ejemplo.com', N'Jr. Las Palmeras 1213, Cercado de Lima, Lima', N'Cercado de Lima', '2023-02-05T14:00:00'),
    (N'77000052', N'Frank', N'Rojas Salcedo', N'982259879', N'cliente052@ejemplo.com', N'Av. Primavera 1266, Jesús María, Lima', N'Jesús María', '2023-07-09T10:30:00'),
    (N'77000053', N'Daniela', N'Acosta Vílchez', N'975489851', N'cliente053@ejemplo.com', N'Jr. Los Álamos 1319, Breña, Lima', N'Breña', '2023-03-06T11:20:00'),
    (N'77000054', N'Patricia', N'Pérez Gómez', N'973203210', N'cliente054@ejemplo.com', N'Av. Los Próceres 1372, La Molina, Lima', N'La Molina', '2023-11-22T15:40:00'),
    (N'77000055', N'Carlos', N'Ramírez Torres', N'986313192', N'cliente055@ejemplo.com', N'Calle Las Acacias 1425, San Borja, Lima', N'San Borja', '2023-03-07T12:40:00'),
    (N'77000056', N'Thiago', N'Arias Benites', N'961735710', N'cliente056@ejemplo.com', N'Av. Los Olivos 1478, Surco, Lima', N'Surco', '2024-05-31T09:30:00'),
    (N'77000057', N'Gabriela', N'Sánchez Peña', N'967234003', N'cliente057@ejemplo.com', N'Jr. Santa Rosa 1531, Comas, Lima', N'Comas', '2024-10-20T17:40:00'),
    (N'77000058', N'Mateo', N'Mendoza Soto', N'987290041', N'cliente058@ejemplo.com', N'Av. Universitaria 1584, San Isidro, Lima', N'San Isidro', '2024-08-16T10:40:00'),
    (N'77000059', N'Adrián', N'Cárdenas Luna', N'924509427', N'cliente059@ejemplo.com', N'Jr. Las Palmeras 1637, Los Olivos, Lima', N'Los Olivos', '2024-10-27T10:45:00'),
    (N'77000060', N'Zulema', N'Palomino Lazo', N'927083213', N'cliente060@ejemplo.com', N'Av. Primavera 1690, Miraflores, Lima', N'Miraflores', '2024-05-02T09:40:00'),
    (N'77000061', N'Mariana', N'Salazar León', N'979259209', N'cliente061@ejemplo.com', N'Jr. Los Álamos 143, San Miguel, Lima', N'San Miguel', '2024-04-28T09:40:00'),
    (N'77000062', N'Diego', N'Quispe Rojas', N'934851910', N'cliente062@ejemplo.com', N'Av. Los Próceres 196, Chorrillos, Lima', N'Chorrillos', '2024-05-02T15:15:00'),
    (N'77000063', N'Eduardo', N'Paredes Ramos', N'928567633', N'cliente063@ejemplo.com', N'Calle Las Acacias 249, Pueblo Libre, Lima', N'Pueblo Libre', '2024-06-06T13:40:00'),
    (N'77000064', N'Lucía', N'Navarro Ríos', N'988087194', N'cliente064@ejemplo.com', N'Av. Los Olivos 302, Magdalena, Lima', N'Magdalena', '2024-01-27T10:00:00'),
    (N'77000065', N'Sofía', N'Vargas Ruiz', N'964247701', N'cliente065@ejemplo.com', N'Jr. Santa Rosa 355, Lince, Lima', N'Lince', '2024-03-26T09:00:00'),
    (N'77000066', N'Renzo', N'Medina Chávez', N'958199486', N'cliente066@ejemplo.com', N'Av. Universitaria 408, Cercado de Lima, Lima', N'Cercado de Lima', '2024-11-25T17:45:00'),
    (N'77000067', N'Santiago', N'García Gutiérrez', N'937304995', N'cliente067@ejemplo.com', N'Jr. Las Palmeras 461, Jesús María, Lima', N'Jesús María', '2024-07-20T14:15:00'),
    (N'77000068', N'Micaela', N'Flores Campos', N'921003360', N'cliente068@ejemplo.com', N'Av. Primavera 514, Breña, Lima', N'Breña', '2024-10-28T15:50:00'),
    (N'77000069', N'Sebastián', N'Castillo Pérez', N'924737922', N'cliente069@ejemplo.com', N'Jr. Los Álamos 567, La Molina, Lima', N'La Molina', '2024-08-26T11:45:00'),
    (N'77000070', N'Alonso', N'Reyes Gálvez', N'987605483', N'cliente070@ejemplo.com', N'Av. Los Próceres 620, San Borja, Lima', N'San Borja', '2024-10-10T11:30:00'),
    (N'77000071', N'Katherin', N'Zambrano Núñez', N'938121125', N'cliente071@ejemplo.com', N'Calle Las Acacias 673, Surco, Lima', N'Surco', '2024-02-28T12:50:00'),
    (N'77000072', N'Rocío', N'Torres Silva', N'983784508', N'cliente072@ejemplo.com', N'Av. Los Olivos 726, Comas, Lima', N'Comas', '2024-02-13T08:20:00'),
    (N'77000073', N'Luis', N'Flores Díaz', N'961936366', N'cliente073@ejemplo.com', N'Jr. Santa Rosa 779, San Isidro, Lima', N'San Isidro', '2024-07-28T17:20:00'),
    (N'77000074', N'Gael', N'Vega Condori', N'983928226', N'cliente074@ejemplo.com', N'Av. Universitaria 832, Los Olivos, Lima', N'Los Olivos', '2024-08-30T11:20:00'),
    (N'77000075', N'Alejandra', N'Guzmán Ponce', N'919650714', N'cliente075@ejemplo.com', N'Jr. Las Palmeras 885, Miraflores, Lima', N'Miraflores', '2024-09-26T08:00:00'),
    (N'77000076', N'Diana', N'Huamán López', N'933324215', N'cliente076@ejemplo.com', N'Av. Primavera 938, San Miguel, Lima', N'San Miguel', '2024-11-26T10:10:00'),
    (N'77000077', N'Ángel', N'Rojas Salcedo', N'915393250', N'cliente077@ejemplo.com', N'Jr. Los Álamos 991, Chorrillos, Lima', N'Chorrillos', '2026-05-23T08:20:00'),
    (N'77000078', N'Fernanda', N'Acosta Vílchez', N'928602385', N'cliente078@ejemplo.com', N'Av. Los Próceres 1044, Pueblo Libre, Lima', N'Pueblo Libre', '2025-01-18T16:50:00'),
    (N'77000079', N'Alessia', N'Pérez Gómez', N'969383528', N'cliente079@ejemplo.com', N'Calle Las Acacias 1097, Magdalena, Lima', N'Magdalena', '2025-09-06T16:15:00'),
    (N'77000080', N'Marco', N'Ramírez Torres', N'930940493', N'cliente080@ejemplo.com', N'Av. Los Olivos 1150, Lince, Lima', N'Lince', '2026-01-13T15:50:00'),
    (N'77000081', N'Fabio', N'Arias Benites', N'964635346', N'cliente081@ejemplo.com', N'Jr. Santa Rosa 1203, Cercado de Lima, Lima', N'Cercado de Lima', '2025-10-20T11:20:00'),
    (N'77000082', N'Camila', N'Sánchez Peña', N'958815811', N'cliente082@ejemplo.com', N'Av. Universitaria 1256, Jesús María, Lima', N'Jesús María', '2025-10-24T14:15:00'),
    (N'77000083', N'Claudia', N'Mendoza Soto', N'982412972', N'cliente083@ejemplo.com', N'Jr. Las Palmeras 1309, Breña, Lima', N'Breña', '2026-03-24T08:30:00'),
    (N'77000084', N'Daniel', N'Cárdenas Luna', N'931654804', N'cliente084@ejemplo.com', N'Av. Primavera 1362, La Molina, Lima', N'La Molina', '2026-04-01T16:40:00'),
    (N'77000085', N'José', N'Palomino Lazo', N'990663122', N'cliente085@ejemplo.com', N'Jr. Los Álamos 1415, San Borja, Lima', N'San Borja', '2025-05-07T14:45:00'),
    (N'77000086', N'Andrea', N'Salazar León', N'911689158', N'cliente086@ejemplo.com', N'Av. Los Próceres 1468, Surco, Lima', N'Surco', '2026-04-07T15:15:00'),
    (N'77000087', N'Natalia', N'Quispe Rojas', N'990192055', N'cliente087@ejemplo.com', N'Calle Las Acacias 1521, Comas, Lima', N'Comas', '2025-11-22T10:00:00'),
    (N'77000088', N'Joaquín', N'Paredes Ramos', N'944102327', N'cliente088@ejemplo.com', N'Av. Los Olivos 1574, San Isidro, Lima', N'San Isidro', '2026-03-09T10:50:00'),
    (N'77000089', N'Valeria', N'Navarro Ríos', N'943721058', N'cliente089@ejemplo.com', N'Jr. Santa Rosa 1627, Los Olivos, Lima', N'Los Olivos', '2026-01-29T16:10:00'),
    (N'77000090', N'Maite', N'Vargas Ruiz', N'926683196', N'cliente090@ejemplo.com', N'Av. Universitaria 1680, Miraflores, Lima', N'Miraflores', '2025-04-29T14:00:00');
GO

INSERT INTO dbo.Articulo (idCategoria, codigo, nombre, talla, color, costoCompra, precioAlquiler, precioVenta, stock, stockMinimo, estado) VALUES
    (1, N'ME-01-001', N'Terno clásico slim', N'M', N'Negro', 245, 120, 460, 9, 2, N'Activo'),
    (1, N'ME-01-002', N'Terno clásico slim', N'L', N'Azul marino', 255, 125, 475, 9, 2, N'Activo'),
    (1, N'ME-01-003', N'Terno ejecutivo', N'M', N'Gris grafito', 280, 145, 530, 8, 2, N'Activo'),
    (1, N'ME-01-004', N'Terno ejecutivo', N'L', N'Negro', 285, 150, 540, 8, 2, N'Activo'),
    (1, N'ME-01-005', N'Terno tres piezas', N'M', N'Azul noche', 330, 185, 640, 7, 2, N'Activo'),
    (1, N'ME-01-006', N'Terno tres piezas', N'L', N'Gris perla', 340, 190, 660, 7, 2, N'Activo'),
    (1, N'ME-01-007', N'Terno de ceremonia', N'S', N'Beige', 305, 175, 590, 6, 2, N'Activo'),
    (1, N'ME-01-008', N'Terno de ceremonia', N'XL', N'Negro', 345, 205, 690, 5, 1, N'Activo'),
    (2, N'ME-02-009', N'Vestido de gala satinado', N'S', N'Borgoña', 230, 155, 470, 7, 2, N'Activo'),
    (2, N'ME-02-010', N'Vestido de gala satinado', N'M', N'Azul petróleo', 240, 160, 490, 7, 2, N'Activo'),
    (2, N'ME-02-011', N'Vestido largo plisado', N'M', N'Verde esmeralda', 200, 135, 410, 8, 2, N'Activo'),
    (2, N'ME-02-012', N'Vestido largo plisado', N'L', N'Rosa palo', 210, 140, 430, 8, 2, N'Activo'),
    (2, N'ME-02-013', N'Vestido de coctel', N'S', N'Negro', 165, 105, 335, 8, 2, N'Activo'),
    (2, N'ME-02-014', N'Vestido de coctel', N'M', N'Champán', 175, 115, 355, 8, 2, N'Activo'),
    (2, N'ME-02-015', N'Vestido de fiesta encaje', N'L', N'Azul marino', 220, 150, 455, 6, 2, N'Activo'),
    (2, N'ME-02-016', N'Vestido madrina', N'XL', N'Vino', 275, 180, 560, 5, 1, N'Activo'),
    (3, N'ME-03-017', N'Camisa Oxford premium', N'M', N'Blanco', 48, 28, 105, 16, 4, N'Activo'),
    (3, N'ME-03-018', N'Camisa Oxford premium', N'L', N'Celeste', 50, 28, 110, 15, 4, N'Activo'),
    (3, N'ME-03-019', N'Camisa cuello italiano', N'M', N'Blanco', 55, 32, 120, 14, 3, N'Activo'),
    (3, N'ME-03-020', N'Camisa cuello italiano', N'XL', N'Negro', 57, 35, 125, 10, 2, N'Activo'),
    (4, N'ME-04-021', N'Blazer de lino', N'M', N'Arena', 145, 75, 295, 9, 2, N'Activo'),
    (4, N'ME-04-022', N'Blazer de lino', N'L', N'Azul marino', 150, 80, 310, 9, 2, N'Activo'),
    (4, N'ME-04-023', N'Saco cruzado elegante', N'M', N'Negro', 160, 90, 340, 8, 2, N'Activo'),
    (4, N'ME-04-024', N'Saco juvenil entallado', N'S', N'Gris', 130, 70, 275, 9, 2, N'Activo'),
    (5, N'ME-05-025', N'Pantalón de vestir slim', N'30', N'Negro', 68, 35, 145, 14, 3, N'Activo'),
    (5, N'ME-05-026', N'Pantalón de vestir clásico', N'32', N'Gris oscuro', 72, 40, 155, 13, 3, N'Activo'),
    (5, N'ME-05-027', N'Pantalón sastre dama', N'M', N'Beige', 82, 45, 175, 11, 2, N'Activo'),
    (5, N'ME-05-028', N'Pantalón sastre dama', N'L', N'Negro', 85, 48, 180, 10, 2, N'Activo'),
    (6, N'ME-06-029', N'Corbata de seda', N'Única', N'Azul marino', 19, 10, 49, 28, 5, N'Activo'),
    (6, N'ME-06-030', N'Corbata de seda', N'Única', N'Borgoña', 19, 10, 49, 28, 5, N'Activo'),
    (6, N'ME-06-031', N'Pajarita satinada', N'Única', N'Negro', 15, 8, 39, 27, 5, N'Activo'),
    (6, N'ME-06-032', N'Cinturón formal', N'M', N'Marrón', 22, 12, 55, 24, 4, N'Activo'),
    (6, N'ME-06-033', N'Pañuelo de bolsillo', N'Única', N'Blanco', 11, 6, 29, 30, 6, N'Activo'),
    (6, N'ME-06-034', N'Set de gemelos', N'Única', N'Plateado', 32, 15, 75, 17, 3, N'Activo'),
    (7, N'ME-07-035', N'Zapato Oxford cuero', N'40', N'Negro', 110, 60, 245, 9, 2, N'Activo'),
    (7, N'ME-07-036', N'Zapato Derby', N'42', N'Marrón', 115, 65, 255, 8, 2, N'Activo'),
    (7, N'ME-07-037', N'Tacón de fiesta', N'37', N'Nude', 90, 55, 205, 9, 2, N'Activo'),
    (7, N'ME-07-038', N'Tacón de fiesta', N'39', N'Negro', 92, 55, 210, 9, 2, N'Activo'),
    (8, N'ME-08-039', N'Terno infantil ceremonia', N'8', N'Azul marino', 105, 65, 230, 8, 2, N'Activo'),
    (8, N'ME-08-040', N'Terno infantil ceremonia', N'12', N'Gris', 112, 70, 245, 7, 2, N'Activo'),
    (8, N'ME-08-041', N'Vestido infantil tul', N'8', N'Rosa palo', 85, 55, 190, 8, 2, N'Activo'),
    (8, N'ME-08-042', N'Vestido infantil tul', N'12', N'Blanco', 88, 55, 195, 8, 2, N'Activo'),
    (9, N'ME-09-043', N'Conjunto sastre dos piezas', N'S', N'Crema', 185, 115, 385, 7, 2, N'Activo'),
    (9, N'ME-09-044', N'Conjunto sastre dos piezas', N'M', N'Negro', 190, 120, 395, 8, 2, N'Activo'),
    (9, N'ME-09-045', N'Conjunto blazer y falda', N'M', N'Azul noche', 175, 110, 370, 8, 2, N'Activo'),
    (9, N'ME-09-046', N'Conjunto blazer y pantalón', N'L', N'Arena', 200, 125, 420, 7, 2, N'Activo');
GO

INSERT INTO dbo.Venta (idCliente, idTrabajador, fechaVenta, tipoComprobante, canalVenta, estado, total) VALUES
    (41, 3, '2024-01-16T09:40:00', N'Boleta', N'WhatsApp', N'Pagada', 698.00),
    (11, 6, '2024-01-18T09:00:00', N'Boleta', N'Instagram', N'Pagada', 835),
    (52, 4, '2024-01-20T08:45:00', N'Boleta', N'Tienda física', N'Pagada', 205),
    (37, 7, '2024-02-02T11:30:00', N'Boleta', N'Tienda física', N'Pagada', 355),
    (28, 7, '2024-02-02T13:30:00', N'Factura', N'Tienda física', N'Pagada', 646.25),
    (33, 2, '2024-02-08T13:50:00', N'Boleta', N'Tienda física', N'Pagada', 656.00),
    (38, 7, '2024-02-20T09:50:00', N'Boleta', N'WhatsApp', N'Pagada', 171.00),
    (3, 4, '2024-02-25T15:00:00', N'Boleta', N'Tienda física', N'Pagada', 300),
    (36, 6, '2024-03-01T09:10:00', N'Boleta', N'Tienda física', N'Pagada', 1295.50),
    (46, 3, '2024-03-07T13:50:00', N'Boleta', N'Instagram', N'Pagada', 147),
    (25, 7, '2024-03-09T08:40:00', N'Boleta', N'Tienda física', N'Pagada', 350),
    (33, 4, '2024-03-12T16:40:00', N'Boleta', N'WhatsApp', N'Pagada', 890),
    (41, 2, '2024-03-24T16:10:00', N'Boleta', N'Tienda física', N'Pagada', 677.25),
    (46, 7, '2024-03-27T12:50:00', N'Boleta', N'Tienda física', N'Pagada', 826.50),
    (33, 7, '2024-03-27T12:15:00', N'Boleta', N'Tienda física', N'Pagada', 631.00),
    (15, 4, '2024-03-29T16:15:00', N'Boleta', N'Instagram', N'Pagada', 347.25),
    (53, 3, '2024-04-03T13:00:00', N'Boleta', N'Tienda física', N'Pagada', 245),
    (39, 4, '2024-04-15T10:40:00', N'Boleta', N'Tienda física', N'Pagada', 301.50),
    (18, 4, '2024-04-18T15:30:00', N'Boleta', N'WhatsApp', N'Pagada', 370),
    (30, 3, '2024-04-19T08:30:00', N'Boleta', N'WhatsApp', N'Pagada', 897.50),
    (42, 6, '2024-04-24T16:45:00', N'Boleta', N'Instagram', N'Pagada', 825),
    (47, 6, '2024-04-25T09:15:00', N'Boleta', N'Tienda física', N'Pagada', 720),
    (35, 6, '2024-05-13T14:15:00', N'Boleta', N'WhatsApp', N'Pagada', 831.25),
    (27, 4, '2024-05-17T15:20:00', N'Boleta', N'WhatsApp', N'Pagada', 871.25),
    (8, 7, '2024-06-12T16:45:00', N'Boleta', N'WhatsApp', N'Pagada', 49),
    (9, 2, '2024-06-18T10:10:00', N'Boleta', N'Instagram', N'Pagada', 259),
    (3, 7, '2024-06-21T09:45:00', N'Boleta', N'Tienda física', N'Pagada', 783.75),
    (30, 2, '2024-07-12T09:00:00', N'Boleta', N'WhatsApp', N'Pagada', 250),
    (31, 3, '2024-07-13T13:50:00', N'Boleta', N'Tienda física', N'Pagada', 330),
    (56, 4, '2024-07-14T09:30:00', N'Boleta', N'Tienda física', N'Pagada', 850.50),
    (1, 7, '2024-07-31T12:50:00', N'Boleta', N'Tienda física', N'Pagada', 560),
    (64, 7, '2024-08-03T14:50:00', N'Boleta', N'WhatsApp', N'Pagada', 690),
    (31, 3, '2024-08-07T13:40:00', N'Boleta', N'Tienda física', N'Pagada', 405),
    (10, 3, '2024-08-09T13:45:00', N'Factura', N'WhatsApp', N'Pagada', 581.75),
    (4, 4, '2024-08-11T12:00:00', N'Boleta', N'Instagram', N'Pagada', 104),
    (25, 6, '2024-08-23T13:30:00', N'Boleta', N'WhatsApp', N'Pagada', 412.50),
    (65, 3, '2024-08-24T11:45:00', N'Factura', N'WhatsApp', N'Pagada', 148.60),
    (5, 6, '2024-09-09T10:15:00', N'Boleta', N'Tienda física', N'Pagada', 569),
    (41, 3, '2024-09-10T16:50:00', N'Boleta', N'Tienda física', N'Pagada', 275),
    (22, 7, '2024-09-18T10:00:00', N'Boleta', N'Instagram', N'Pagada', 521.00),
    (32, 3, '2024-09-22T14:40:00', N'Boleta', N'Tienda física', N'Pagada', 123.10),
    (67, 4, '2024-09-22T08:00:00', N'Boleta', N'WhatsApp', N'Pagada', 679),
    (11, 6, '2024-09-26T15:20:00', N'Boleta', N'Tienda física', N'Pagada', 404),
    (19, 6, '2024-10-02T12:30:00', N'Boleta', N'WhatsApp', N'Pagada', 174.75),
    (28, 2, '2024-10-02T15:00:00', N'Boleta', N'Tienda física', N'Pagada', 1220),
    (15, 2, '2024-10-08T15:15:00', N'Boleta', N'Tienda física', N'Pagada', 451.25),
    (5, 3, '2024-10-12T13:00:00', N'Boleta', N'Tienda física', N'Pagada', 185.25),
    (50, 2, '2024-10-12T16:15:00', N'Boleta', N'WhatsApp', N'Pagada', 640),
    (49, 7, '2024-10-12T15:30:00', N'Boleta', N'Tienda física', N'Pagada', 210),
    (58, 3, '2024-10-13T08:40:00', N'Boleta', N'WhatsApp', N'Pagada', 420),
    (47, 7, '2024-10-16T14:20:00', N'Boleta', N'WhatsApp', N'Pagada', 175),
    (56, 3, '2024-11-03T12:40:00', N'Factura', N'WhatsApp', N'Pagada', 624.50),
    (34, 3, '2024-11-09T09:30:00', N'Boleta', N'Instagram', N'Pagada', 1097.25),
    (1, 7, '2024-11-10T08:00:00', N'Factura', N'Tienda física', N'Pagada', 255),
    (72, 2, '2024-11-16T13:15:00', N'Boleta', N'Tienda física', N'Pagada', 176.55),
    (39, 3, '2024-11-20T13:15:00', N'Boleta', N'Tienda física', N'Pagada', 250),
    (46, 7, '2024-11-24T12:40:00', N'Boleta', N'WhatsApp', N'Pagada', 137.75),
    (52, 7, '2024-11-27T09:15:00', N'Boleta', N'Tienda física', N'Pagada', 1031.25),
    (24, 6, '2024-12-11T16:20:00', N'Factura', N'Instagram', N'Pagada', 614.75),
    (2, 6, '2024-12-18T08:10:00', N'Boleta', N'WhatsApp', N'Pagada', 855),
    (66, 4, '2025-01-12T17:40:00', N'Boleta', N'Tienda física', N'Pagada', 120),
    (54, 4, '2025-01-21T11:30:00', N'Factura', N'Tienda física', N'Pagada', 575),
    (7, 6, '2025-01-22T12:20:00', N'Boleta', N'Web', N'Pagada', 139.65),
    (33, 2, '2025-01-23T12:15:00', N'Boleta', N'Tienda física', N'Pagada', 414.50),
    (5, 7, '2025-01-24T09:10:00', N'Boleta', N'Instagram', N'Pagada', 615.50),
    (5, 7, '2025-01-26T09:00:00', N'Boleta', N'Instagram', N'Pagada', 581.50),
    (65, 3, '2025-01-30T11:15:00', N'Boleta', N'WhatsApp', N'Pagada', 530),
    (69, 7, '2025-02-04T11:30:00', N'Boleta', N'Tienda física', N'Pagada', 390),
    (53, 3, '2025-02-06T11:50:00', N'Boleta', N'Tienda física', N'Pagada', 745),
    (76, 6, '2025-02-09T13:00:00', N'Boleta', N'Tienda física', N'Pagada', 784.50),
    (43, 6, '2025-02-09T15:20:00', N'Factura', N'Tienda física', N'Pagada', 295),
    (40, 2, '2025-02-12T15:00:00', N'Boleta', N'WhatsApp', N'Pagada', 503.50),
    (35, 4, '2025-02-21T16:10:00', N'Boleta', N'Tienda física', N'Pagada', 780),
    (66, 4, '2025-02-22T09:50:00', N'Factura', N'Tienda física', N'Pagada', 365),
    (20, 4, '2025-03-01T12:20:00', N'Boleta', N'Tienda física', N'Pagada', 847.00),
    (25, 7, '2025-03-05T16:45:00', N'Boleta', N'Tienda física', N'Pagada', 150),
    (42, 3, '2025-03-13T11:15:00', N'Boleta', N'WhatsApp', N'Pagada', 835),
    (6, 7, '2025-03-25T17:15:00', N'Factura', N'Tienda física', N'Pagada', 385),
    (67, 2, '2025-03-25T13:15:00', N'Boleta', N'Tienda física', N'Pagada', 240),
    (35, 6, '2025-03-26T11:40:00', N'Boleta', N'Tienda física', N'Pagada', 780),
    (9, 2, '2025-03-29T12:10:00', N'Boleta', N'Instagram', N'Pagada', 370),
    (46, 7, '2025-04-10T09:50:00', N'Factura', N'WhatsApp', N'Pagada', 565),
    (65, 4, '2025-04-24T08:30:00', N'Factura', N'WhatsApp', N'Pagada', 255),
    (12, 3, '2025-04-24T08:30:00', N'Boleta', N'Web', N'Pagada', 660),
    (11, 6, '2025-04-27T09:10:00', N'Boleta', N'Tienda física', N'Pagada', 250),
    (58, 7, '2025-04-29T09:50:00', N'Boleta', N'Instagram', N'Pagada', 826.75),
    (8, 2, '2025-05-02T15:40:00', N'Boleta', N'Tienda física', N'Pagada', 890),
    (24, 6, '2025-05-04T16:40:00', N'Boleta', N'Tienda física', N'Pagada', 541.50),
    (26, 7, '2025-05-21T10:45:00', N'Boleta', N'Tienda física', N'Pagada', 740),
    (6, 3, '2025-05-23T12:45:00', N'Boleta', N'Tienda física', N'Pagada', 800),
    (41, 7, '2025-05-26T14:15:00', N'Boleta', N'Tienda física', N'Pagada', 112.50),
    (75, 7, '2025-05-26T09:40:00', N'Factura', N'Tienda física', N'Pagada', 310),
    (40, 2, '2025-06-03T16:20:00', N'Boleta', N'Tienda física', N'Pagada', 498.00),
    (40, 2, '2025-06-06T12:15:00', N'Boleta', N'Tienda física', N'Pagada', 450),
    (50, 6, '2025-06-10T11:10:00', N'Boleta', N'WhatsApp', N'Pagada', 190),
    (45, 6, '2025-06-13T11:15:00', N'Boleta', N'Tienda física', N'Pagada', 539),
    (19, 6, '2025-06-13T09:30:00', N'Boleta', N'Tienda física', N'Pagada', 974.00),
    (48, 6, '2025-06-15T14:30:00', N'Boleta', N'WhatsApp', N'Pagada', 177.50),
    (62, 7, '2025-06-16T15:20:00', N'Factura', N'Tienda física', N'Pagada', 389.50),
    (42, 7, '2025-06-18T15:00:00', N'Factura', N'WhatsApp', N'Pagada', 822.75),
    (75, 4, '2025-06-20T17:45:00', N'Boleta', N'WhatsApp', N'Pagada', 526.50),
    (16, 7, '2025-06-21T11:15:00', N'Factura', N'Tienda física', N'Pagada', 205),
    (49, 4, '2025-06-27T16:50:00', N'Boleta', N'Tienda física', N'Pagada', 658.25),
    (63, 7, '2025-07-16T10:30:00', N'Boleta', N'WhatsApp', N'Pagada', 1020),
    (28, 4, '2025-07-18T15:10:00', N'Factura', N'Tienda física', N'Pagada', 605),
    (24, 7, '2025-07-19T15:40:00', N'Boleta', N'Tienda física', N'Pagada', 275),
    (48, 2, '2025-07-24T09:45:00', N'Boleta', N'WhatsApp', N'Pagada', 350),
    (62, 4, '2025-07-31T10:50:00', N'Factura', N'WhatsApp', N'Pagada', 709),
    (44, 7, '2025-08-02T13:40:00', N'Boleta', N'Tienda física', N'Pagada', 240),
    (34, 6, '2025-08-12T10:20:00', N'Boleta', N'Tienda física', N'Pagada', 49),
    (17, 4, '2025-08-13T11:00:00', N'Boleta', N'WhatsApp', N'Pagada', 243),
    (22, 6, '2025-08-16T15:00:00', N'Boleta', N'Tienda física', N'Pagada', 370),
    (46, 6, '2025-08-20T12:10:00', N'Boleta', N'Web', N'Pagada', 640),
    (1, 4, '2025-08-23T15:50:00', N'Boleta', N'Tienda física', N'Pagada', 606.50),
    (11, 3, '2025-09-04T14:50:00', N'Boleta', N'WhatsApp', N'Pagada', 1125),
    (16, 4, '2025-09-09T17:20:00', N'Boleta', N'Tienda física', N'Pagada', 340),
    (72, 7, '2025-10-01T08:30:00', N'Factura', N'Tienda física', N'Pagada', 414.50),
    (48, 2, '2025-10-04T14:15:00', N'Boleta', N'WhatsApp', N'Pagada', 39),
    (46, 4, '2025-10-09T10:15:00', N'Boleta', N'Tienda física', N'Pagada', 490),
    (36, 4, '2025-10-09T10:50:00', N'Boleta', N'Instagram', N'Pagada', 845),
    (34, 3, '2025-10-11T12:20:00', N'Boleta', N'WhatsApp', N'Pagada', 779.10),
    (63, 2, '2025-10-16T15:00:00', N'Boleta', N'Tienda física', N'Pagada', 234.25),
    (32, 2, '2025-10-30T13:20:00', N'Boleta', N'WhatsApp', N'Pagada', 395),
    (11, 3, '2025-10-31T15:45:00', N'Factura', N'Tienda física', N'Pagada', 67.50),
    (26, 4, '2025-11-01T14:45:00', N'Boleta', N'Tienda física', N'Pagada', 232.75),
    (72, 6, '2025-11-15T12:50:00', N'Factura', N'Instagram', N'Pagada', 589),
    (6, 3, '2025-11-22T12:00:00', N'Boleta', N'Tienda física', N'Pagada', 304.75),
    (59, 6, '2025-12-05T09:20:00', N'Boleta', N'Tienda física', N'Pagada', 475),
    (19, 2, '2025-12-17T09:30:00', N'Boleta', N'Tienda física', N'Pagada', 294),
    (79, 4, '2025-12-17T15:40:00', N'Boleta', N'WhatsApp', N'Pagada', 710.50),
    (66, 2, '2026-01-10T16:20:00', N'Boleta', N'Tienda física', N'Pagada', 715),
    (11, 6, '2026-01-14T15:20:00', N'Boleta', N'Tienda física', N'Pagada', 890),
    (62, 3, '2026-01-16T13:45:00', N'Boleta', N'Tienda física', N'Pagada', 590),
    (73, 2, '2026-01-23T10:10:00', N'Boleta', N'Tienda física', N'Pagada', 191.55),
    (53, 2, '2026-01-29T15:10:00', N'Boleta', N'Tienda física', N'Pagada', 110),
    (49, 6, '2026-02-03T14:30:00', N'Boleta', N'Tienda física', N'Pagada', 308.00),
    (63, 2, '2026-02-10T09:40:00', N'Boleta', N'WhatsApp', N'Pagada', 845),
    (32, 2, '2026-02-16T11:00:00', N'Boleta', N'Tienda física', N'Pagada', 264.00),
    (16, 3, '2026-02-20T08:15:00', N'Boleta', N'Tienda física', N'Pagada', 855.50),
    (69, 4, '2026-03-03T16:15:00', N'Boleta', N'Tienda física', N'Pagada', 799.75),
    (82, 7, '2026-03-06T13:45:00', N'Boleta', N'Tienda física', N'Pagada', 364.50),
    (71, 3, '2026-03-12T16:45:00', N'Boleta', N'Tienda física', N'Pagada', 810),
    (28, 2, '2026-03-17T17:40:00', N'Boleta', N'Tienda física', N'Pagada', 355),
    (87, 2, '2026-03-28T11:50:00', N'Boleta', N'WhatsApp', N'Pagada', 369.10),
    (61, 3, '2026-04-03T17:20:00', N'Boleta', N'WhatsApp', N'Pagada', 513.05),
    (47, 4, '2026-04-06T16:30:00', N'Factura', N'Tienda física', N'Pagada', 394.25),
    (48, 7, '2026-04-12T16:50:00', N'Boleta', N'Tienda física', N'Pagada', 441.75),
    (71, 6, '2026-04-12T10:20:00', N'Boleta', N'Instagram', N'Pagada', 1506.00),
    (55, 6, '2026-04-23T10:50:00', N'Boleta', N'Tienda física', N'Pagada', 605),
    (3, 7, '2026-05-04T12:20:00', N'Boleta', N'Tienda física', N'Pagada', 390);
GO

INSERT INTO dbo.Venta (idCliente, idTrabajador, fechaVenta, tipoComprobante, canalVenta, estado, total) VALUES
    (8, 2, '2026-05-04T14:00:00', N'Boleta', N'Tienda física', N'Pagada', 540),
    (18, 3, '2026-05-06T11:20:00', N'Factura', N'Tienda física', N'Pagada', 467.50),
    (34, 2, '2026-05-13T14:30:00', N'Boleta', N'WhatsApp', N'Pagada', 454.50),
    (76, 3, '2026-05-27T13:10:00', N'Boleta', N'Tienda física', N'Pagada', 451.25),
    (9, 4, '2026-06-03T13:50:00', N'Boleta', N'WhatsApp', N'Pagada', 600),
    (66, 4, '2026-06-12T16:20:00', N'Boleta', N'Tienda física', N'Pagada', 375.25),
    (2, 2, '2026-06-15T14:10:00', N'Boleta', N'WhatsApp', N'Pagada', 601.25),
    (53, 3, '2026-06-16T15:30:00', N'Factura', N'Tienda física', N'Pagada', 39),
    (36, 3, '2026-06-19T12:30:00', N'Boleta', N'WhatsApp', N'Pagada', 166.25),
    (40, 3, '2026-06-22T15:10:00', N'Boleta', N'WhatsApp', N'Pagada', 150),
    (83, 3, '2026-06-25T14:20:00', N'Factura', N'Instagram', N'Pagada', 550),
    (82, 6, '2026-07-01T14:20:00', N'Boleta', N'Tienda física', N'Pagada', 925),
    (2, 4, '2026-07-02T16:45:00', N'Boleta', N'Tienda física', N'Pagada', 240),
    (44, 3, '2026-07-06T11:20:00', N'Boleta', N'Instagram', N'Pagada', 410),
    (27, 7, '2026-07-25T16:15:00', N'Boleta', N'Web', N'Pagada', 990),
    (87, 4, '2026-07-29T13:00:00', N'Boleta', N'Tienda física', N'Pagada', 560.50),
    (19, 4, '2026-08-02T14:30:00', N'Boleta', N'Tienda física', N'Pagada', 690),
    (72, 3, '2026-08-13T10:15:00', N'Boleta', N'WhatsApp', N'Pagada', 438),
    (8, 3, '2026-08-16T09:20:00', N'Boleta', N'Tienda física', N'Pagada', 440),
    (8, 6, '2026-08-18T12:15:00', N'Factura', N'Tienda física', N'Pagada', 563.50),
    (69, 3, '2026-08-30T11:20:00', N'Factura', N'Tienda física', N'Pagada', 385.50),
    (61, 4, '2026-08-30T13:10:00', N'Factura', N'Tienda física', N'Pagada', 473.75),
    (14, 3, '2026-09-01T17:40:00', N'Boleta', N'Tienda física', N'Pagada', 166.25),
    (10, 3, '2026-09-01T16:45:00', N'Boleta', N'Tienda física', N'Pagada', 430),
    (7, 7, '2026-09-13T14:50:00', N'Boleta', N'Tienda física', N'Pagada', 540),
    (62, 7, '2026-09-18T17:15:00', N'Boleta', N'Tienda física', N'Pagada', 261.00),
    (66, 2, '2026-09-18T08:30:00', N'Boleta', N'Tienda física', N'Pagada', 210),
    (20, 7, '2026-09-24T17:50:00', N'Factura', N'WhatsApp', N'Pagada', 750),
    (61, 4, '2026-09-25T14:15:00', N'Boleta', N'Tienda física', N'Pagada', 75),
    (89, 6, '2026-09-29T09:20:00', N'Boleta', N'WhatsApp', N'Parcial', 540),
    (60, 3, '2026-10-03T12:30:00', N'Factura', N'WhatsApp', N'Pagada', 880.50),
    (3, 2, '2026-10-04T11:20:00', N'Boleta', N'WhatsApp', N'Pagada', 1020),
    (53, 6, '2026-10-04T13:10:00', N'Boleta', N'Tienda física', N'Pagada', 261.25),
    (85, 4, '2026-10-06T14:20:00', N'Boleta', N'Tienda física', N'Parcial', 29),
    (50, 3, '2026-10-13T15:00:00', N'Factura', N'Tienda física', N'Pagada', 917.00);
GO

INSERT INTO dbo.Alquiler (idCliente, idTrabajador, fechaAlquiler, fechaEntrega, fechaDevolucionProgramada, fechaDevolucionReal, tipoEvento, canalReserva, estado, observacion, total) VALUES
    (53, 3, '2024-01-08T16:10:00', '2024-01-08T16:10:00', '2024-01-12T17:30:00', '2024-01-12T14:15:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 220),
    (29, 7, '2024-01-18T10:45:00', '2024-01-18T11:15:00', '2024-01-22T17:30:00', '2024-01-22T12:15:00', N'Graduación', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 66.50),
    (52, 6, '2024-01-19T16:15:00', '2024-01-21T09:00:00', '2024-01-24T17:30:00', '2024-01-24T11:30:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 150),
    (26, 3, '2024-01-26T14:10:00', '2024-01-27T12:30:00', '2024-01-29T17:30:00', '2024-01-29T09:45:00', N'Quinceañero', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 145),
    (4, 2, '2024-01-26T08:15:00', '2024-01-27T11:45:00', '2024-01-30T17:30:00', '2024-01-31T14:15:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 120),
    (26, 2, '2024-01-28T12:20:00', '2024-01-29T12:45:00', '2024-02-03T17:30:00', '2024-02-03T13:00:00', N'Ceremonia familiar', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 142.00),
    (42, 6, '2024-02-01T17:00:00', '2024-02-02T14:30:00', '2024-02-07T17:30:00', '2024-02-07T15:15:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 270),
    (19, 4, '2024-02-02T08:45:00', '2024-02-03T13:30:00', '2024-02-05T17:30:00', '2024-02-06T15:15:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: fuera de plazo; incidencia por manchado', 120),
    (33, 6, '2024-02-12T16:30:00', '2024-02-14T14:30:00', '2024-02-18T17:30:00', '2024-02-18T10:15:00', N'Sesión fotográfica', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 52.25),
    (26, 7, '2024-02-14T10:00:00', '2024-02-14T12:45:00', '2024-02-16T17:30:00', '2024-02-15T14:45:00', N'Graduación', N'Web', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 58.50),
    (52, 7, '2024-02-17T16:10:00', '2024-02-18T12:15:00', '2024-02-21T17:30:00', '2024-02-21T14:00:00', N'Fiesta de gala', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 80),
    (18, 7, '2024-02-18T15:15:00', '2024-02-18T17:15:00', '2024-02-21T17:30:00', '2024-02-21T12:45:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 265),
    (19, 3, '2024-03-05T10:45:00', '2024-03-07T10:00:00', '2024-03-12T17:30:00', '2024-03-12T16:15:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 260),
    (21, 2, '2024-03-17T14:50:00', '2024-03-19T15:45:00', '2024-03-22T17:30:00', '2024-03-22T09:15:00', N'Fiesta de gala', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por rasgado', 70),
    (26, 6, '2024-03-23T11:40:00', '2024-03-25T12:15:00', '2024-03-27T17:30:00', '2024-03-27T11:00:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 185),
    (2, 6, '2024-03-26T16:10:00', '2024-03-28T12:15:00', '2024-04-01T17:30:00', '2024-04-01T11:00:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 90),
    (13, 2, '2024-03-28T13:00:00', '2024-03-30T14:30:00', '2024-04-01T17:30:00', '2024-04-03T13:30:00', N'Evento corporativo', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 184.50),
    (13, 4, '2024-04-03T10:10:00', '2024-04-04T15:30:00', '2024-04-06T17:30:00', '2024-04-06T11:45:00', N'Ceremonia familiar', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 255),
    (26, 6, '2024-04-04T09:45:00', '2024-04-04T11:15:00', '2024-04-06T17:30:00', '2024-04-06T11:45:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 120),
    (32, 2, '2024-04-04T08:10:00', '2024-04-06T09:45:00', '2024-04-11T17:30:00', '2024-04-10T11:45:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por rasgado', 55),
    (8, 7, '2024-04-13T08:45:00', '2024-04-14T15:00:00', '2024-04-19T17:30:00', '2024-04-20T09:15:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 120),
    (43, 2, '2024-04-22T13:50:00', '2024-04-24T11:15:00', '2024-04-27T17:30:00', '2024-04-27T11:30:00', N'Sesión fotográfica', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por manchado', 62.25),
    (64, 7, '2024-04-28T09:20:00', '2024-04-29T14:45:00', '2024-05-04T17:30:00', '2024-05-03T10:30:00', N'Graduación', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 120),
    (64, 4, '2024-05-01T15:00:00', '2024-05-03T15:45:00', '2024-05-06T17:30:00', '2024-05-06T16:15:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 180),
    (11, 2, '2024-05-05T16:50:00', '2024-05-05T16:50:00', '2024-05-07T17:30:00', '2024-05-07T14:30:00', N'Evento corporativo', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 345.25),
    (26, 4, '2024-05-12T10:30:00', '2024-05-14T10:00:00', '2024-05-17T17:30:00', '2024-05-17T11:30:00', N'Quinceañero', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por rasgado', 275),
    (53, 7, '2024-05-17T08:50:00', '2024-05-19T13:00:00', '2024-05-24T17:30:00', '2024-05-28T10:00:00', N'Matrimonio', N'Instagram', N'Devuelto', N'Devolución registrada: fuera de plazo; incidencia por manchado', 150),
    (32, 4, '2024-05-18T15:15:00', '2024-05-20T11:30:00', '2024-05-22T17:30:00', '2024-05-22T13:45:00', N'Evento corporativo', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por manchado', 240.75),
    (28, 6, '2024-05-29T14:40:00', '2024-05-31T12:30:00', '2024-06-04T17:30:00', '2024-06-04T15:30:00', N'Fiesta de gala', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 150),
    (50, 2, '2024-05-29T15:40:00', '2024-05-31T13:45:00', '2024-06-04T17:30:00', '2024-06-04T10:00:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 190),
    (10, 2, '2024-06-02T16:10:00', '2024-06-02T16:10:00', '2024-06-07T17:30:00', '2024-06-08T11:15:00', N'Fiesta de gala', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 55),
    (8, 6, '2024-06-03T16:00:00', '2024-06-04T13:15:00', '2024-06-07T17:30:00', '2024-06-08T12:30:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 175),
    (25, 6, '2024-06-05T16:50:00', '2024-06-07T09:15:00', '2024-06-10T17:30:00', '2024-06-11T10:15:00', N'Evento corporativo', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 145),
    (51, 4, '2024-06-08T10:10:00', '2024-06-09T15:00:00', '2024-06-12T17:30:00', '2024-06-13T12:30:00', N'Matrimonio', N'Instagram', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 164.75),
    (1, 4, '2024-06-14T14:50:00', '2024-06-15T15:15:00', '2024-06-18T17:30:00', '2024-06-19T14:00:00', N'Evento corporativo', N'WhatsApp', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 85.50),
    (63, 7, '2024-06-14T12:30:00', '2024-06-14T13:00:00', '2024-06-17T17:30:00', '2024-06-17T10:00:00', N'Sesión fotográfica', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 250),
    (52, 4, '2024-06-23T14:50:00', '2024-06-24T13:45:00', '2024-06-27T17:30:00', '2024-06-27T10:30:00', N'Quinceañero', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 255),
    (8, 2, '2024-07-03T08:45:00', '2024-07-03T09:45:00', '2024-07-07T17:30:00', '2024-07-07T10:30:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 70),
    (14, 3, '2024-07-04T16:45:00', '2024-07-06T15:45:00', '2024-07-11T17:30:00', '2024-07-11T13:15:00', N'Sesión fotográfica', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 120),
    (64, 4, '2024-07-14T14:00:00', '2024-07-14T16:15:00', '2024-07-18T17:30:00', '2024-07-18T11:45:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 255),
    (71, 7, '2024-07-17T16:50:00', '2024-07-17T16:50:00', '2024-07-20T17:30:00', '2024-07-21T09:00:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; incidencia por rasgado', 52.25),
    (9, 6, '2024-07-19T08:50:00', '2024-07-20T11:00:00', '2024-07-23T17:30:00', '2024-07-26T09:30:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 185),
    (13, 6, '2024-07-25T12:30:00', '2024-07-27T09:00:00', '2024-07-30T17:30:00', '2024-07-29T14:45:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 310),
    (73, 7, '2024-07-29T10:20:00', '2024-07-31T11:30:00', '2024-08-03T17:30:00', '2024-08-03T15:00:00', N'Graduación', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por manchado', 205.50),
    (8, 6, '2024-07-30T13:15:00', '2024-07-30T17:00:00', '2024-08-01T17:30:00', '2024-08-01T13:00:00', N'Quinceañero', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 110),
    (39, 3, '2024-08-10T08:20:00', '2024-08-10T11:00:00', '2024-08-14T17:30:00', '2024-08-14T10:15:00', N'Evento corporativo', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 145),
    (13, 6, '2024-08-12T09:40:00', '2024-08-13T12:45:00', '2024-08-15T17:30:00', '2024-08-15T09:30:00', N'Fiesta de gala', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 185),
    (58, 4, '2024-08-23T12:50:00', '2024-08-24T09:30:00', '2024-08-26T17:30:00', '2024-08-26T12:45:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por manchado', 214.25),
    (3, 7, '2024-08-31T11:10:00', '2024-09-01T11:45:00', '2024-09-06T17:30:00', '2024-09-07T09:00:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 190),
    (20, 7, '2024-09-15T15:20:00', '2024-09-16T12:00:00', '2024-09-18T17:30:00', '2024-09-18T14:15:00', N'Fiesta de gala', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 260),
    (4, 6, '2024-09-20T16:15:00', '2024-09-21T12:45:00', '2024-09-23T17:30:00', '2024-09-23T13:45:00', N'Evento corporativo', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por rasgado', 115),
    (40, 6, '2024-09-22T12:15:00', '2024-09-22T13:30:00', '2024-09-25T17:30:00', '2024-09-25T09:15:00', N'Fiesta de gala', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 258.00),
    (58, 7, '2024-09-23T12:10:00', '2024-09-25T15:30:00', '2024-09-29T17:30:00', '2024-10-01T14:15:00', N'Evento corporativo', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 160),
    (13, 4, '2024-09-24T10:10:00', '2024-09-25T11:15:00', '2024-09-28T17:30:00', '2024-09-29T15:00:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 145),
    (41, 4, '2024-09-29T17:30:00', '2024-09-30T10:45:00', '2024-10-03T17:30:00', '2024-10-02T11:00:00', N'Fiesta de gala', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 415),
    (40, 7, '2024-09-29T15:20:00', '2024-09-29T16:15:00', '2024-10-02T17:30:00', '2024-10-02T13:00:00', N'Ceremonia familiar', N'Web', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 380.75),
    (53, 2, '2024-09-30T17:20:00', '2024-10-01T13:30:00', '2024-10-03T17:30:00', '2024-10-07T11:15:00', N'Fiesta de gala', N'WhatsApp', N'Devuelto', N'Devolución registrada: fuera de plazo; incidencia por manchado', 264.00),
    (75, 3, '2024-10-09T12:10:00', '2024-10-10T15:15:00', '2024-10-14T17:30:00', '2024-10-14T11:00:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 175),
    (1, 2, '2024-10-16T14:50:00', '2024-10-17T14:00:00', '2024-10-21T17:30:00', '2024-10-21T14:45:00', N'Graduación', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 120),
    (71, 6, '2024-10-18T17:20:00', '2024-10-18T17:20:00', '2024-10-21T17:30:00', '2024-10-22T10:45:00', N'Quinceañero', N'WhatsApp', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 175),
    (38, 7, '2024-10-31T10:50:00', '2024-11-02T09:15:00', '2024-11-05T17:30:00', '2024-11-08T14:15:00', N'Ceremonia familiar', N'Instagram', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 55),
    (50, 7, '2024-11-02T08:45:00', '2024-11-03T09:45:00', '2024-11-08T17:30:00', '2024-11-08T11:00:00', N'Evento corporativo', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 70),
    (49, 2, '2024-11-04T15:40:00', '2024-11-06T10:45:00', '2024-11-08T17:30:00', '2024-11-08T15:15:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 151),
    (5, 6, '2024-11-07T10:40:00', '2024-11-08T15:30:00', '2024-11-11T17:30:00', '2024-11-13T15:15:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 55),
    (61, 4, '2024-11-13T09:40:00', '2024-11-14T14:45:00', '2024-11-19T17:30:00', '2024-11-19T11:30:00', N'Quinceañero', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 125),
    (29, 6, '2024-11-21T12:50:00', '2024-11-22T14:45:00', '2024-11-26T17:30:00', '2024-11-26T11:45:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 115),
    (49, 6, '2024-11-22T15:30:00', '2024-11-22T16:00:00', '2024-11-25T17:30:00', '2024-11-25T12:30:00', N'Evento corporativo', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por rasgado', 155),
    (57, 4, '2024-11-24T08:45:00', '2024-11-26T09:45:00', '2024-11-28T17:30:00', '2024-11-29T14:15:00', N'Quinceañero', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; incidencia por manchado', 52.25),
    (7, 7, '2024-12-04T11:00:00', '2024-12-06T09:00:00', '2024-12-09T17:30:00', '2024-12-11T16:30:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 194.75),
    (10, 7, '2024-12-11T16:00:00', '2024-12-11T16:00:00', '2024-12-14T17:30:00', '2024-12-14T15:30:00', N'Evento corporativo', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 190),
    (57, 7, '2025-01-10T16:00:00', '2025-01-11T10:15:00', '2025-01-16T17:30:00', '2025-01-16T12:30:00', N'Graduación', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por dañado', 209.50),
    (56, 2, '2025-01-10T12:10:00', '2025-01-10T17:45:00', '2025-01-13T17:30:00', '2025-01-12T13:15:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 120),
    (31, 2, '2025-01-10T08:45:00', '2025-01-10T11:15:00', '2025-01-14T17:30:00', '2025-01-14T13:45:00', N'Ceremonia familiar', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 231.50),
    (4, 6, '2025-01-19T08:45:00', '2025-01-21T13:30:00', '2025-01-24T17:30:00', '2025-01-24T12:30:00', N'Fiesta de gala', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 109.25),
    (15, 7, '2025-01-21T11:30:00', '2025-01-21T13:15:00', '2025-01-26T17:30:00', '2025-01-26T14:15:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por rasgado', 145),
    (56, 2, '2025-01-21T13:15:00', '2025-01-22T10:15:00', '2025-01-25T17:30:00', '2025-01-25T11:15:00', N'Fiesta de gala', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por manchado', 335),
    (72, 6, '2025-01-22T16:15:00', '2025-01-24T12:30:00', '2025-01-27T17:30:00', '2025-01-27T16:45:00', N'Evento corporativo', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 277.00),
    (2, 6, '2025-01-27T08:00:00', '2025-01-29T15:00:00', '2025-01-31T17:30:00', '2025-01-31T12:00:00', N'Matrimonio', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 229.50),
    (41, 3, '2025-02-05T13:45:00', '2025-02-07T10:00:00', '2025-02-09T17:30:00', '2025-02-09T15:45:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 182),
    (11, 4, '2025-02-06T10:20:00', '2025-02-07T10:45:00', '2025-02-10T17:30:00', '2025-02-10T14:00:00', N'Sesión fotográfica', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 65),
    (60, 7, '2025-02-06T16:50:00', '2025-02-06T16:50:00', '2025-02-09T17:30:00', '2025-02-09T12:00:00', N'Sesión fotográfica', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 290),
    (12, 3, '2025-02-07T14:45:00', '2025-02-09T10:15:00', '2025-02-12T17:30:00', '2025-02-14T09:00:00', N'Ceremonia familiar', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; incidencia por dañado', 185),
    (30, 6, '2025-02-09T09:00:00', '2025-02-09T17:00:00', '2025-02-14T17:30:00', '2025-02-14T15:30:00', N'Fiesta de gala', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por manchado', 180),
    (70, 7, '2025-02-16T12:15:00', '2025-02-18T13:30:00', '2025-02-20T17:30:00', '2025-02-20T11:15:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 190),
    (52, 4, '2025-03-01T13:45:00', '2025-03-03T13:00:00', '2025-03-06T17:30:00', '2025-03-06T11:45:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 390),
    (71, 3, '2025-03-09T12:45:00', '2025-03-10T12:00:00', '2025-03-13T17:30:00', '2025-03-13T09:45:00', N'Graduación', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 55),
    (70, 2, '2025-03-13T08:40:00', '2025-03-15T11:00:00', '2025-03-18T17:30:00', '2025-03-18T13:30:00', N'Matrimonio', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 155),
    (4, 6, '2025-03-13T17:00:00', '2025-03-15T12:45:00', '2025-03-18T17:30:00', '2025-03-18T09:30:00', N'Ceremonia familiar', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por manchado', 120),
    (37, 4, '2025-03-20T09:15:00', '2025-03-22T13:45:00', '2025-03-24T17:30:00', '2025-03-24T13:45:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 115),
    (54, 7, '2025-04-04T12:50:00', '2025-04-05T11:00:00', '2025-04-07T17:30:00', '2025-04-07T09:45:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 215),
    (4, 3, '2025-04-09T13:45:00', '2025-04-09T14:00:00', '2025-04-14T17:30:00', '2025-04-17T12:45:00', N'Fiesta de gala', N'Instagram', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 245),
    (9, 2, '2025-04-10T12:00:00', '2025-04-10T13:45:00', '2025-04-15T17:30:00', '2025-04-18T14:00:00', N'Ceremonia familiar', N'WhatsApp', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 325),
    (5, 7, '2025-04-14T09:15:00', '2025-04-16T13:15:00', '2025-04-19T17:30:00', '2025-04-19T09:00:00', N'Evento corporativo', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 215),
    (42, 3, '2025-04-20T13:10:00', '2025-04-20T14:45:00', '2025-04-22T17:30:00', '2025-04-22T12:00:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por rasgado', 193.50),
    (71, 3, '2025-05-02T08:30:00', '2025-05-02T11:30:00', '2025-05-06T17:30:00', '2025-05-08T10:15:00', N'Ceremonia familiar', N'WhatsApp', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 120),
    (11, 2, '2025-05-03T12:50:00', '2025-05-05T09:15:00', '2025-05-09T17:30:00', '2025-05-09T15:15:00', N'Graduación', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por dañado', 475),
    (42, 7, '2025-05-05T16:50:00', '2025-05-05T16:50:00', '2025-05-07T17:30:00', '2025-05-07T09:15:00', N'Evento corporativo', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 215),
    (10, 6, '2025-05-08T15:45:00', '2025-05-08T16:45:00', '2025-05-12T17:30:00', '2025-05-12T09:00:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 221.50),
    (40, 4, '2025-05-21T13:45:00', '2025-05-22T14:15:00', '2025-05-25T17:30:00', '2025-05-27T10:00:00', N'Sesión fotográfica', N'Instagram', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 147),
    (54, 3, '2025-05-30T14:30:00', '2025-05-30T16:30:00', '2025-06-01T17:30:00', '2025-06-01T11:00:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 227.25),
    (6, 7, '2025-06-03T10:50:00', '2025-06-03T15:15:00', '2025-06-08T17:30:00', '2025-06-08T11:30:00', N'Graduación', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 180.50),
    (34, 7, '2025-06-18T08:00:00', '2025-06-18T10:00:00', '2025-06-21T17:30:00', '2025-06-21T12:15:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 175.75),
    (78, 3, '2025-06-19T13:10:00', '2025-06-19T14:00:00', '2025-06-24T17:30:00', '2025-06-24T10:15:00', N'Fiesta de gala', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 171.00),
    (57, 3, '2025-06-25T16:10:00', '2025-06-27T13:30:00', '2025-06-30T17:30:00', '2025-06-30T10:30:00', N'Quinceañero', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 225),
    (68, 2, '2025-06-28T17:50:00', '2025-06-30T14:15:00', '2025-07-04T17:30:00', '2025-07-04T14:15:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 150),
    (68, 7, '2025-06-30T15:10:00', '2025-07-01T11:30:00', '2025-07-06T17:30:00', '2025-07-10T10:45:00', N'Fiesta de gala', N'Web', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 65),
    (56, 7, '2025-07-03T10:10:00', '2025-07-03T11:00:00', '2025-07-06T17:30:00', '2025-07-06T09:00:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por manchado', 66.50),
    (4, 2, '2025-07-13T17:10:00', '2025-07-13T17:10:00', '2025-07-17T17:30:00', '2025-07-17T14:30:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por dañado', 199.50),
    (22, 2, '2025-07-13T08:40:00', '2025-07-13T14:15:00', '2025-07-16T17:30:00', '2025-07-16T10:15:00', N'Evento corporativo', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 325),
    (76, 3, '2025-07-15T09:30:00', '2025-07-15T15:00:00', '2025-07-17T17:30:00', '2025-07-17T09:15:00', N'Evento corporativo', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 290),
    (43, 4, '2025-07-17T13:40:00', '2025-07-17T17:15:00', '2025-07-21T17:30:00', '2025-07-23T11:00:00', N'Graduación', N'Instagram', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 250),
    (63, 3, '2025-07-24T15:10:00', '2025-07-24T17:45:00', '2025-07-27T17:30:00', '2025-07-27T16:00:00', N'Fiesta de gala', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 140),
    (20, 3, '2025-07-27T10:15:00', '2025-07-28T14:45:00', '2025-07-30T17:30:00', '2025-07-30T16:15:00', N'Sesión fotográfica', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 52.25),
    (2, 3, '2025-08-02T11:10:00', '2025-08-03T11:00:00', '2025-08-07T17:30:00', '2025-08-08T13:00:00', N'Quinceañero', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; incidencia por manchado', 120),
    (52, 4, '2025-08-06T12:30:00', '2025-08-07T11:45:00', '2025-08-11T17:30:00', '2025-08-11T11:45:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 230),
    (21, 2, '2025-08-07T08:00:00', '2025-08-07T14:30:00', '2025-08-11T17:30:00', '2025-08-11T09:45:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 245),
    (36, 4, '2025-08-11T14:10:00', '2025-08-11T16:30:00', '2025-08-14T17:30:00', '2025-08-14T15:30:00', N'Graduación', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 190),
    (19, 7, '2025-08-15T08:40:00', '2025-08-16T14:00:00', '2025-08-20T17:30:00', '2025-08-20T15:15:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 150),
    (64, 7, '2025-08-18T15:40:00', '2025-08-20T15:30:00', '2025-08-25T17:30:00', '2025-08-26T09:45:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 230),
    (23, 6, '2025-08-22T14:10:00', '2025-08-22T17:15:00', '2025-08-24T17:30:00', '2025-08-25T15:30:00', N'Quinceañero', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 194.75),
    (56, 3, '2025-08-22T17:10:00', '2025-08-22T17:10:00', '2025-08-24T17:30:00', '2025-08-24T10:30:00', N'Fiesta de gala', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por manchado', 265),
    (4, 4, '2025-08-30T10:45:00', '2025-08-30T14:15:00', '2025-09-03T17:30:00', '2025-09-04T13:00:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 49.50),
    (72, 7, '2025-09-05T12:15:00', '2025-09-06T15:15:00', '2025-09-09T17:30:00', '2025-09-09T15:45:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por dañado', 452.50),
    (20, 6, '2025-09-06T08:50:00', '2025-09-07T15:30:00', '2025-09-11T17:30:00', '2025-09-11T09:45:00', N'Graduación', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 144.00),
    (38, 4, '2025-09-08T09:50:00', '2025-09-10T11:30:00', '2025-09-12T17:30:00', '2025-09-14T14:30:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 160),
    (32, 3, '2025-09-12T11:45:00', '2025-09-12T14:30:00', '2025-09-15T17:30:00', '2025-09-15T15:00:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 190),
    (37, 6, '2025-09-17T17:45:00', '2025-09-17T17:45:00', '2025-09-21T17:30:00', '2025-09-22T15:30:00', N'Fiesta de gala', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 114.00),
    (76, 3, '2025-09-18T14:30:00', '2025-09-19T11:00:00', '2025-09-22T17:30:00', '2025-09-22T11:15:00', N'Evento corporativo', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 280),
    (75, 3, '2025-09-18T16:20:00', '2025-09-18T16:20:00', '2025-09-21T17:30:00', '2025-09-21T11:30:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por rasgado', 135.00),
    (76, 6, '2025-09-19T16:45:00', '2025-09-21T13:45:00', '2025-09-26T17:30:00', '2025-09-27T14:15:00', N'Graduación', N'WhatsApp', N'Devuelto', N'Devolución registrada: fuera de plazo; incidencia por manchado', 180),
    (30, 6, '2025-09-25T11:00:00', '2025-09-26T11:15:00', '2025-09-29T17:30:00', '2025-09-29T15:00:00', N'Quinceañero', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 139.50),
    (6, 4, '2025-10-01T16:20:00', '2025-10-02T11:00:00', '2025-10-04T17:30:00', '2025-10-03T09:15:00', N'Fiesta de gala', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 105),
    (70, 6, '2025-10-06T11:00:00', '2025-10-07T14:30:00', '2025-10-10T17:30:00', '2025-10-10T13:45:00', N'Fiesta de gala', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 126.25),
    (25, 3, '2025-10-07T14:45:00', '2025-10-07T15:30:00', '2025-10-11T17:30:00', '2025-10-11T11:00:00', N'Ceremonia familiar', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por manchado', 245.50),
    (12, 2, '2025-10-07T11:15:00', '2025-10-09T12:30:00', '2025-10-12T17:30:00', '2025-10-12T16:15:00', N'Fiesta de gala', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 255.00),
    (43, 3, '2025-10-09T13:00:00', '2025-10-09T15:30:00', '2025-10-12T17:30:00', '2025-10-12T15:00:00', N'Graduación', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 109.25),
    (52, 4, '2025-10-09T17:20:00', '2025-10-09T17:20:00', '2025-10-13T17:30:00', '2025-10-12T11:00:00', N'Quinceañero', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por dañado', 333.25),
    (36, 6, '2025-10-10T11:10:00', '2025-10-12T12:45:00', '2025-10-16T17:30:00', '2025-10-16T16:45:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 135.00),
    (59, 4, '2025-10-10T13:10:00', '2025-10-12T13:00:00', '2025-10-14T17:30:00', '2025-10-17T13:45:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; incidencia por dañado', 235),
    (63, 6, '2025-10-12T14:10:00', '2025-10-12T16:45:00', '2025-10-15T17:30:00', '2025-10-18T13:30:00', N'Quinceañero', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 225),
    (23, 7, '2025-10-15T15:15:00', '2025-10-16T11:45:00', '2025-10-18T17:30:00', '2025-10-18T10:45:00', N'Fiesta de gala', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 345),
    (28, 3, '2025-10-21T11:50:00', '2025-10-21T16:45:00', '2025-10-23T17:30:00', '2025-10-23T15:15:00', N'Evento corporativo', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 321.75),
    (2, 3, '2025-10-23T15:15:00', '2025-10-23T16:15:00', '2025-10-27T17:30:00', '2025-10-28T12:45:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 65),
    (90, 4, '2025-10-24T10:15:00', '2025-10-26T12:00:00', '2025-10-29T17:30:00', '2025-10-29T11:45:00', N'Ceremonia familiar', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 55),
    (49, 2, '2025-10-31T15:00:00', '2025-10-31T16:45:00', '2025-11-03T17:30:00', '2025-11-03T11:15:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 150),
    (55, 3, '2025-11-20T09:00:00', '2025-11-20T13:00:00', '2025-11-23T17:30:00', '2025-11-23T13:45:00', N'Graduación', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 65),
    (76, 3, '2025-11-21T11:00:00', '2025-11-22T14:00:00', '2025-11-24T17:30:00', '2025-11-26T09:45:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 194.75),
    (75, 6, '2025-11-21T09:30:00', '2025-11-22T12:00:00', '2025-11-26T17:30:00', '2025-11-26T11:45:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 215),
    (24, 2, '2025-11-24T10:00:00', '2025-11-26T11:45:00', '2025-12-01T17:30:00', '2025-12-01T11:15:00', N'Sesión fotográfica', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por rasgado', 170),
    (39, 2, '2025-11-27T11:10:00', '2025-11-28T14:15:00', '2025-12-01T17:30:00', '2025-12-01T11:30:00', N'Fiesta de gala', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 125);
GO

INSERT INTO dbo.Alquiler (idCliente, idTrabajador, fechaAlquiler, fechaEntrega, fechaDevolucionProgramada, fechaDevolucionReal, tipoEvento, canalReserva, estado, observacion, total) VALUES
    (52, 3, '2025-11-28T11:15:00', '2025-11-29T09:30:00', '2025-12-02T17:30:00', '2025-12-03T16:15:00', N'Matrimonio', N'Web', N'Devuelto', N'Devolución registrada: fuera de plazo; incidencia por rasgado', 140),
    (63, 7, '2025-11-28T15:30:00', '2025-11-29T14:15:00', '2025-12-02T17:30:00', '2025-12-03T10:15:00', N'Fiesta de gala', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 380),
    (37, 4, '2025-12-05T13:20:00', '2025-12-07T13:00:00', '2025-12-10T17:30:00', '2025-12-10T09:30:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por manchado', 125),
    (54, 2, '2025-12-08T13:10:00', '2025-12-08T15:00:00', '2025-12-10T17:30:00', '2025-12-11T14:00:00', N'Quinceañero', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 232.50),
    (11, 3, '2025-12-09T17:50:00', '2025-12-11T10:00:00', '2025-12-14T17:30:00', '2025-12-14T13:45:00', N'Sesión fotográfica', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 215),
    (39, 2, '2025-12-11T16:40:00', '2025-12-11T16:40:00', '2025-12-13T17:30:00', '2025-12-13T14:45:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 220),
    (10, 3, '2025-12-17T13:30:00', '2025-12-19T15:30:00', '2025-12-24T17:30:00', '2025-12-24T11:00:00', N'Quinceañero', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 420.50),
    (41, 3, '2025-12-22T17:50:00', '2025-12-24T10:00:00', '2025-12-26T17:30:00', '2025-12-26T09:45:00', N'Sesión fotográfica', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 24),
    (15, 4, '2026-01-13T13:50:00', '2026-01-15T10:30:00', '2026-01-20T17:30:00', '2026-01-20T11:45:00', N'Quinceañero', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 115),
    (23, 4, '2026-01-18T08:00:00', '2026-01-18T16:30:00', '2026-01-22T17:30:00', '2026-01-22T12:30:00', N'Graduación', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 180),
    (13, 7, '2026-01-22T17:15:00', '2026-01-24T15:30:00', '2026-01-27T17:30:00', '2026-01-27T15:45:00', N'Graduación', N'Web', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 175),
    (81, 7, '2026-01-22T10:00:00', '2026-01-24T13:45:00', '2026-01-27T17:30:00', '2026-01-27T10:15:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 253.00),
    (54, 6, '2026-01-26T10:00:00', '2026-01-26T16:15:00', '2026-01-28T17:30:00', '2026-01-28T14:15:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 180),
    (2, 2, '2026-01-27T11:40:00', '2026-01-27T14:15:00', '2026-01-31T17:30:00', '2026-01-31T16:30:00', N'Sesión fotográfica', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 180),
    (65, 7, '2026-01-27T09:10:00', '2026-01-29T11:45:00', '2026-02-01T17:30:00', '2026-02-01T09:45:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 355),
    (37, 7, '2026-01-30T08:50:00', '2026-01-30T13:30:00', '2026-02-02T17:30:00', '2026-02-02T10:45:00', N'Evento corporativo', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por dañado', 70),
    (8, 6, '2026-02-03T13:50:00', '2026-02-04T11:15:00', '2026-02-09T17:30:00', '2026-02-09T10:00:00', N'Matrimonio', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por dañado', 180),
    (64, 3, '2026-02-09T12:40:00', '2026-02-09T15:30:00', '2026-02-12T17:30:00', '2026-02-16T13:45:00', N'Ceremonia familiar', N'WhatsApp', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 355),
    (43, 2, '2026-02-15T10:10:00', '2026-02-15T16:30:00', '2026-02-19T17:30:00', '2026-02-20T13:00:00', N'Graduación', N'WhatsApp', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 140),
    (11, 3, '2026-02-16T11:00:00', '2026-02-18T12:30:00', '2026-02-21T17:30:00', '2026-02-21T13:30:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 215),
    (48, 4, '2026-02-19T13:00:00', '2026-02-19T16:30:00', '2026-02-23T17:30:00', '2026-02-23T11:30:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 323.75),
    (26, 6, '2026-02-22T12:10:00', '2026-02-22T16:00:00', '2026-02-25T17:30:00', '2026-02-25T13:45:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 376.25),
    (43, 3, '2026-02-23T08:10:00', '2026-02-23T15:30:00', '2026-02-28T17:30:00', '2026-02-28T12:00:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 135),
    (38, 4, '2026-02-28T17:00:00', '2026-02-28T17:00:00', '2026-03-02T17:30:00', '2026-03-05T13:45:00', N'Fiesta de gala', N'Instagram', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 206.50),
    (48, 6, '2026-03-04T13:40:00', '2026-03-06T12:00:00', '2026-03-09T17:30:00', '2026-03-09T12:30:00', N'Ceremonia familiar', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por manchado', 205),
    (38, 3, '2026-03-07T13:50:00', '2026-03-07T17:00:00', '2026-03-10T17:30:00', '2026-03-10T14:00:00', N'Evento corporativo', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 104.50),
    (68, 6, '2026-03-23T15:50:00', '2026-03-25T09:30:00', '2026-03-28T17:30:00', '2026-03-28T10:30:00', N'Evento corporativo', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 99.75),
    (46, 6, '2026-03-27T12:40:00', '2026-03-27T13:15:00', '2026-03-31T17:30:00', '2026-03-31T14:15:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 260),
    (17, 2, '2026-03-30T08:10:00', '2026-03-30T17:45:00', '2026-04-02T17:30:00', '2026-04-03T16:00:00', N'Graduación', N'WhatsApp', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 205),
    (64, 6, '2026-04-06T13:45:00', '2026-04-07T09:30:00', '2026-04-12T17:30:00', '2026-04-12T14:15:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 6),
    (73, 6, '2026-04-15T11:50:00', '2026-04-17T10:00:00', '2026-04-21T17:30:00', '2026-04-21T15:15:00', N'Quinceañero', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 114.00),
    (26, 2, '2026-04-17T11:10:00', '2026-04-18T15:15:00', '2026-04-22T17:30:00', '2026-04-22T09:30:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 292.00),
    (2, 2, '2026-04-25T11:15:00', '2026-04-26T11:30:00', '2026-04-28T17:30:00', '2026-04-28T14:45:00', N'Sesión fotográfica', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 65),
    (76, 3, '2026-04-26T10:15:00', '2026-04-27T13:00:00', '2026-05-01T17:30:00', '2026-05-01T15:00:00', N'Fiesta de gala', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 99.75),
    (43, 4, '2026-04-28T16:45:00', '2026-04-30T15:15:00', '2026-05-03T17:30:00', '2026-05-03T15:30:00', N'Matrimonio', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 208),
    (73, 4, '2026-04-30T08:50:00', '2026-05-01T13:45:00', '2026-05-04T17:30:00', '2026-05-04T13:45:00', N'Quinceañero', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 150),
    (1, 6, '2026-05-02T14:40:00', '2026-05-03T12:15:00', '2026-05-06T17:30:00', '2026-05-06T12:30:00', N'Quinceañero', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por dañado', 340),
    (3, 7, '2026-05-04T09:50:00', '2026-05-05T11:15:00', '2026-05-08T17:30:00', '2026-05-08T14:30:00', N'Ceremonia familiar', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 194.75),
    (24, 2, '2026-05-12T10:00:00', '2026-05-14T12:15:00', '2026-05-18T17:30:00', '2026-05-18T14:45:00', N'Fiesta de gala', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por rasgado', 240),
    (12, 3, '2026-05-22T13:10:00', '2026-05-22T17:00:00', '2026-05-26T17:30:00', '2026-05-29T09:00:00', N'Sesión fotográfica', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 250),
    (65, 7, '2026-05-24T15:00:00', '2026-05-24T17:45:00', '2026-05-27T17:30:00', '2026-05-27T14:15:00', N'Evento corporativo', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 112.50),
    (53, 4, '2026-05-28T09:40:00', '2026-05-30T10:00:00', '2026-06-03T17:30:00', '2026-06-03T13:00:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 125),
    (2, 7, '2026-05-31T13:50:00', '2026-06-01T15:00:00', '2026-06-05T17:30:00', '2026-06-05T14:00:00', N'Fiesta de gala', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 243.75),
    (43, 7, '2026-06-02T16:15:00', '2026-06-04T11:15:00', '2026-06-09T17:30:00', '2026-06-09T14:00:00', N'Ceremonia familiar', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 55),
    (57, 7, '2026-06-16T09:50:00', '2026-06-16T17:00:00', '2026-06-21T17:30:00', '2026-06-21T14:30:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 110),
    (3, 2, '2026-06-16T17:40:00', '2026-06-18T15:30:00', '2026-06-21T17:30:00', '2026-06-21T12:15:00', N'Graduación', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por rasgado', 294.00),
    (63, 4, '2026-06-19T16:15:00', '2026-06-21T15:45:00', '2026-06-25T17:30:00', '2026-06-28T15:45:00', N'Ceremonia familiar', N'Tienda física', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 300),
    (7, 6, '2026-06-20T17:50:00', '2026-06-20T17:50:00', '2026-06-24T17:30:00', '2026-06-24T10:30:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 195),
    (23, 3, '2026-06-24T10:50:00', '2026-06-25T11:00:00', '2026-06-28T17:30:00', '2026-06-28T12:00:00', N'Evento corporativo', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 245),
    (75, 4, '2026-06-27T13:00:00', '2026-06-29T10:30:00', '2026-07-02T17:30:00', '2026-07-03T13:00:00', N'Ceremonia familiar', N'Instagram', N'Devuelto', N'Devolución registrada: fuera de plazo; incidencia por rasgado', 195),
    (28, 7, '2026-06-29T12:40:00', '2026-07-01T11:30:00', '2026-07-05T17:30:00', '2026-07-05T11:15:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 145),
    (87, 7, '2026-06-29T12:00:00', '2026-07-01T09:45:00', '2026-07-05T17:30:00', '2026-07-05T13:45:00', N'Matrimonio', N'Web', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 180.50),
    (13, 7, '2026-07-02T09:10:00', '2026-07-02T14:30:00', '2026-07-07T17:30:00', '2026-07-08T14:30:00', N'Fiesta de gala', N'WhatsApp', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 135),
    (63, 3, '2026-07-06T11:00:00', '2026-07-07T13:15:00', '2026-07-09T17:30:00', '2026-07-09T15:45:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 470),
    (29, 6, '2026-07-06T16:00:00', '2026-07-07T12:15:00', '2026-07-11T17:30:00', '2026-07-11T16:15:00', N'Graduación', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 305),
    (57, 7, '2026-07-07T11:45:00', '2026-07-07T16:15:00', '2026-07-11T17:30:00', '2026-07-11T09:15:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 195),
    (85, 4, '2026-07-09T15:45:00', '2026-07-11T12:15:00', '2026-07-16T17:30:00', '2026-07-16T14:15:00', N'Sesión fotográfica', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por rasgado', 167.50),
    (87, 2, '2026-07-09T15:40:00', '2026-07-09T17:30:00', '2026-07-12T17:30:00', '2026-07-12T10:15:00', N'Evento corporativo', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 61.75),
    (28, 6, '2026-07-12T12:10:00', '2026-07-12T14:00:00', '2026-07-15T17:30:00', '2026-07-15T11:45:00', N'Evento corporativo', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por manchado', 55),
    (50, 6, '2026-07-15T16:45:00', '2026-07-17T13:45:00', '2026-07-22T17:30:00', '2026-07-22T15:45:00', N'Quinceañero', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por manchado', 45),
    (26, 6, '2026-07-20T09:40:00', '2026-07-22T15:00:00', '2026-07-24T17:30:00', '2026-07-25T14:15:00', N'Graduación', N'WhatsApp', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 205),
    (13, 6, '2026-07-21T15:15:00', '2026-07-22T14:45:00', '2026-07-26T17:30:00', '2026-07-26T10:15:00', N'Evento corporativo', N'Web', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 295),
    (68, 6, '2026-07-25T10:30:00', '2026-07-27T10:00:00', '2026-07-31T17:30:00', '2026-07-31T13:15:00', N'Ceremonia familiar', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por manchado', 87.25),
    (60, 2, '2026-07-29T15:20:00', '2026-07-30T09:30:00', '2026-08-01T17:30:00', '2026-08-01T15:00:00', N'Fiesta de gala', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 60),
    (33, 3, '2026-08-02T11:40:00', '2026-08-02T14:00:00', '2026-08-04T17:30:00', '2026-08-04T13:30:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 135),
    (69, 7, '2026-08-02T15:20:00', '2026-08-04T09:00:00', '2026-08-07T17:30:00', '2026-08-07T16:15:00', N'Evento corporativo', N'Web', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por manchado', 180),
    (38, 7, '2026-08-09T08:50:00', '2026-08-10T13:30:00', '2026-08-12T17:30:00', '2026-08-12T09:00:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 180),
    (88, 2, '2026-08-10T11:15:00', '2026-08-10T14:45:00', '2026-08-15T17:30:00', '2026-08-15T16:00:00', N'Evento corporativo', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 168),
    (32, 7, '2026-08-15T15:50:00', '2026-08-17T15:00:00', '2026-08-20T17:30:00', '2026-08-20T09:15:00', N'Fiesta de gala', N'Web', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 172.25),
    (74, 6, '2026-08-19T10:00:00', '2026-08-21T14:00:00', '2026-08-23T17:30:00', '2026-08-23T16:45:00', N'Evento corporativo', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 80),
    (40, 6, '2026-08-21T15:40:00', '2026-08-22T09:30:00', '2026-08-26T17:30:00', '2026-08-26T13:30:00', N'Matrimonio', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 300),
    (14, 7, '2026-08-21T11:45:00', '2026-08-21T14:15:00', '2026-08-26T17:30:00', '2026-08-26T13:00:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 288.75),
    (14, 6, '2026-08-22T15:40:00', '2026-08-24T10:15:00', '2026-08-28T17:30:00', '2026-08-28T14:30:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por manchado', 245),
    (71, 6, '2026-08-26T13:20:00', '2026-08-27T12:30:00', '2026-08-30T17:30:00', '2026-08-31T10:30:00', N'Graduación', N'Instagram', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 340),
    (72, 3, '2026-08-29T17:20:00', '2026-08-30T11:45:00', '2026-09-01T17:30:00', '2026-09-01T11:00:00', N'Fiesta de gala', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 255),
    (56, 4, '2026-09-08T11:45:00', '2026-09-08T16:45:00', '2026-09-11T17:30:00', '2026-09-11T16:15:00', N'Sesión fotográfica', N'WhatsApp', N'Devuelto', N'Devolución registrada: dentro del plazo; incidencia por manchado', 150),
    (84, 6, '2026-09-13T09:00:00', '2026-09-14T14:15:00', '2026-09-16T17:30:00', '2026-09-16T10:30:00', N'Fiesta de gala', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 125),
    (2, 4, '2026-09-20T12:40:00', '2026-09-21T15:00:00', '2026-09-24T17:30:00', '2026-09-24T16:45:00', N'Evento corporativo', N'Instagram', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 185),
    (46, 4, '2026-10-07T17:00:00', '2026-10-09T10:00:00', '2026-10-14T17:30:00', NULL, N'Matrimonio', N'Tienda física', N'Vencido', N'Contrato vencido: devolución aún no registrada', 355),
    (12, 7, '2026-10-08T09:40:00', '2026-10-09T14:30:00', '2026-10-12T17:30:00', '2026-10-13T11:15:00', N'Matrimonio', N'WhatsApp', N'Devuelto', N'Devolución registrada: fuera de plazo; sin daños', 118.75),
    (74, 4, '2026-10-09T10:30:00', '2026-10-12T12:45:00', '2026-10-14T17:30:00', NULL, N'Sesión fotográfica', N'Tienda física', N'Vencido', N'Contrato vencido: devolución aún no registrada', 140),
    (24, 4, '2026-10-10T13:15:00', '2026-10-13T10:45:00', '2026-10-16T17:30:00', NULL, N'Matrimonio', N'Tienda física', N'En curso', N'Prendas por devolver', 190),
    (9, 7, '2026-10-11T10:50:00', '2026-10-12T12:30:00', '2026-10-15T17:30:00', NULL, N'Graduación', N'Tienda física', N'En curso', N'Prendas por devolver', 300),
    (89, 4, '2026-10-11T11:00:00', '2026-10-14T14:00:00', '2026-10-19T17:30:00', NULL, N'Evento corporativo', N'Tienda física', N'En curso', N'Prendas por devolver', 65),
    (71, 7, '2026-10-12T11:15:00', '2026-10-12T13:15:00', '2026-10-15T17:30:00', '2026-10-15T16:15:00', N'Fiesta de gala', N'Tienda física', N'Devuelto', N'Devolución registrada: dentro del plazo; sin daños', 183.25),
    (78, 4, '2026-10-13T09:40:00', '2026-10-15T11:30:00', '2026-10-18T17:30:00', NULL, N'Matrimonio', N'WhatsApp', N'En curso', N'Prendas por devolver', 110),
    (71, 6, '2026-10-13T10:00:00', '2026-10-13T14:45:00', '2026-10-18T17:30:00', NULL, N'Fiesta de gala', N'Tienda física', N'En curso', N'Prendas por devolver', 115),
    (60, 6, '2026-10-14T09:20:00', NULL, '2026-10-20T17:30:00', NULL, N'Matrimonio', N'Tienda física', N'Reservado', N'Entrega por realizar', 218.50),
    (54, 7, '2026-10-14T13:10:00', '2026-10-15T09:30:00', '2026-10-19T17:30:00', NULL, N'Fiesta de gala', N'Tienda física', N'En curso', N'Prendas por devolver', 94.50),
    (13, 4, '2026-10-15T16:20:00', '2026-10-15T16:20:00', '2026-10-17T17:30:00', NULL, N'Matrimonio', N'Tienda física', N'En curso', N'Prendas por devolver', 161.00);
GO

INSERT INTO dbo.DetalleVenta (idVenta, idArticulo, cantidad, precioUnitario, costoUnitario, subtotal) VALUES
    (1, 9, 1, 423.00, 230, 423.00),
    (1, 24, 1, 275, 130, 275),
    (2, 4, 1, 540, 285, 540),
    (2, 21, 1, 295, 145, 295),
    (3, 37, 1, 205, 90, 205),
    (4, 14, 1, 355, 175, 355),
    (5, 42, 1, 195, 88, 195),
    (5, 2, 1, 451.25, 255, 451.25),
    (6, 19, 2, 120, 55, 240),
    (6, 28, 1, 171.00, 85, 171.00),
    (6, 35, 1, 245, 110, 245),
    (7, 28, 1, 171.00, 85, 171.00),
    (8, 32, 1, 55, 22, 55),
    (8, 35, 1, 245, 110, 245),
    (9, 35, 1, 245, 110, 245),
    (9, 7, 1, 560.50, 305, 560.50),
    (9, 10, 1, 490, 240, 490),
    (10, 30, 3, 49, 19, 147),
    (11, 27, 2, 175, 82, 350),
    (12, 3, 1, 530, 280, 530),
    (12, 28, 2, 180, 85, 360),
    (13, 23, 1, 340, 160, 340),
    (13, 14, 1, 337.25, 175, 337.25),
    (14, 18, 3, 104.50, 50, 313.50),
    (14, 4, 1, 513.00, 285, 513.00),
    (15, 1, 1, 460, 245, 460),
    (15, 28, 1, 171.00, 85, 171.00),
    (16, 17, 1, 105, 48, 105),
    (16, 36, 1, 242.25, 115, 242.25),
    (17, 35, 1, 245, 110, 245),
    (18, 13, 1, 301.50, 165, 301.50),
    (19, 45, 1, 370, 175, 370),
    (20, 9, 1, 470, 230, 470),
    (20, 2, 1, 427.50, 255, 427.50),
    (21, 12, 1, 430, 210, 430),
    (21, 44, 1, 395, 190, 395),
    (22, 45, 1, 370, 175, 370),
    (22, 27, 2, 175, 82, 350),
    (23, 37, 1, 205, 90, 205),
    (23, 42, 1, 185.25, 88, 185.25),
    (23, 10, 1, 441.00, 240, 441.00),
    (24, 46, 1, 420, 200, 420),
    (24, 2, 1, 451.25, 255, 451.25),
    (25, 29, 1, 49, 19, 49),
    (26, 30, 1, 49, 19, 49),
    (26, 38, 1, 210, 92, 210),
    (27, 12, 1, 408.50, 210, 408.50),
    (27, 44, 1, 375.25, 190, 375.25),
    (28, 20, 2, 125, 57, 250),
    (29, 24, 1, 275, 130, 275),
    (29, 32, 1, 55, 22, 55),
    (30, 8, 1, 655.50, 345, 655.50),
    (30, 42, 1, 195, 88, 195),
    (31, 43, 1, 385, 185, 385),
    (31, 27, 1, 175, 82, 175),
    (32, 1, 1, 460, 245, 460),
    (32, 39, 1, 230, 105, 230),
    (33, 39, 1, 230, 105, 230),
    (33, 27, 1, 175, 82, 175),
    (34, 25, 1, 137.75, 68, 137.75),
    (34, 29, 1, 49, 19, 49),
    (34, 44, 1, 395, 190, 395),
    (35, 30, 1, 49, 19, 49),
    (35, 32, 1, 55, 22, 55),
    (36, 27, 1, 175, 82, 175),
    (36, 20, 2, 118.75, 57, 237.50),
    (37, 18, 1, 104.50, 50, 104.50),
    (37, 29, 1, 44.10, 19, 44.10),
    (38, 25, 1, 145, 68, 145),
    (38, 44, 1, 395, 190, 395),
    (38, 33, 1, 29, 11, 29),
    (39, 24, 1, 275, 130, 275),
    (40, 27, 2, 175, 82, 350),
    (40, 28, 1, 171.00, 85, 171.00),
    (41, 30, 1, 49, 19, 49),
    (41, 31, 2, 37.05, 15, 74.10),
    (42, 5, 1, 640, 330, 640),
    (42, 31, 1, 39, 15, 39),
    (43, 29, 1, 49, 19, 49),
    (43, 14, 1, 355, 175, 355),
    (44, 17, 1, 99.75, 48, 99.75),
    (44, 34, 1, 75, 32, 75),
    (45, 3, 1, 530, 280, 530),
    (45, 8, 1, 690, 345, 690),
    (46, 2, 1, 451.25, 255, 451.25),
    (47, 42, 1, 185.25, 88, 185.25),
    (48, 5, 1, 640, 330, 640),
    (49, 38, 1, 210, 92, 210),
    (50, 46, 1, 420, 200, 420),
    (51, 27, 1, 175, 82, 175),
    (52, 44, 1, 395, 190, 395),
    (52, 36, 1, 229.50, 115, 229.50),
    (53, 11, 1, 410, 200, 410),
    (53, 26, 1, 147.25, 72, 147.25),
    (53, 4, 1, 540, 285, 540),
    (54, 36, 1, 255, 115, 255),
    (55, 31, 1, 37.05, 15, 37.05),
    (55, 26, 1, 139.50, 72, 139.50),
    (56, 17, 1, 105, 48, 105),
    (56, 25, 1, 145, 68, 145),
    (57, 25, 1, 137.75, 68, 137.75),
    (58, 5, 1, 576.00, 330, 576.00),
    (58, 27, 1, 175, 82, 175),
    (58, 21, 1, 280.25, 145, 280.25),
    (59, 46, 1, 420, 200, 420),
    (59, 37, 1, 194.75, 90, 194.75),
    (60, 28, 1, 180, 85, 180),
    (60, 36, 1, 255, 115, 255),
    (60, 46, 1, 420, 200, 420),
    (61, 19, 1, 120, 55, 120),
    (62, 17, 1, 105, 48, 105),
    (62, 9, 1, 470, 230, 470),
    (63, 30, 3, 46.55, 19, 139.65),
    (64, 39, 1, 230, 105, 230),
    (64, 37, 1, 184.50, 90, 184.50),
    (65, 10, 1, 465.50, 240, 465.50),
    (65, 34, 2, 75, 32, 150),
    (66, 45, 1, 351.50, 175, 351.50),
    (66, 39, 1, 230, 105, 230),
    (67, 3, 1, 530, 280, 530),
    (68, 40, 1, 245, 112, 245),
    (68, 25, 1, 145, 68, 145),
    (69, 8, 1, 690, 345, 690),
    (69, 32, 1, 55, 22, 55),
    (70, 22, 1, 294.50, 150, 294.50),
    (70, 10, 1, 490, 240, 490),
    (71, 21, 1, 295, 145, 295),
    (72, 3, 1, 503.50, 280, 503.50),
    (73, 45, 1, 370, 175, 370),
    (73, 11, 1, 410, 200, 410),
    (74, 18, 1, 110, 50, 110),
    (74, 36, 1, 255, 115, 255),
    (75, 5, 1, 640, 330, 640),
    (75, 39, 1, 207.00, 105, 207.00),
    (76, 34, 2, 75, 32, 150),
    (77, 21, 1, 295, 145, 295),
    (77, 37, 1, 205, 90, 205),
    (77, 13, 1, 335, 165, 335),
    (78, 43, 1, 385, 185, 385),
    (79, 19, 2, 120, 55, 240),
    (80, 41, 1, 190, 85, 190),
    (80, 7, 1, 590, 305, 590),
    (81, 45, 1, 370, 175, 370),
    (82, 46, 1, 420, 200, 420),
    (82, 25, 1, 145, 68, 145),
    (83, 36, 1, 255, 115, 255),
    (84, 6, 1, 660, 340, 660),
    (85, 20, 2, 125, 57, 250),
    (86, 38, 1, 210, 92, 210),
    (86, 32, 3, 52.25, 22, 156.75);
GO

INSERT INTO dbo.DetalleVenta (idVenta, idArticulo, cantidad, precioUnitario, costoUnitario, subtotal) VALUES
    (86, 1, 1, 460, 245, 460),
    (87, 1, 1, 460, 245, 460),
    (87, 12, 1, 430, 210, 430),
    (88, 41, 1, 190, 85, 190),
    (88, 45, 1, 351.50, 175, 351.50),
    (89, 3, 1, 530, 280, 530),
    (89, 38, 1, 210, 92, 210),
    (90, 18, 1, 110, 50, 110),
    (90, 8, 1, 690, 345, 690),
    (91, 20, 1, 112.50, 57, 112.50),
    (92, 26, 2, 155, 72, 310),
    (93, 23, 1, 323.00, 160, 323.00),
    (93, 27, 1, 175, 82, 175),
    (94, 38, 1, 210, 92, 210),
    (94, 19, 2, 120, 55, 240),
    (95, 41, 1, 190, 85, 190),
    (96, 10, 1, 490, 240, 490),
    (96, 29, 1, 49, 19, 49),
    (97, 16, 1, 504.00, 275, 504.00),
    (97, 9, 1, 470, 230, 470),
    (98, 18, 1, 110, 50, 110),
    (98, 34, 1, 67.50, 32, 67.50),
    (99, 11, 1, 389.50, 200, 389.50),
    (100, 7, 1, 590, 305, 590),
    (100, 35, 1, 232.75, 110, 232.75),
    (101, 27, 1, 175, 82, 175),
    (101, 45, 1, 351.50, 175, 351.50),
    (102, 37, 1, 205, 90, 205),
    (103, 13, 1, 318.25, 165, 318.25),
    (103, 23, 1, 340, 160, 340),
    (104, 16, 1, 560, 275, 560),
    (104, 1, 1, 460, 245, 460),
    (105, 44, 1, 395, 190, 395),
    (105, 38, 1, 210, 92, 210),
    (106, 24, 1, 275, 130, 275),
    (107, 17, 1, 105, 48, 105),
    (107, 40, 1, 245, 112, 245),
    (108, 30, 1, 49, 19, 49),
    (108, 6, 1, 660, 340, 660),
    (109, 19, 2, 120, 55, 240),
    (110, 29, 1, 49, 19, 49),
    (111, 30, 2, 49, 19, 98),
    (111, 25, 1, 145, 68, 145),
    (112, 45, 1, 370, 175, 370),
    (113, 5, 1, 640, 330, 640),
    (114, 36, 1, 255, 115, 255),
    (114, 45, 1, 351.50, 175, 351.50),
    (115, 22, 1, 310, 150, 310),
    (115, 46, 1, 420, 200, 420),
    (115, 44, 1, 395, 190, 395),
    (116, 23, 1, 340, 160, 340),
    (117, 19, 1, 120, 55, 120),
    (117, 22, 1, 294.50, 150, 294.50),
    (118, 31, 1, 39, 15, 39),
    (119, 10, 1, 490, 240, 490),
    (120, 45, 1, 370, 175, 370),
    (120, 2, 1, 475, 255, 475),
    (121, 31, 2, 37.05, 15, 74.10),
    (121, 2, 1, 475, 255, 475),
    (121, 39, 1, 230, 105, 230),
    (122, 42, 1, 185.25, 88, 185.25),
    (122, 29, 1, 49, 19, 49),
    (123, 44, 1, 395, 190, 395),
    (124, 34, 1, 67.50, 32, 67.50),
    (125, 35, 1, 232.75, 110, 232.75),
    (126, 4, 1, 540, 285, 540),
    (126, 30, 1, 49, 19, 49),
    (127, 18, 1, 110, 50, 110),
    (127, 37, 1, 194.75, 90, 194.75),
    (128, 2, 1, 475, 255, 475),
    (129, 31, 1, 39, 15, 39),
    (129, 36, 1, 255, 115, 255),
    (130, 34, 2, 75, 32, 150),
    (130, 7, 1, 560.50, 305, 560.50),
    (131, 9, 1, 470, 230, 470),
    (131, 35, 1, 245, 110, 245),
    (132, 46, 1, 420, 200, 420),
    (132, 9, 1, 470, 230, 470),
    (133, 7, 1, 590, 305, 590),
    (134, 30, 1, 46.55, 19, 46.55),
    (134, 25, 1, 145, 68, 145),
    (135, 18, 1, 110, 50, 110),
    (136, 18, 2, 99.00, 50, 198.00),
    (136, 32, 2, 55, 22, 110),
    (137, 45, 1, 370, 175, 370),
    (137, 2, 1, 475, 255, 475),
    (138, 34, 1, 75, 32, 75),
    (138, 38, 1, 189.00, 92, 189.00),
    (139, 21, 1, 295, 145, 295),
    (139, 7, 1, 560.50, 305, 560.50),
    (140, 38, 1, 210, 92, 210),
    (140, 17, 1, 99.75, 48, 99.75),
    (140, 10, 1, 490, 240, 490),
    (141, 39, 1, 207.00, 105, 207.00),
    (141, 27, 1, 157.50, 82, 157.50),
    (142, 34, 1, 75, 32, 75),
    (142, 24, 1, 275, 130, 275),
    (142, 1, 1, 460, 245, 460),
    (143, 14, 1, 355, 175, 355),
    (144, 21, 1, 295, 145, 295),
    (144, 31, 2, 37.05, 15, 74.10),
    (145, 14, 1, 355, 175, 355),
    (145, 33, 1, 27.55, 11, 27.55),
    (145, 25, 1, 130.50, 68, 130.50),
    (146, 37, 1, 194.75, 90, 194.75),
    (146, 38, 1, 199.50, 92, 199.50),
    (147, 41, 1, 180.50, 85, 180.50),
    (147, 24, 1, 261.25, 130, 261.25),
    (148, 43, 1, 385, 185, 385),
    (148, 10, 1, 465.50, 240, 465.50),
    (148, 8, 1, 655.50, 345, 655.50),
    (149, 28, 2, 180, 85, 360),
    (149, 35, 1, 245, 110, 245),
    (150, 25, 1, 145, 68, 145),
    (150, 35, 1, 245, 110, 245),
    (151, 19, 1, 120, 55, 120),
    (151, 46, 1, 420, 200, 420),
    (152, 20, 1, 112.50, 57, 112.50),
    (152, 14, 1, 355, 175, 355),
    (153, 38, 1, 199.50, 92, 199.50),
    (153, 36, 1, 255, 115, 255),
    (154, 2, 1, 451.25, 255, 451.25),
    (155, 35, 1, 245, 110, 245),
    (155, 14, 1, 355, 175, 355),
    (156, 44, 1, 375.25, 190, 375.25),
    (157, 34, 1, 71.25, 32, 71.25),
    (157, 3, 1, 530, 280, 530),
    (158, 31, 1, 39, 15, 39),
    (159, 27, 1, 166.25, 82, 166.25),
    (160, 34, 2, 75, 32, 150),
    (161, 32, 3, 55, 22, 165),
    (161, 43, 1, 385, 185, 385),
    (162, 4, 1, 540, 285, 540),
    (162, 43, 1, 385, 185, 385),
    (163, 19, 2, 120, 55, 240),
    (164, 11, 1, 410, 200, 410),
    (165, 3, 1, 530, 280, 530),
    (165, 1, 1, 460, 245, 460),
    (166, 7, 1, 560.50, 305, 560.50),
    (167, 8, 1, 690, 345, 690),
    (168, 31, 1, 39, 15, 39),
    (168, 27, 2, 175, 82, 350),
    (168, 30, 1, 49, 19, 49),
    (169, 38, 1, 210, 92, 210),
    (169, 39, 1, 230, 105, 230),
    (170, 10, 1, 465.50, 240, 465.50),
    (170, 29, 2, 49, 19, 98),
    (171, 21, 1, 265.50, 145, 265.50),
    (171, 19, 1, 120, 55, 120),
    (172, 24, 1, 247.50, 130, 247.50);
GO

INSERT INTO dbo.DetalleVenta (idVenta, idArticulo, cantidad, precioUnitario, costoUnitario, subtotal) VALUES
    (172, 34, 1, 71.25, 32, 71.25),
    (172, 26, 1, 155, 72, 155),
    (173, 27, 1, 166.25, 82, 166.25),
    (174, 27, 1, 175, 82, 175),
    (174, 36, 1, 255, 115, 255),
    (175, 4, 1, 540, 285, 540),
    (176, 25, 2, 130.50, 68, 261.00),
    (177, 38, 1, 210, 92, 210),
    (178, 44, 1, 395, 190, 395),
    (178, 14, 1, 355, 175, 355),
    (179, 34, 1, 75, 32, 75),
    (180, 21, 1, 295, 145, 295),
    (180, 35, 1, 245, 110, 245),
    (181, 5, 1, 608.00, 330, 608.00),
    (181, 34, 1, 67.50, 32, 67.50),
    (181, 37, 1, 205, 90, 205),
    (182, 8, 1, 690, 345, 690),
    (182, 32, 1, 55, 22, 55),
    (182, 24, 1, 275, 130, 275),
    (183, 24, 1, 261.25, 130, 261.25),
    (184, 33, 1, 29, 11, 29),
    (185, 16, 1, 532.00, 275, 532.00),
    (185, 43, 1, 385, 185, 385);
GO

INSERT INTO dbo.DetalleAlquiler (idAlquiler, idArticulo, cantidad, precioUnitario, subtotal) VALUES
    (1, 39, 1, 65, 65),
    (1, 9, 1, 155, 155),
    (2, 40, 1, 66.50, 66.50),
    (3, 15, 1, 150, 150),
    (4, 3, 1, 145, 145),
    (5, 1, 1, 120, 120),
    (6, 24, 1, 70, 70),
    (6, 22, 1, 72.00, 72.00),
    (7, 16, 1, 180, 180),
    (7, 23, 1, 90, 90),
    (8, 44, 1, 120, 120),
    (9, 42, 1, 52.25, 52.25),
    (10, 39, 1, 58.50, 58.50),
    (11, 22, 1, 80, 80),
    (12, 13, 1, 105, 105),
    (12, 10, 1, 160, 160),
    (13, 6, 1, 190, 190),
    (13, 40, 1, 70, 70),
    (14, 24, 1, 70, 70),
    (15, 2, 1, 125, 125),
    (15, 35, 1, 60, 60),
    (16, 23, 1, 90, 90),
    (17, 8, 1, 184.50, 184.50),
    (18, 12, 1, 140, 140),
    (18, 14, 1, 115, 115),
    (19, 1, 1, 120, 120),
    (20, 37, 1, 55, 55),
    (21, 1, 1, 120, 120),
    (22, 41, 1, 52.25, 52.25),
    (22, 30, 1, 10, 10),
    (23, 41, 1, 55, 55),
    (23, 39, 1, 65, 65),
    (24, 16, 1, 180, 180),
    (25, 2, 1, 112.50, 112.50),
    (25, 37, 1, 52.25, 52.25),
    (25, 6, 1, 180.50, 180.50),
    (26, 4, 1, 150, 150),
    (26, 2, 1, 125, 125),
    (27, 4, 1, 150, 150),
    (28, 39, 1, 65, 65),
    (28, 5, 1, 175.75, 175.75),
    (29, 4, 1, 150, 150),
    (30, 6, 1, 190, 190),
    (31, 42, 1, 55, 55),
    (32, 7, 1, 175, 175),
    (33, 3, 1, 145, 145),
    (34, 13, 1, 99.75, 99.75),
    (34, 39, 1, 65, 65),
    (35, 23, 1, 85.50, 85.50),
    (36, 16, 1, 180, 180),
    (36, 24, 1, 70, 70),
    (37, 4, 1, 150, 150),
    (37, 13, 1, 105, 105),
    (38, 40, 1, 70, 70),
    (39, 1, 1, 120, 120),
    (40, 39, 1, 65, 65),
    (40, 6, 1, 190, 190),
    (41, 37, 1, 52.25, 52.25),
    (42, 44, 1, 120, 120),
    (42, 39, 1, 65, 65),
    (43, 4, 1, 150, 150),
    (43, 10, 1, 160, 160),
    (44, 7, 1, 157.50, 157.50),
    (44, 28, 1, 48, 48),
    (45, 45, 1, 110, 110),
    (46, 3, 1, 145, 145),
    (47, 5, 1, 185, 185),
    (48, 14, 1, 109.25, 109.25),
    (48, 13, 1, 105, 105),
    (49, 6, 1, 190, 190),
    (50, 3, 1, 145, 145),
    (50, 43, 1, 115, 115),
    (51, 14, 1, 115, 115),
    (52, 12, 1, 133.00, 133.00),
    (52, 2, 1, 125, 125),
    (53, 13, 1, 105, 105),
    (53, 37, 1, 55, 55),
    (54, 3, 1, 145, 145),
    (55, 7, 1, 175, 175),
    (55, 14, 1, 115, 115),
    (55, 46, 1, 125, 125),
    (56, 5, 1, 175.75, 175.75),
    (56, 8, 1, 205, 205),
    (57, 1, 1, 114.00, 114.00),
    (57, 15, 1, 150, 150),
    (58, 7, 1, 175, 175),
    (59, 44, 1, 120, 120),
    (60, 7, 1, 175, 175),
    (61, 37, 1, 55, 55),
    (62, 24, 1, 70, 70),
    (63, 3, 1, 145, 145),
    (63, 33, 1, 6, 6),
    (64, 42, 1, 55, 55),
    (65, 2, 1, 125, 125),
    (66, 43, 1, 115, 115),
    (67, 9, 1, 155, 155),
    (68, 41, 1, 52.25, 52.25),
    (69, 8, 1, 194.75, 194.75),
    (70, 6, 1, 190, 190),
    (71, 38, 1, 49.50, 49.50),
    (71, 10, 1, 160, 160),
    (72, 44, 1, 120, 120),
    (73, 45, 1, 110, 110),
    (73, 11, 1, 121.50, 121.50),
    (74, 14, 1, 109.25, 109.25),
    (75, 3, 1, 145, 145),
    (76, 10, 1, 160, 160),
    (76, 7, 1, 175, 175),
    (77, 10, 1, 152.00, 152.00),
    (77, 46, 1, 125, 125),
    (78, 40, 1, 66.50, 66.50),
    (78, 37, 1, 55, 55),
    (78, 1, 1, 108.00, 108.00),
    (79, 15, 1, 150, 150),
    (79, 19, 1, 32, 32),
    (80, 39, 1, 65, 65),
    (81, 46, 1, 125, 125),
    (81, 9, 1, 155, 155),
    (81, 29, 1, 10, 10),
    (82, 5, 1, 185, 185),
    (83, 2, 1, 125, 125),
    (83, 41, 1, 55, 55),
    (84, 6, 1, 190, 190),
    (85, 10, 1, 160, 160),
    (85, 7, 1, 175, 175),
    (85, 41, 1, 55, 55),
    (86, 42, 1, 55, 55),
    (87, 9, 1, 155, 155),
    (88, 1, 1, 120, 120),
    (89, 14, 1, 115, 115),
    (90, 39, 1, 65, 65),
    (90, 4, 1, 150, 150),
    (91, 1, 1, 120, 120),
    (91, 2, 1, 125, 125),
    (92, 7, 1, 175, 175),
    (92, 4, 1, 150, 150),
    (93, 8, 1, 205, 205),
    (93, 30, 1, 10, 10),
    (94, 15, 1, 135.00, 135.00),
    (94, 36, 1, 58.50, 58.50),
    (95, 44, 1, 120, 120),
    (96, 46, 1, 125, 125),
    (96, 3, 1, 145, 145),
    (96, 8, 1, 205, 205),
    (97, 39, 1, 65, 65),
    (97, 15, 1, 150, 150),
    (98, 9, 1, 155, 155),
    (98, 40, 1, 66.50, 66.50),
    (99, 32, 1, 12, 12),
    (99, 11, 1, 135, 135);
GO

INSERT INTO dbo.DetalleAlquiler (idAlquiler, idArticulo, cantidad, precioUnitario, subtotal) VALUES
    (100, 42, 1, 52.25, 52.25),
    (100, 25, 1, 35, 35),
    (100, 12, 1, 140, 140),
    (101, 40, 1, 66.50, 66.50),
    (101, 44, 1, 114.00, 114.00),
    (102, 5, 1, 175.75, 175.75),
    (103, 6, 1, 171.00, 171.00),
    (104, 39, 1, 65, 65),
    (104, 10, 1, 160, 160),
    (105, 4, 1, 150, 150),
    (106, 39, 1, 65, 65),
    (107, 40, 1, 66.50, 66.50),
    (108, 41, 1, 49.50, 49.50),
    (108, 15, 1, 150, 150),
    (109, 12, 1, 140, 140),
    (109, 5, 1, 185, 185),
    (110, 11, 1, 135, 135),
    (110, 9, 1, 155, 155),
    (111, 14, 1, 115, 115),
    (111, 11, 1, 135, 135),
    (112, 12, 1, 140, 140),
    (113, 41, 1, 52.25, 52.25),
    (114, 1, 1, 120, 120),
    (115, 2, 1, 125, 125),
    (115, 13, 1, 105, 105),
    (116, 45, 1, 110, 110),
    (116, 11, 1, 135, 135),
    (117, 6, 1, 190, 190),
    (118, 4, 1, 150, 150),
    (119, 24, 1, 70, 70),
    (119, 10, 1, 160, 160),
    (120, 8, 1, 194.75, 194.75),
    (121, 12, 1, 140, 140),
    (121, 2, 1, 125, 125),
    (122, 42, 1, 49.50, 49.50),
    (123, 10, 1, 160, 160),
    (123, 15, 1, 142.50, 142.50),
    (123, 4, 1, 150, 150),
    (124, 10, 1, 144.00, 144.00),
    (125, 10, 1, 160, 160),
    (126, 45, 1, 110, 110),
    (126, 22, 1, 80, 80),
    (127, 44, 1, 114.00, 114.00),
    (128, 1, 1, 120, 120),
    (128, 10, 1, 160, 160),
    (129, 15, 1, 135.00, 135.00),
    (130, 16, 1, 180, 180),
    (131, 9, 1, 139.50, 139.50),
    (132, 13, 1, 105, 105),
    (133, 38, 1, 55, 55),
    (133, 21, 1, 71.25, 71.25),
    (134, 6, 1, 180.50, 180.50),
    (134, 36, 1, 65, 65),
    (135, 4, 1, 135.00, 135.00),
    (135, 39, 1, 65, 65),
    (135, 41, 1, 55, 55),
    (136, 14, 1, 109.25, 109.25),
    (137, 8, 1, 205, 205),
    (137, 11, 1, 128.25, 128.25),
    (138, 4, 1, 135.00, 135.00),
    (139, 14, 1, 115, 115),
    (139, 44, 1, 120, 120),
    (140, 9, 1, 155, 155),
    (140, 24, 1, 70, 70),
    (141, 5, 1, 185, 185),
    (141, 10, 1, 160, 160),
    (142, 14, 1, 109.25, 109.25),
    (142, 40, 1, 70, 70),
    (142, 15, 1, 142.50, 142.50),
    (143, 39, 1, 65, 65),
    (144, 41, 1, 55, 55),
    (145, 4, 1, 150, 150),
    (146, 39, 1, 65, 65),
    (147, 8, 1, 194.75, 194.75),
    (148, 9, 1, 155, 155),
    (148, 35, 1, 60, 60),
    (149, 29, 2, 10, 20),
    (149, 15, 1, 150, 150),
    (150, 46, 1, 125, 125),
    (151, 12, 1, 140, 140),
    (152, 1, 1, 120, 120),
    (152, 42, 1, 55, 55),
    (152, 8, 1, 205, 205),
    (153, 2, 1, 125, 125),
    (154, 2, 1, 112.50, 112.50),
    (154, 1, 1, 120, 120),
    (155, 36, 1, 65, 65),
    (155, 15, 1, 150, 150),
    (156, 9, 1, 155, 155),
    (156, 36, 1, 65, 65),
    (157, 12, 1, 126.00, 126.00),
    (157, 15, 1, 142.50, 142.50),
    (157, 10, 1, 152.00, 152.00),
    (158, 32, 2, 12, 24),
    (159, 14, 1, 115, 115),
    (160, 16, 1, 180, 180),
    (161, 40, 1, 70, 70),
    (161, 13, 1, 105, 105),
    (162, 44, 1, 120, 120),
    (162, 12, 1, 133.00, 133.00),
    (163, 16, 1, 180, 180),
    (164, 41, 1, 55, 55),
    (164, 2, 1, 125, 125),
    (165, 42, 1, 55, 55),
    (165, 12, 1, 140, 140),
    (165, 10, 1, 160, 160),
    (166, 24, 1, 70, 70),
    (167, 16, 1, 180, 180),
    (168, 2, 1, 125, 125),
    (168, 44, 1, 120, 120),
    (168, 45, 1, 110, 110),
    (169, 13, 1, 105, 105),
    (169, 20, 1, 35, 35),
    (170, 29, 1, 10, 10),
    (170, 8, 1, 205, 205),
    (171, 15, 1, 150, 150),
    (171, 46, 1, 118.75, 118.75),
    (171, 42, 1, 55, 55),
    (172, 7, 1, 166.25, 166.25),
    (172, 9, 1, 155, 155),
    (172, 38, 1, 55, 55),
    (173, 11, 1, 135, 135),
    (174, 12, 1, 140, 140),
    (174, 40, 1, 66.50, 66.50),
    (175, 15, 1, 150, 150),
    (175, 42, 1, 55, 55),
    (176, 45, 1, 104.50, 104.50),
    (177, 13, 1, 99.75, 99.75),
    (178, 2, 1, 125, 125),
    (178, 11, 1, 135, 135),
    (179, 11, 1, 135, 135),
    (179, 37, 1, 55, 55),
    (179, 34, 1, 15, 15),
    (180, 33, 1, 6, 6),
    (181, 44, 1, 114.00, 114.00),
    (182, 12, 1, 140, 140),
    (182, 10, 1, 152.00, 152.00),
    (183, 36, 1, 65, 65),
    (184, 13, 1, 99.75, 99.75),
    (185, 17, 1, 28, 28),
    (185, 16, 1, 180, 180),
    (186, 15, 1, 150, 150),
    (187, 16, 1, 180, 180),
    (187, 10, 1, 160, 160),
    (188, 8, 1, 194.75, 194.75),
    (189, 41, 1, 55, 55),
    (189, 5, 1, 185, 185),
    (190, 11, 1, 135, 135),
    (190, 43, 1, 115, 115),
    (191, 2, 1, 112.50, 112.50);
GO

INSERT INTO dbo.DetalleAlquiler (idAlquiler, idArticulo, cantidad, precioUnitario, subtotal) VALUES
    (192, 2, 1, 125, 125),
    (193, 2, 1, 125, 125),
    (193, 46, 1, 118.75, 118.75),
    (194, 41, 1, 55, 55),
    (195, 45, 1, 110, 110),
    (196, 16, 1, 180, 180),
    (196, 1, 1, 114.00, 114.00),
    (197, 16, 1, 180, 180),
    (197, 1, 1, 120, 120),
    (198, 40, 1, 70, 70),
    (198, 46, 1, 125, 125),
    (199, 40, 1, 70, 70),
    (199, 7, 1, 175, 175),
    (200, 14, 1, 115, 115),
    (200, 22, 1, 80, 80),
    (201, 3, 1, 145, 145),
    (202, 6, 1, 180.50, 180.50),
    (203, 24, 1, 70, 70),
    (203, 39, 1, 65, 65),
    (204, 10, 1, 160, 160),
    (204, 5, 1, 185, 185),
    (204, 46, 1, 125, 125),
    (205, 10, 1, 160, 160),
    (205, 3, 1, 145, 145),
    (206, 2, 1, 125, 125),
    (206, 24, 1, 70, 70),
    (207, 2, 1, 112.50, 112.50),
    (207, 37, 1, 55, 55),
    (208, 39, 1, 61.75, 61.75),
    (209, 38, 1, 55, 55),
    (210, 27, 1, 45, 45),
    (211, 8, 1, 205, 205),
    (212, 44, 1, 120, 120),
    (212, 39, 1, 65, 65),
    (212, 45, 1, 110, 110),
    (213, 42, 1, 52.25, 52.25),
    (213, 25, 1, 35, 35),
    (214, 35, 1, 60, 60),
    (215, 11, 1, 135, 135),
    (216, 16, 1, 180, 180),
    (217, 16, 1, 180, 180),
    (218, 17, 1, 28, 28),
    (218, 12, 1, 140, 140),
    (219, 44, 1, 120, 120),
    (219, 42, 1, 52.25, 52.25),
    (220, 22, 1, 80, 80),
    (221, 14, 1, 115, 115),
    (221, 13, 1, 105, 105),
    (221, 22, 1, 80, 80),
    (222, 13, 1, 105, 105),
    (222, 46, 1, 118.75, 118.75),
    (222, 36, 1, 65, 65),
    (223, 37, 1, 55, 55),
    (223, 6, 1, 190, 190),
    (224, 5, 1, 185, 185),
    (224, 9, 1, 155, 155),
    (225, 44, 1, 120, 120),
    (225, 11, 1, 135, 135),
    (226, 15, 1, 150, 150),
    (227, 2, 1, 125, 125),
    (228, 5, 1, 185, 185),
    (229, 4, 1, 150, 150),
    (229, 8, 1, 205, 205),
    (230, 46, 1, 118.75, 118.75),
    (231, 12, 1, 140, 140),
    (232, 6, 1, 190, 190),
    (233, 43, 1, 115, 115),
    (233, 5, 1, 185, 185),
    (234, 39, 1, 65, 65),
    (235, 42, 1, 55, 55),
    (235, 11, 1, 128.25, 128.25),
    (236, 45, 1, 110, 110),
    (237, 14, 1, 115, 115),
    (238, 7, 1, 166.25, 166.25),
    (238, 37, 1, 52.25, 52.25),
    (239, 13, 1, 94.50, 94.50),
    (240, 12, 1, 126.00, 126.00),
    (240, 20, 1, 35, 35);
GO

INSERT INTO dbo.Devolucion (idAlquiler, fechaDevolucion, estadoArticulo, observaciones) VALUES
    (1, '2024-01-12T14:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (2, '2024-01-22T12:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (3, '2024-01-24T11:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (4, '2024-01-29T09:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (5, '2024-01-31T14:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (6, '2024-02-03T13:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (7, '2024-02-07T15:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (8, '2024-02-06T15:15:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (9, '2024-02-18T10:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (10, '2024-02-15T14:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (11, '2024-02-21T14:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (12, '2024-02-21T12:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (13, '2024-03-12T16:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (14, '2024-03-22T09:15:00', N'Rasgado', N'Prenda con costura rasgada'),
    (15, '2024-03-27T11:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (16, '2024-04-01T11:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (17, '2024-04-03T13:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (18, '2024-04-06T11:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (19, '2024-04-06T11:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (20, '2024-04-10T11:45:00', N'Rasgado', N'Prenda con costura rasgada'),
    (21, '2024-04-20T09:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (22, '2024-04-27T11:30:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (23, '2024-05-03T10:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (24, '2024-05-06T16:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (25, '2024-05-07T14:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (26, '2024-05-17T11:30:00', N'Rasgado', N'Prenda con costura rasgada'),
    (27, '2024-05-28T10:00:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (28, '2024-05-22T13:45:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (29, '2024-06-04T15:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (30, '2024-06-04T10:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (31, '2024-06-08T11:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (32, '2024-06-08T12:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (33, '2024-06-11T10:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (34, '2024-06-13T12:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (35, '2024-06-19T14:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (36, '2024-06-17T10:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (37, '2024-06-27T10:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (38, '2024-07-07T10:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (39, '2024-07-11T13:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (40, '2024-07-18T11:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (41, '2024-07-21T09:00:00', N'Rasgado', N'Prenda con costura rasgada'),
    (42, '2024-07-26T09:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (43, '2024-07-29T14:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (44, '2024-08-03T15:00:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (45, '2024-08-01T13:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (46, '2024-08-14T10:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (47, '2024-08-15T09:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (48, '2024-08-26T12:45:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (49, '2024-09-07T09:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (50, '2024-09-18T14:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (51, '2024-09-23T13:45:00', N'Rasgado', N'Prenda con costura rasgada'),
    (52, '2024-09-25T09:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (53, '2024-10-01T14:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (54, '2024-09-29T15:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (55, '2024-10-02T11:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (56, '2024-10-02T13:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (57, '2024-10-07T11:15:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (58, '2024-10-14T11:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (59, '2024-10-21T14:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (60, '2024-10-22T10:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (61, '2024-11-08T14:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (62, '2024-11-08T11:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (63, '2024-11-08T15:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (64, '2024-11-13T15:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (65, '2024-11-19T11:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (66, '2024-11-26T11:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (67, '2024-11-25T12:30:00', N'Rasgado', N'Prenda con costura rasgada'),
    (68, '2024-11-29T14:15:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (69, '2024-12-11T16:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (70, '2024-12-14T15:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (71, '2025-01-16T12:30:00', N'Dañado', N'Prenda con daño reparable en tela o cierre'),
    (72, '2025-01-12T13:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (73, '2025-01-14T13:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (74, '2025-01-24T12:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (75, '2025-01-26T14:15:00', N'Rasgado', N'Prenda con costura rasgada'),
    (76, '2025-01-25T11:15:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (77, '2025-01-27T16:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (78, '2025-01-31T12:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (79, '2025-02-09T15:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (80, '2025-02-10T14:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (81, '2025-02-09T12:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (82, '2025-02-14T09:00:00', N'Dañado', N'Prenda con daño reparable en tela o cierre'),
    (83, '2025-02-14T15:30:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (84, '2025-02-20T11:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (85, '2025-03-06T11:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (86, '2025-03-13T09:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (87, '2025-03-18T13:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (88, '2025-03-18T09:30:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (89, '2025-03-24T13:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (90, '2025-04-07T09:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (91, '2025-04-17T12:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (92, '2025-04-18T14:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (93, '2025-04-19T09:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (94, '2025-04-22T12:00:00', N'Rasgado', N'Prenda con costura rasgada'),
    (95, '2025-05-08T10:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (96, '2025-05-09T15:15:00', N'Dañado', N'Prenda con daño reparable en tela o cierre'),
    (97, '2025-05-07T09:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (98, '2025-05-12T09:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (99, '2025-05-27T10:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (100, '2025-06-01T11:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (101, '2025-06-08T11:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (102, '2025-06-21T12:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (103, '2025-06-24T10:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (104, '2025-06-30T10:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (105, '2025-07-04T14:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (106, '2025-07-10T10:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (107, '2025-07-06T09:00:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (108, '2025-07-17T14:30:00', N'Dañado', N'Prenda con daño reparable en tela o cierre'),
    (109, '2025-07-16T10:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (110, '2025-07-17T09:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (111, '2025-07-23T11:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (112, '2025-07-27T16:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (113, '2025-07-30T16:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (114, '2025-08-08T13:00:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (115, '2025-08-11T11:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (116, '2025-08-11T09:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (117, '2025-08-14T15:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (118, '2025-08-20T15:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (119, '2025-08-26T09:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (120, '2025-08-25T15:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (121, '2025-08-24T10:30:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (122, '2025-09-04T13:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (123, '2025-09-09T15:45:00', N'Dañado', N'Prenda con daño reparable en tela o cierre'),
    (124, '2025-09-11T09:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (125, '2025-09-14T14:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (126, '2025-09-15T15:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (127, '2025-09-22T15:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (128, '2025-09-22T11:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (129, '2025-09-21T11:30:00', N'Rasgado', N'Prenda con costura rasgada'),
    (130, '2025-09-27T14:15:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (131, '2025-09-29T15:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (132, '2025-10-03T09:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (133, '2025-10-10T13:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (134, '2025-10-11T11:00:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (135, '2025-10-12T16:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (136, '2025-10-12T15:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (137, '2025-10-12T11:00:00', N'Dañado', N'Prenda con daño reparable en tela o cierre'),
    (138, '2025-10-16T16:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (139, '2025-10-17T13:45:00', N'Dañado', N'Prenda con daño reparable en tela o cierre'),
    (140, '2025-10-18T13:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (141, '2025-10-18T10:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (142, '2025-10-23T15:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (143, '2025-10-28T12:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (144, '2025-10-29T11:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (145, '2025-11-03T11:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (146, '2025-11-23T13:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (147, '2025-11-26T09:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (148, '2025-11-26T11:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (149, '2025-12-01T11:15:00', N'Rasgado', N'Prenda con costura rasgada'),
    (150, '2025-12-01T11:30:00', N'Bueno', N'Prendas devueltas en buen estado');
GO

INSERT INTO dbo.Devolucion (idAlquiler, fechaDevolucion, estadoArticulo, observaciones) VALUES
    (151, '2025-12-03T16:15:00', N'Rasgado', N'Prenda con costura rasgada'),
    (152, '2025-12-03T10:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (153, '2025-12-10T09:30:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (154, '2025-12-11T14:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (155, '2025-12-14T13:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (156, '2025-12-13T14:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (157, '2025-12-24T11:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (158, '2025-12-26T09:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (159, '2026-01-20T11:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (160, '2026-01-22T12:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (161, '2026-01-27T15:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (162, '2026-01-27T10:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (163, '2026-01-28T14:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (164, '2026-01-31T16:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (165, '2026-02-01T09:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (166, '2026-02-02T10:45:00', N'Dañado', N'Prenda con daño reparable en tela o cierre'),
    (167, '2026-02-09T10:00:00', N'Dañado', N'Prenda con daño reparable en tela o cierre'),
    (168, '2026-02-16T13:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (169, '2026-02-20T13:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (170, '2026-02-21T13:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (171, '2026-02-23T11:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (172, '2026-02-25T13:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (173, '2026-02-28T12:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (174, '2026-03-05T13:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (175, '2026-03-09T12:30:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (176, '2026-03-10T14:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (177, '2026-03-28T10:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (178, '2026-03-31T14:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (179, '2026-04-03T16:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (180, '2026-04-12T14:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (181, '2026-04-21T15:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (182, '2026-04-22T09:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (183, '2026-04-28T14:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (184, '2026-05-01T15:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (185, '2026-05-03T15:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (186, '2026-05-04T13:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (187, '2026-05-06T12:30:00', N'Dañado', N'Prenda con daño reparable en tela o cierre'),
    (188, '2026-05-08T14:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (189, '2026-05-18T14:45:00', N'Rasgado', N'Prenda con costura rasgada'),
    (190, '2026-05-29T09:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (191, '2026-05-27T14:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (192, '2026-06-03T13:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (193, '2026-06-05T14:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (194, '2026-06-09T14:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (195, '2026-06-21T14:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (196, '2026-06-21T12:15:00', N'Rasgado', N'Prenda con costura rasgada'),
    (197, '2026-06-28T15:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (198, '2026-06-24T10:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (199, '2026-06-28T12:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (200, '2026-07-03T13:00:00', N'Rasgado', N'Prenda con costura rasgada'),
    (201, '2026-07-05T11:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (202, '2026-07-05T13:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (203, '2026-07-08T14:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (204, '2026-07-09T15:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (205, '2026-07-11T16:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (206, '2026-07-11T09:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (207, '2026-07-16T14:15:00', N'Rasgado', N'Prenda con costura rasgada'),
    (208, '2026-07-12T10:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (209, '2026-07-15T11:45:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (210, '2026-07-22T15:45:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (211, '2026-07-25T14:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (212, '2026-07-26T10:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (213, '2026-07-31T13:15:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (214, '2026-08-01T15:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (215, '2026-08-04T13:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (216, '2026-08-07T16:15:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (217, '2026-08-12T09:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (218, '2026-08-15T16:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (219, '2026-08-20T09:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (220, '2026-08-23T16:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (221, '2026-08-26T13:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (222, '2026-08-26T13:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (223, '2026-08-28T14:30:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (224, '2026-08-31T10:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (225, '2026-09-01T11:00:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (226, '2026-09-11T16:15:00', N'Manchado', N'Se observa mancha que requiere lavandería especializada'),
    (227, '2026-09-16T10:30:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (228, '2026-09-24T16:45:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (230, '2026-10-13T11:15:00', N'Bueno', N'Prendas devueltas en buen estado'),
    (235, '2026-10-15T16:15:00', N'Bueno', N'Prendas devueltas en buen estado');
GO

INSERT INTO dbo.Penalidad (idDevolucion, idArticulo, tipoPenalidad, descripcion, diasRetraso, monto, fechaRegistro, estadoPenalidad) VALUES
    (5, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2024-01-31T14:15:00', N'Pagada'),
    (8, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2024-02-06T15:15:00', N'Pagada'),
    (8, 44, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2024-02-06T15:15:00', N'Pagada'),
    (14, 24, N'Reparación', N'Reparación por rasgadura de tela', 0, 95.00, '2024-03-22T09:15:00', N'Pendiente'),
    (17, NULL, N'Mora', N'Devolución con 2 día(s) de atraso; S/ 25 por día', 2, 50.00, '2024-04-03T13:30:00', N'Pagada'),
    (20, 37, N'Reparación', N'Reparación por rasgadura de tela', 0, 95.00, '2024-04-10T11:45:00', N'Pagada'),
    (21, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2024-04-20T09:15:00', N'Pagada'),
    (22, 30, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2024-04-27T11:30:00', N'Pendiente'),
    (26, 4, N'Reparación', N'Reparación por rasgadura de tela', 0, 95.00, '2024-05-17T11:30:00', N'Pagada'),
    (27, NULL, N'Mora', N'Devolución con 4 día(s) de atraso; S/ 25 por día', 4, 100.00, '2024-05-28T10:00:00', N'Pagada'),
    (27, 4, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2024-05-28T10:00:00', N'Pagada'),
    (28, 39, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2024-05-22T13:45:00', N'Pendiente'),
    (31, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2024-06-08T11:15:00', N'Pagada'),
    (32, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2024-06-08T12:30:00', N'Pagada'),
    (33, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2024-06-11T10:15:00', N'Pagada'),
    (34, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2024-06-13T12:30:00', N'Pendiente'),
    (35, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2024-06-19T14:00:00', N'Pagada'),
    (41, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2024-07-21T09:00:00', N'Pagada'),
    (41, 37, N'Reparación', N'Reparación por rasgadura de tela', 0, 95.00, '2024-07-21T09:00:00', N'Pagada'),
    (42, NULL, N'Mora', N'Devolución con 3 día(s) de atraso; S/ 25 por día', 3, 75.00, '2024-07-26T09:30:00', N'Pendiente'),
    (44, 28, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2024-08-03T15:00:00', N'Pagada'),
    (48, 13, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2024-08-26T12:45:00', N'Pagada'),
    (49, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2024-09-07T09:00:00', N'Pagada'),
    (51, 14, N'Reparación', N'Reparación por rasgadura de tela', 0, 95.00, '2024-09-23T13:45:00', N'Pendiente'),
    (53, NULL, N'Mora', N'Devolución con 2 día(s) de atraso; S/ 25 por día', 2, 50.00, '2024-10-01T14:15:00', N'Pagada'),
    (54, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2024-09-29T15:00:00', N'Pagada'),
    (57, NULL, N'Mora', N'Devolución con 4 día(s) de atraso; S/ 25 por día', 4, 100.00, '2024-10-07T11:15:00', N'Pagada'),
    (57, 1, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2024-10-07T11:15:00', N'Pendiente'),
    (60, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2024-10-22T10:45:00', N'Pagada'),
    (61, NULL, N'Mora', N'Devolución con 3 día(s) de atraso; S/ 25 por día', 3, 75.00, '2024-11-08T14:15:00', N'Pagada'),
    (64, NULL, N'Mora', N'Devolución con 2 día(s) de atraso; S/ 25 por día', 2, 50.00, '2024-11-13T15:15:00', N'Pagada'),
    (67, 9, N'Reparación', N'Reparación por rasgadura de tela', 0, 95.00, '2024-11-25T12:30:00', N'Pendiente'),
    (68, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2024-11-29T14:15:00', N'Pagada'),
    (68, 41, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2024-11-29T14:15:00', N'Pagada'),
    (69, NULL, N'Mora', N'Devolución con 2 día(s) de atraso; S/ 25 por día', 2, 50.00, '2024-12-11T16:30:00', N'Pagada'),
    (71, 38, N'Reparación', N'Reparación de costura o cierre', 0, 125.00, '2025-01-16T12:30:00', N'Pendiente'),
    (75, 3, N'Reparación', N'Reparación por rasgadura de tela', 0, 95.00, '2025-01-26T14:15:00', N'Pagada'),
    (76, 10, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2025-01-25T11:15:00', N'Pagada'),
    (82, NULL, N'Mora', N'Devolución con 2 día(s) de atraso; S/ 25 por día', 2, 50.00, '2025-02-14T09:00:00', N'Pagada'),
    (82, 5, N'Reparación', N'Reparación de costura o cierre', 0, 125.00, '2025-02-14T09:00:00', N'Pendiente'),
    (83, 41, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2025-02-14T15:30:00', N'Pagada'),
    (88, 1, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2025-03-18T09:30:00', N'Pagada'),
    (91, NULL, N'Mora', N'Devolución con 3 día(s) de atraso; S/ 25 por día', 3, 75.00, '2025-04-17T12:45:00', N'Pagada'),
    (92, NULL, N'Mora', N'Devolución con 3 día(s) de atraso; S/ 25 por día', 3, 75.00, '2025-04-18T14:00:00', N'Pendiente'),
    (94, 15, N'Reparación', N'Reparación por rasgadura de tela', 0, 95.00, '2025-04-22T12:00:00', N'Pagada'),
    (95, NULL, N'Mora', N'Devolución con 2 día(s) de atraso; S/ 25 por día', 2, 50.00, '2025-05-08T10:15:00', N'Pagada'),
    (96, 8, N'Reparación', N'Reparación de costura o cierre', 0, 125.00, '2025-05-09T15:15:00', N'Pagada'),
    (99, NULL, N'Mora', N'Devolución con 2 día(s) de atraso; S/ 25 por día', 2, 50.00, '2025-05-27T10:00:00', N'Pendiente'),
    (106, NULL, N'Mora', N'Devolución con 4 día(s) de atraso; S/ 25 por día', 4, 100.00, '2025-07-10T10:45:00', N'Pagada'),
    (107, 40, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2025-07-06T09:00:00', N'Pagada'),
    (108, 15, N'Reparación', N'Reparación de costura o cierre', 0, 125.00, '2025-07-17T14:30:00', N'Pagada'),
    (111, NULL, N'Mora', N'Devolución con 2 día(s) de atraso; S/ 25 por día', 2, 50.00, '2025-07-23T11:00:00', N'Pendiente'),
    (114, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2025-08-08T13:00:00', N'Pagada'),
    (114, 1, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2025-08-08T13:00:00', N'Pagada'),
    (119, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2025-08-26T09:45:00', N'Pagada'),
    (120, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2025-08-25T15:30:00', N'Pendiente'),
    (121, 12, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2025-08-24T10:30:00', N'Pagada'),
    (122, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2025-09-04T13:00:00', N'Pagada'),
    (123, 4, N'Reparación', N'Reparación de costura o cierre', 0, 125.00, '2025-09-09T15:45:00', N'Pagada'),
    (125, NULL, N'Mora', N'Devolución con 2 día(s) de atraso; S/ 25 por día', 2, 50.00, '2025-09-14T14:30:00', N'Pendiente'),
    (127, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2025-09-22T15:30:00', N'Pagada'),
    (129, 15, N'Reparación', N'Reparación por rasgadura de tela', 0, 95.00, '2025-09-21T11:30:00', N'Pagada'),
    (130, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2025-09-27T14:15:00', N'Pagada'),
    (130, 16, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2025-09-27T14:15:00', N'Pendiente'),
    (134, 36, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2025-10-11T11:00:00', N'Pagada'),
    (137, 8, N'Reparación', N'Reparación de costura o cierre', 0, 125.00, '2025-10-12T11:00:00', N'Pagada'),
    (139, NULL, N'Mora', N'Devolución con 3 día(s) de atraso; S/ 25 por día', 3, 75.00, '2025-10-17T13:45:00', N'Pagada'),
    (139, 44, N'Reparación', N'Reparación de costura o cierre', 0, 125.00, '2025-10-17T13:45:00', N'Pendiente'),
    (140, NULL, N'Mora', N'Devolución con 3 día(s) de atraso; S/ 25 por día', 3, 75.00, '2025-10-18T13:30:00', N'Pagada'),
    (143, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2025-10-28T12:45:00', N'Pagada'),
    (147, NULL, N'Mora', N'Devolución con 2 día(s) de atraso; S/ 25 por día', 2, 50.00, '2025-11-26T09:45:00', N'Pagada'),
    (149, 29, N'Reparación', N'Reparación por rasgadura de tela', 0, 95.00, '2025-12-01T11:15:00', N'Pendiente'),
    (151, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2025-12-03T16:15:00', N'Pagada'),
    (151, 12, N'Reparación', N'Reparación por rasgadura de tela', 0, 95.00, '2025-12-03T16:15:00', N'Pagada'),
    (152, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2025-12-03T10:15:00', N'Pagada'),
    (153, 2, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2025-12-10T09:30:00', N'Pendiente'),
    (154, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2025-12-11T14:00:00', N'Pagada'),
    (166, 24, N'Reparación', N'Reparación de costura o cierre', 0, 125.00, '2026-02-02T10:45:00', N'Pagada'),
    (167, 16, N'Reparación', N'Reparación de costura o cierre', 0, 125.00, '2026-02-09T10:00:00', N'Pagada'),
    (168, NULL, N'Mora', N'Devolución con 4 día(s) de atraso; S/ 25 por día', 4, 100.00, '2026-02-16T13:45:00', N'Pendiente'),
    (169, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2026-02-20T13:00:00', N'Pagada'),
    (174, NULL, N'Mora', N'Devolución con 3 día(s) de atraso; S/ 25 por día', 3, 75.00, '2026-03-05T13:45:00', N'Pagada'),
    (175, 15, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2026-03-09T12:30:00', N'Pagada'),
    (179, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2026-04-03T16:00:00', N'Pendiente'),
    (187, 10, N'Reparación', N'Reparación de costura o cierre', 0, 125.00, '2026-05-06T12:30:00', N'Pagada'),
    (189, 41, N'Reparación', N'Reparación por rasgadura de tela', 0, 95.00, '2026-05-18T14:45:00', N'Pagada'),
    (190, NULL, N'Mora', N'Devolución con 3 día(s) de atraso; S/ 25 por día', 3, 75.00, '2026-05-29T09:00:00', N'Pagada'),
    (196, 16, N'Reparación', N'Reparación por rasgadura de tela', 0, 95.00, '2026-06-21T12:15:00', N'Pendiente'),
    (197, NULL, N'Mora', N'Devolución con 3 día(s) de atraso; S/ 25 por día', 3, 75.00, '2026-06-28T15:45:00', N'Pagada'),
    (200, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2026-07-03T13:00:00', N'Pagada'),
    (200, 14, N'Reparación', N'Reparación por rasgadura de tela', 0, 95.00, '2026-07-03T13:00:00', N'Pagada'),
    (203, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2026-07-08T14:30:00', N'Pendiente'),
    (207, 2, N'Reparación', N'Reparación por rasgadura de tela', 0, 95.00, '2026-07-16T14:15:00', N'Pagada'),
    (209, 38, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2026-07-15T11:45:00', N'Pagada'),
    (210, 27, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2026-07-22T15:45:00', N'Pagada'),
    (211, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2026-07-25T14:15:00', N'Pendiente'),
    (213, 25, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2026-07-31T13:15:00', N'Pagada'),
    (216, 16, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2026-08-07T16:15:00', N'Pagada'),
    (223, 37, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2026-08-28T14:30:00', N'Pagada'),
    (224, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2026-08-31T10:30:00', N'Pendiente'),
    (226, 15, N'Limpieza', N'Limpieza especializada por manchas', 0, 45.00, '2026-09-11T16:15:00', N'Pagada'),
    (229, NULL, N'Mora', N'Devolución con 1 día(s) de atraso; S/ 25 por día', 1, 25.00, '2026-10-13T11:15:00', N'Pagada');
GO

INSERT INTO dbo.Gasto (fechaGasto, tipoGasto, descripcion, monto, idVenta, idAlquiler) VALUES
    ('2024-01-09T10:50:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 45.00, NULL, NULL),
    ('2024-01-11T09:50:00', N'Alquiler de local', N'Arrendamiento de local comercial', 960.00, NULL, NULL),
    ('2024-01-16T14:20:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 75.00, NULL, 1),
    ('2024-01-25T13:10:00', N'Alquiler de local', N'Arrendamiento de local comercial', 1545.00, NULL, NULL),
    ('2024-02-01T12:10:00', N'Movilidad', N'Transporte y retiro de prendas', 50.00, NULL, NULL),
    ('2024-02-28T10:50:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 50.00, NULL, 5),
    ('2024-03-05T13:20:00', N'Marketing', N'Promoción digital y material publicitario', 95.00, NULL, NULL),
    ('2024-03-20T17:40:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 95.00, NULL, NULL),
    ('2024-03-22T13:20:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 45.00, NULL, 13),
    ('2024-03-25T16:15:00', N'Marketing', N'Promoción digital y material publicitario', 90.00, NULL, NULL),
    ('2024-03-30T16:15:00', N'Alquiler de local', N'Arrendamiento de local comercial', 1135.00, NULL, NULL),
    ('2024-04-29T15:50:00', N'Servicios', N'Electricidad, agua e internet del local', 195.00, NULL, NULL),
    ('2024-05-08T10:45:00', N'Movilidad', N'Transporte y retiro de prendas', 45.00, NULL, NULL),
    ('2024-05-18T13:45:00', N'Marketing', N'Promoción digital y material publicitario', 140.00, NULL, NULL),
    ('2024-05-28T10:30:00', N'Servicios', N'Electricidad, agua e internet del local', 290.00, NULL, NULL),
    ('2024-05-30T17:15:00', N'Movilidad', N'Transporte y retiro de prendas', 75.00, NULL, NULL),
    ('2024-06-02T12:45:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 110.00, NULL, NULL),
    ('2024-06-05T13:40:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 100.00, NULL, 10),
    ('2024-06-08T08:00:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 110.00, NULL, NULL),
    ('2024-06-08T16:10:00', N'Marketing', N'Promoción digital y material publicitario', 270.00, NULL, NULL),
    ('2024-06-10T11:50:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 45.00, NULL, 15),
    ('2024-06-12T16:00:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 75.00, NULL, NULL),
    ('2024-06-18T11:10:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 115.00, NULL, NULL),
    ('2024-06-28T14:30:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 80.00, NULL, 16),
    ('2024-07-07T13:40:00', N'Remuneraciones', N'Pago de personal y comisiones', 925.00, NULL, NULL),
    ('2024-07-08T14:00:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 110.00, NULL, NULL),
    ('2024-07-30T17:20:00', N'Marketing', N'Promoción digital y material publicitario', 130.00, NULL, NULL),
    ('2024-08-14T17:00:00', N'Marketing', N'Promoción digital y material publicitario', 265.00, NULL, NULL),
    ('2024-08-29T12:20:00', N'Movilidad', N'Transporte y retiro de prendas', 50.00, NULL, NULL),
    ('2024-09-04T08:40:00', N'Marketing', N'Promoción digital y material publicitario', 375.00, NULL, NULL),
    ('2024-09-08T08:50:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 115.00, NULL, NULL),
    ('2024-09-18T09:40:00', N'Movilidad', N'Transporte y retiro de prendas', 65.00, NULL, NULL),
    ('2024-09-30T12:50:00', N'Servicios', N'Electricidad, agua e internet del local', 195.00, NULL, NULL),
    ('2024-10-08T10:15:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 120.00, NULL, NULL),
    ('2024-10-11T12:40:00', N'Servicios', N'Electricidad, agua e internet del local', 175.00, NULL, NULL),
    ('2024-11-03T11:45:00', N'Servicios', N'Electricidad, agua e internet del local', 265.00, NULL, NULL),
    ('2024-11-03T10:30:00', N'Remuneraciones', N'Pago de personal y comisiones', 2425.00, NULL, NULL),
    ('2024-11-22T16:40:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 155.00, NULL, NULL),
    ('2024-12-01T09:20:00', N'Marketing', N'Promoción digital y material publicitario', 305.00, NULL, NULL),
    ('2024-12-01T13:00:00', N'Marketing', N'Promoción digital y material publicitario', 215.00, NULL, NULL),
    ('2024-12-10T12:10:00', N'Alquiler de local', N'Arrendamiento de local comercial', 1115.00, NULL, NULL),
    ('2024-12-13T08:10:00', N'Movilidad', N'Transporte y retiro de prendas', 40.00, NULL, 67),
    ('2025-01-11T16:15:00', N'Movilidad', N'Transporte y retiro de prendas', 70.00, NULL, NULL),
    ('2025-01-23T17:40:00', N'Remuneraciones', N'Pago de personal y comisiones', 890.00, NULL, NULL),
    ('2025-01-24T17:00:00', N'Movilidad', N'Transporte y retiro de prendas', 80.00, NULL, 63),
    ('2025-02-13T08:50:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 70.00, NULL, NULL),
    ('2025-02-14T13:20:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 95.00, NULL, NULL),
    ('2025-02-20T16:45:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 115.00, NULL, 26),
    ('2025-02-20T10:30:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 50.00, NULL, NULL),
    ('2025-03-02T13:40:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 95.00, NULL, NULL),
    ('2025-03-03T14:40:00', N'Movilidad', N'Transporte y retiro de prendas', 40.00, NULL, 24),
    ('2025-03-12T16:30:00', N'Servicios', N'Electricidad, agua e internet del local', 285.00, NULL, NULL),
    ('2025-03-18T16:10:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 115.00, NULL, NULL),
    ('2025-03-18T17:20:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 110.00, NULL, 84),
    ('2025-04-04T13:10:00', N'Marketing', N'Promoción digital y material publicitario', 85.00, NULL, NULL),
    ('2025-04-07T17:20:00', N'Marketing', N'Promoción digital y material publicitario', 225.00, NULL, NULL),
    ('2025-05-03T11:30:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 65.00, NULL, NULL),
    ('2025-05-06T11:45:00', N'Servicios', N'Electricidad, agua e internet del local', 295.00, NULL, NULL),
    ('2025-05-07T13:50:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 140.00, NULL, NULL),
    ('2025-05-15T13:45:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 65.00, NULL, 87),
    ('2025-05-27T09:50:00', N'Remuneraciones', N'Pago de personal y comisiones', 1640.00, NULL, NULL),
    ('2025-05-30T12:45:00', N'Servicios', N'Electricidad, agua e internet del local', 180.00, NULL, NULL),
    ('2025-06-04T08:45:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 150.00, 32, NULL),
    ('2025-06-04T10:30:00', N'Movilidad', N'Transporte y retiro de prendas', 25.00, NULL, NULL),
    ('2025-06-08T10:10:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 110.00, NULL, NULL),
    ('2025-06-21T11:50:00', N'Marketing', N'Promoción digital y material publicitario', 145.00, NULL, NULL),
    ('2025-06-29T13:20:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 120.00, NULL, NULL),
    ('2025-07-09T15:15:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 150.00, NULL, NULL),
    ('2025-07-10T13:40:00', N'Marketing', N'Promoción digital y material publicitario', 360.00, NULL, NULL),
    ('2025-08-12T12:00:00', N'Movilidad', N'Transporte y retiro de prendas', 65.00, NULL, NULL),
    ('2025-08-13T12:40:00', N'Movilidad', N'Transporte y retiro de prendas', 60.00, NULL, NULL),
    ('2025-08-17T08:30:00', N'Servicios', N'Electricidad, agua e internet del local', 260.00, NULL, NULL),
    ('2025-08-19T17:30:00', N'Alquiler de local', N'Arrendamiento de local comercial', 1650.00, NULL, NULL),
    ('2025-08-31T10:00:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 85.00, NULL, NULL),
    ('2025-09-16T16:40:00', N'Movilidad', N'Transporte y retiro de prendas', 80.00, NULL, 120),
    ('2025-09-27T08:10:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 60.00, NULL, NULL),
    ('2025-09-30T13:00:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 115.00, NULL, NULL),
    ('2025-10-09T17:00:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 65.00, NULL, NULL),
    ('2025-10-16T17:15:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 85.00, NULL, NULL),
    ('2025-10-17T12:30:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 130.00, NULL, NULL),
    ('2025-10-17T17:00:00', N'Movilidad', N'Transporte y retiro de prendas', 60.00, NULL, 11),
    ('2025-10-30T12:40:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 120.00, NULL, NULL),
    ('2025-10-31T09:15:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 85.00, NULL, NULL),
    ('2025-11-02T11:10:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 105.00, NULL, NULL),
    ('2025-11-03T15:15:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 145.00, NULL, NULL),
    ('2025-11-07T09:20:00', N'Movilidad', N'Transporte y retiro de prendas', 75.00, NULL, NULL),
    ('2025-11-10T11:40:00', N'Servicios', N'Electricidad, agua e internet del local', 345.00, NULL, NULL),
    ('2025-11-25T15:45:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 140.00, NULL, NULL),
    ('2025-11-28T13:45:00', N'Servicios', N'Electricidad, agua e internet del local', 340.00, NULL, NULL),
    ('2025-11-29T17:20:00', N'Remuneraciones', N'Pago de personal y comisiones', 1775.00, NULL, NULL),
    ('2025-12-05T14:15:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 80.00, NULL, NULL),
    ('2025-12-16T12:10:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 100.00, NULL, NULL),
    ('2025-12-18T15:15:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 110.00, NULL, 50),
    ('2025-12-22T17:50:00', N'Remuneraciones', N'Pago de personal y comisiones', 1365.00, NULL, NULL),
    ('2026-01-09T14:50:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 130.00, NULL, NULL),
    ('2026-01-13T13:50:00', N'Marketing', N'Promoción digital y material publicitario', 335.00, NULL, NULL),
    ('2026-01-17T15:10:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 130.00, NULL, NULL),
    ('2026-01-31T13:10:00', N'Servicios', N'Electricidad, agua e internet del local', 380.00, NULL, NULL),
    ('2026-02-14T17:50:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 130.00, NULL, 56),
    ('2026-02-19T11:10:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 120.00, NULL, NULL),
    ('2026-02-22T11:20:00', N'Marketing', N'Promoción digital y material publicitario', 295.00, NULL, NULL),
    ('2026-03-01T15:20:00', N'Movilidad', N'Transporte y retiro de prendas', 65.00, NULL, 70),
    ('2026-03-05T14:10:00', N'Marketing', N'Promoción digital y material publicitario', 200.00, NULL, NULL),
    ('2026-03-06T12:15:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 80.00, NULL, NULL),
    ('2026-03-07T10:10:00', N'Marketing', N'Promoción digital y material publicitario', 245.00, NULL, NULL),
    ('2026-03-11T11:30:00', N'Movilidad', N'Transporte y retiro de prendas', 40.00, NULL, NULL),
    ('2026-03-12T16:00:00', N'Servicios', N'Electricidad, agua e internet del local', 355.00, NULL, NULL),
    ('2026-03-14T17:00:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 100.00, NULL, 53),
    ('2026-03-17T16:30:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 70.00, NULL, NULL),
    ('2026-03-25T11:30:00', N'Marketing', N'Promoción digital y material publicitario', 230.00, NULL, NULL),
    ('2026-03-26T10:30:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 80.00, NULL, 156),
    ('2026-03-26T16:10:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 50.00, NULL, NULL),
    ('2026-03-27T16:45:00', N'Servicios', N'Electricidad, agua e internet del local', 230.00, NULL, NULL),
    ('2026-04-13T15:15:00', N'Marketing', N'Promoción digital y material publicitario', 225.00, NULL, NULL),
    ('2026-04-29T13:15:00', N'Movilidad', N'Transporte y retiro de prendas', 30.00, NULL, NULL),
    ('2026-05-04T17:20:00', N'Remuneraciones', N'Pago de personal y comisiones', 2035.00, NULL, NULL),
    ('2026-05-11T16:00:00', N'Marketing', N'Promoción digital y material publicitario', 185.00, NULL, NULL),
    ('2026-05-12T16:40:00', N'Servicios', N'Electricidad, agua e internet del local', 400.00, NULL, NULL),
    ('2026-06-15T08:00:00', N'Servicios', N'Electricidad, agua e internet del local', 240.00, NULL, NULL),
    ('2026-06-16T08:10:00', N'Alquiler de local', N'Arrendamiento de local comercial', 985.00, NULL, NULL),
    ('2026-06-16T10:45:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 65.00, NULL, NULL),
    ('2026-06-20T17:00:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 85.00, NULL, NULL),
    ('2026-06-25T13:15:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 125.00, NULL, 187),
    ('2026-06-25T14:10:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 95.00, NULL, NULL),
    ('2026-06-27T16:20:00', N'Insumos', N'Bolsas, ganchos, protectores y empaques', 105.00, NULL, NULL),
    ('2026-07-06T11:00:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 35.00, NULL, 71),
    ('2026-07-11T12:20:00', N'Remuneraciones', N'Pago de personal y comisiones', 2205.00, NULL, NULL),
    ('2026-08-03T14:10:00', N'Movilidad', N'Transporte y retiro de prendas', 35.00, NULL, NULL),
    ('2026-08-14T17:45:00', N'Servicios', N'Electricidad, agua e internet del local', 170.00, NULL, NULL),
    ('2026-08-15T15:50:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 90.00, NULL, NULL),
    ('2026-08-20T11:30:00', N'Servicios', N'Electricidad, agua e internet del local', 345.00, NULL, NULL),
    ('2026-08-23T14:15:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 55.00, NULL, 16),
    ('2026-09-30T13:20:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 65.00, NULL, NULL),
    ('2026-09-30T12:40:00', N'Marketing', N'Promoción digital y material publicitario', 165.00, NULL, NULL),
    ('2026-10-02T15:00:00', N'Mantenimiento', N'Mantenimiento y ajustes de prendas', 80.00, NULL, 93),
    ('2026-10-08T15:50:00', N'Lavandería', N'Servicio de lavado y planchado de prendas', 90.00, NULL, NULL),
    ('2026-10-09T11:45:00', N'Marketing', N'Promoción digital y material publicitario', 310.00, NULL, NULL);
GO

INSERT INTO dbo.Pago (tipoOperacion, idVenta, idAlquiler, idPenalidad, fechaPago, metodoPago, monto, estadoPago) VALUES
    (N'VENTA', 1, NULL, NULL, '2024-01-16T09:40:00', N'Efectivo', 698.00, N'Confirmado'),
    (N'VENTA', 2, NULL, NULL, '2024-01-18T09:00:00', N'Plin', 835, N'Confirmado'),
    (N'VENTA', 3, NULL, NULL, '2024-01-20T08:45:00', N'Tarjeta', 205, N'Confirmado'),
    (N'VENTA', 4, NULL, NULL, '2024-02-02T11:30:00', N'Yape', 355, N'Confirmado'),
    (N'VENTA', 5, NULL, NULL, '2024-02-02T13:30:00', N'Plin', 646.25, N'Confirmado'),
    (N'VENTA', 6, NULL, NULL, '2024-02-08T13:50:00', N'Tarjeta', 656.00, N'Confirmado'),
    (N'VENTA', 7, NULL, NULL, '2024-02-20T09:50:00', N'Tarjeta', 68.40, N'Confirmado'),
    (N'VENTA', 7, NULL, NULL, '2024-02-21T13:10:00', N'Efectivo', 102.60, N'Confirmado'),
    (N'VENTA', 8, NULL, NULL, '2024-02-25T15:00:00', N'Tarjeta', 300, N'Confirmado'),
    (N'VENTA', 9, NULL, NULL, '2024-03-01T09:10:00', N'Yape', 1295.50, N'Confirmado'),
    (N'VENTA', 10, NULL, NULL, '2024-03-07T13:50:00', N'Yape', 147, N'Confirmado'),
    (N'VENTA', 11, NULL, NULL, '2024-03-09T08:40:00', N'Plin', 350, N'Confirmado'),
    (N'VENTA', 12, NULL, NULL, '2024-03-12T16:40:00', N'Yape', 890, N'Confirmado'),
    (N'VENTA', 13, NULL, NULL, '2024-03-24T16:10:00', N'Efectivo', 677.25, N'Confirmado'),
    (N'VENTA', 14, NULL, NULL, '2024-03-27T12:50:00', N'Tarjeta', 330.60, N'Confirmado'),
    (N'VENTA', 14, NULL, NULL, '2024-03-28T17:45:00', N'Yape', 495.90, N'Confirmado'),
    (N'VENTA', 15, NULL, NULL, '2024-03-27T12:15:00', N'Tarjeta', 631.00, N'Confirmado'),
    (N'VENTA', 16, NULL, NULL, '2024-03-29T16:15:00', N'Yape', 347.25, N'Confirmado'),
    (N'VENTA', 17, NULL, NULL, '2024-04-03T13:00:00', N'Yape', 245, N'Confirmado'),
    (N'VENTA', 18, NULL, NULL, '2024-04-15T10:40:00', N'Yape', 301.50, N'Confirmado'),
    (N'VENTA', 19, NULL, NULL, '2024-04-18T15:30:00', N'Efectivo', 370, N'Confirmado'),
    (N'VENTA', 20, NULL, NULL, '2024-04-19T08:30:00', N'Efectivo', 897.50, N'Confirmado'),
    (N'VENTA', 21, NULL, NULL, '2024-04-24T16:45:00', N'Yape', 330.00, N'Confirmado'),
    (N'VENTA', 21, NULL, NULL, '2024-04-25T17:30:00', N'Efectivo', 495.00, N'Confirmado'),
    (N'VENTA', 22, NULL, NULL, '2024-04-25T09:15:00', N'Efectivo', 720, N'Confirmado'),
    (N'VENTA', 23, NULL, NULL, '2024-05-13T14:15:00', N'Transferencia', 831.25, N'Confirmado'),
    (N'VENTA', 24, NULL, NULL, '2024-05-17T15:20:00', N'Yape', 871.25, N'Confirmado'),
    (N'VENTA', 25, NULL, NULL, '2024-06-12T16:45:00', N'Transferencia', 49, N'Confirmado'),
    (N'VENTA', 26, NULL, NULL, '2024-06-18T10:10:00', N'Yape', 259, N'Confirmado'),
    (N'VENTA', 27, NULL, NULL, '2024-06-21T09:45:00', N'Efectivo', 783.75, N'Confirmado'),
    (N'VENTA', 28, NULL, NULL, '2024-07-12T09:00:00', N'Tarjeta', 100.00, N'Confirmado'),
    (N'VENTA', 28, NULL, NULL, '2024-07-13T14:15:00', N'Efectivo', 150.00, N'Confirmado'),
    (N'VENTA', 29, NULL, NULL, '2024-07-13T13:50:00', N'Plin', 330, N'Confirmado'),
    (N'VENTA', 30, NULL, NULL, '2024-07-14T09:30:00', N'Tarjeta', 850.50, N'Confirmado'),
    (N'VENTA', 31, NULL, NULL, '2024-07-31T12:50:00', N'Transferencia', 560, N'Confirmado'),
    (N'VENTA', 32, NULL, NULL, '2024-08-03T14:50:00', N'Yape', 690, N'Confirmado'),
    (N'VENTA', 33, NULL, NULL, '2024-08-07T13:40:00', N'Yape', 405, N'Confirmado'),
    (N'VENTA', 34, NULL, NULL, '2024-08-09T13:45:00', N'Efectivo', 581.75, N'Confirmado'),
    (N'VENTA', 35, NULL, NULL, '2024-08-11T12:00:00', N'Transferencia', 41.60, N'Confirmado'),
    (N'VENTA', 35, NULL, NULL, '2024-08-12T09:15:00', N'Tarjeta', 62.40, N'Confirmado'),
    (N'VENTA', 36, NULL, NULL, '2024-08-23T13:30:00', N'Efectivo', 412.50, N'Confirmado'),
    (N'VENTA', 37, NULL, NULL, '2024-08-24T11:45:00', N'Tarjeta', 148.60, N'Confirmado'),
    (N'VENTA', 38, NULL, NULL, '2024-09-09T10:15:00', N'Tarjeta', 569, N'Confirmado'),
    (N'VENTA', 39, NULL, NULL, '2024-09-10T16:50:00', N'Tarjeta', 275, N'Confirmado'),
    (N'VENTA', 40, NULL, NULL, '2024-09-18T10:00:00', N'Yape', 521.00, N'Confirmado'),
    (N'VENTA', 41, NULL, NULL, '2024-09-22T14:40:00', N'Transferencia', 123.10, N'Confirmado'),
    (N'VENTA', 42, NULL, NULL, '2024-09-22T08:00:00', N'Yape', 271.60, N'Confirmado'),
    (N'VENTA', 42, NULL, NULL, '2024-09-23T16:00:00', N'Efectivo', 407.40, N'Confirmado'),
    (N'VENTA', 43, NULL, NULL, '2024-09-26T15:20:00', N'Efectivo', 404, N'Confirmado'),
    (N'VENTA', 44, NULL, NULL, '2024-10-02T12:30:00', N'Plin', 174.75, N'Confirmado'),
    (N'VENTA', 45, NULL, NULL, '2024-10-02T15:00:00', N'Yape', 1220, N'Confirmado'),
    (N'VENTA', 46, NULL, NULL, '2024-10-08T15:15:00', N'Yape', 451.25, N'Confirmado'),
    (N'VENTA', 47, NULL, NULL, '2024-10-12T13:00:00', N'Plin', 185.25, N'Confirmado'),
    (N'VENTA', 48, NULL, NULL, '2024-10-12T16:15:00', N'Transferencia', 640, N'Confirmado'),
    (N'VENTA', 49, NULL, NULL, '2024-10-12T15:30:00', N'Efectivo', 84.00, N'Confirmado'),
    (N'VENTA', 49, NULL, NULL, '2024-10-13T10:30:00', N'Plin', 126.00, N'Confirmado'),
    (N'VENTA', 50, NULL, NULL, '2024-10-13T08:40:00', N'Efectivo', 420, N'Confirmado'),
    (N'VENTA', 51, NULL, NULL, '2024-10-16T14:20:00', N'Plin', 175, N'Confirmado'),
    (N'VENTA', 52, NULL, NULL, '2024-11-03T12:40:00', N'Tarjeta', 624.50, N'Confirmado'),
    (N'VENTA', 53, NULL, NULL, '2024-11-09T09:30:00', N'Yape', 1097.25, N'Confirmado'),
    (N'VENTA', 54, NULL, NULL, '2024-11-10T08:00:00', N'Yape', 255, N'Confirmado'),
    (N'VENTA', 55, NULL, NULL, '2024-11-16T13:15:00', N'Yape', 176.55, N'Confirmado'),
    (N'VENTA', 56, NULL, NULL, '2024-11-20T13:15:00', N'Tarjeta', 100.00, N'Confirmado'),
    (N'VENTA', 56, NULL, NULL, '2024-11-21T12:20:00', N'Efectivo', 150.00, N'Confirmado'),
    (N'VENTA', 57, NULL, NULL, '2024-11-24T12:40:00', N'Efectivo', 137.75, N'Confirmado'),
    (N'VENTA', 58, NULL, NULL, '2024-11-27T09:15:00', N'Tarjeta', 1031.25, N'Confirmado'),
    (N'VENTA', 59, NULL, NULL, '2024-12-11T16:20:00', N'Plin', 614.75, N'Confirmado'),
    (N'VENTA', 60, NULL, NULL, '2024-12-18T08:10:00', N'Tarjeta', 855, N'Confirmado'),
    (N'VENTA', 61, NULL, NULL, '2025-01-12T17:40:00', N'Plin', 120, N'Confirmado'),
    (N'VENTA', 62, NULL, NULL, '2025-01-21T11:30:00', N'Efectivo', 575, N'Confirmado'),
    (N'VENTA', 63, NULL, NULL, '2025-01-22T12:20:00', N'Yape', 55.86, N'Confirmado'),
    (N'VENTA', 63, NULL, NULL, '2025-01-23T14:15:00', N'Transferencia', 83.79, N'Confirmado'),
    (N'VENTA', 64, NULL, NULL, '2025-01-23T12:15:00', N'Transferencia', 414.50, N'Confirmado'),
    (N'VENTA', 65, NULL, NULL, '2025-01-24T09:10:00', N'Yape', 615.50, N'Confirmado'),
    (N'VENTA', 66, NULL, NULL, '2025-01-26T09:00:00', N'Efectivo', 581.50, N'Confirmado'),
    (N'VENTA', 67, NULL, NULL, '2025-01-30T11:15:00', N'Tarjeta', 530, N'Confirmado'),
    (N'VENTA', 68, NULL, NULL, '2025-02-04T11:30:00', N'Plin', 390, N'Confirmado'),
    (N'VENTA', 69, NULL, NULL, '2025-02-06T11:50:00', N'Plin', 745, N'Confirmado'),
    (N'VENTA', 70, NULL, NULL, '2025-02-09T13:00:00', N'Transferencia', 313.80, N'Confirmado'),
    (N'VENTA', 70, NULL, NULL, '2025-02-10T10:20:00', N'Plin', 470.70, N'Confirmado'),
    (N'VENTA', 71, NULL, NULL, '2025-02-09T15:20:00', N'Yape', 295, N'Confirmado'),
    (N'VENTA', 72, NULL, NULL, '2025-02-12T15:00:00', N'Yape', 503.50, N'Confirmado'),
    (N'VENTA', 73, NULL, NULL, '2025-02-21T16:10:00', N'Plin', 780, N'Confirmado'),
    (N'VENTA', 74, NULL, NULL, '2025-02-22T09:50:00', N'Yape', 365, N'Confirmado'),
    (N'VENTA', 75, NULL, NULL, '2025-03-01T12:20:00', N'Yape', 847.00, N'Confirmado'),
    (N'VENTA', 76, NULL, NULL, '2025-03-05T16:45:00', N'Yape', 150, N'Confirmado'),
    (N'VENTA', 77, NULL, NULL, '2025-03-13T11:15:00', N'Plin', 334.00, N'Confirmado'),
    (N'VENTA', 77, NULL, NULL, '2025-03-14T12:10:00', N'Efectivo', 501.00, N'Confirmado'),
    (N'VENTA', 78, NULL, NULL, '2025-03-25T17:15:00', N'Tarjeta', 385, N'Confirmado'),
    (N'VENTA', 79, NULL, NULL, '2025-03-25T13:15:00', N'Efectivo', 240, N'Confirmado'),
    (N'VENTA', 80, NULL, NULL, '2025-03-26T11:40:00', N'Plin', 780, N'Confirmado'),
    (N'VENTA', 81, NULL, NULL, '2025-03-29T12:10:00', N'Yape', 370, N'Confirmado'),
    (N'VENTA', 82, NULL, NULL, '2025-04-10T09:50:00', N'Efectivo', 565, N'Confirmado'),
    (N'VENTA', 83, NULL, NULL, '2025-04-24T08:30:00', N'Plin', 255, N'Confirmado'),
    (N'VENTA', 84, NULL, NULL, '2025-04-24T08:30:00', N'Tarjeta', 264.00, N'Confirmado'),
    (N'VENTA', 84, NULL, NULL, '2025-04-25T11:45:00', N'Plin', 396.00, N'Confirmado'),
    (N'VENTA', 85, NULL, NULL, '2025-04-27T09:10:00', N'Tarjeta', 250, N'Confirmado'),
    (N'VENTA', 86, NULL, NULL, '2025-04-29T09:50:00', N'Transferencia', 826.75, N'Confirmado'),
    (N'VENTA', 87, NULL, NULL, '2025-05-02T15:40:00', N'Yape', 890, N'Confirmado'),
    (N'VENTA', 88, NULL, NULL, '2025-05-04T16:40:00', N'Efectivo', 541.50, N'Confirmado'),
    (N'VENTA', 89, NULL, NULL, '2025-05-21T10:45:00', N'Yape', 740, N'Confirmado'),
    (N'VENTA', 90, NULL, NULL, '2025-05-23T12:45:00', N'Tarjeta', 800, N'Confirmado'),
    (N'VENTA', 91, NULL, NULL, '2025-05-26T14:15:00', N'Tarjeta', 45.00, N'Confirmado'),
    (N'VENTA', 91, NULL, NULL, '2025-05-27T15:45:00', N'Plin', 67.50, N'Confirmado'),
    (N'VENTA', 92, NULL, NULL, '2025-05-26T09:40:00', N'Yape', 310, N'Confirmado'),
    (N'VENTA', 93, NULL, NULL, '2025-06-03T16:20:00', N'Tarjeta', 498.00, N'Confirmado'),
    (N'VENTA', 94, NULL, NULL, '2025-06-06T12:15:00', N'Tarjeta', 450, N'Confirmado'),
    (N'VENTA', 95, NULL, NULL, '2025-06-10T11:10:00', N'Tarjeta', 190, N'Confirmado'),
    (N'VENTA', 96, NULL, NULL, '2025-06-13T11:15:00', N'Yape', 539, N'Confirmado'),
    (N'VENTA', 97, NULL, NULL, '2025-06-13T09:30:00', N'Tarjeta', 974.00, N'Confirmado'),
    (N'VENTA', 98, NULL, NULL, '2025-06-15T14:30:00', N'Plin', 71.00, N'Confirmado'),
    (N'VENTA', 98, NULL, NULL, '2025-06-16T11:50:00', N'Yape', 106.50, N'Confirmado'),
    (N'VENTA', 99, NULL, NULL, '2025-06-16T15:20:00', N'Yape', 389.50, N'Confirmado'),
    (N'VENTA', 100, NULL, NULL, '2025-06-18T15:00:00', N'Efectivo', 822.75, N'Confirmado'),
    (N'VENTA', 101, NULL, NULL, '2025-06-20T17:45:00', N'Efectivo', 526.50, N'Confirmado'),
    (N'VENTA', 102, NULL, NULL, '2025-06-21T11:15:00', N'Yape', 205, N'Confirmado'),
    (N'VENTA', 103, NULL, NULL, '2025-06-27T16:50:00', N'Yape', 658.25, N'Confirmado'),
    (N'VENTA', 104, NULL, NULL, '2025-07-16T10:30:00', N'Tarjeta', 1020, N'Confirmado'),
    (N'VENTA', 105, NULL, NULL, '2025-07-18T15:10:00', N'Yape', 242.00, N'Confirmado'),
    (N'VENTA', 105, NULL, NULL, '2025-07-19T13:50:00', N'Yape', 363.00, N'Confirmado'),
    (N'VENTA', 106, NULL, NULL, '2025-07-19T15:40:00', N'Efectivo', 275, N'Confirmado'),
    (N'VENTA', 107, NULL, NULL, '2025-07-24T09:45:00', N'Efectivo', 350, N'Confirmado'),
    (N'VENTA', 108, NULL, NULL, '2025-07-31T10:50:00', N'Plin', 709, N'Confirmado'),
    (N'VENTA', 109, NULL, NULL, '2025-08-02T13:40:00', N'Tarjeta', 240, N'Confirmado'),
    (N'VENTA', 110, NULL, NULL, '2025-08-12T10:20:00', N'Efectivo', 49, N'Confirmado'),
    (N'VENTA', 111, NULL, NULL, '2025-08-13T11:00:00', N'Plin', 243, N'Confirmado'),
    (N'VENTA', 112, NULL, NULL, '2025-08-16T15:00:00', N'Tarjeta', 148.00, N'Confirmado'),
    (N'VENTA', 112, NULL, NULL, '2025-08-17T17:40:00', N'Transferencia', 222.00, N'Confirmado'),
    (N'VENTA', 113, NULL, NULL, '2025-08-20T12:10:00', N'Yape', 640, N'Confirmado'),
    (N'VENTA', 114, NULL, NULL, '2025-08-23T15:50:00', N'Yape', 606.50, N'Confirmado'),
    (N'VENTA', 115, NULL, NULL, '2025-09-04T14:50:00', N'Efectivo', 1125, N'Confirmado'),
    (N'VENTA', 116, NULL, NULL, '2025-09-09T17:20:00', N'Tarjeta', 340, N'Confirmado'),
    (N'VENTA', 117, NULL, NULL, '2025-10-01T08:30:00', N'Yape', 414.50, N'Confirmado'),
    (N'VENTA', 118, NULL, NULL, '2025-10-04T14:15:00', N'Yape', 39, N'Confirmado'),
    (N'VENTA', 119, NULL, NULL, '2025-10-09T10:15:00', N'Tarjeta', 196.00, N'Confirmado'),
    (N'VENTA', 119, NULL, NULL, '2025-10-10T08:15:00', N'Efectivo', 294.00, N'Confirmado'),
    (N'VENTA', 120, NULL, NULL, '2025-10-09T10:50:00', N'Yape', 845, N'Confirmado'),
    (N'VENTA', 121, NULL, NULL, '2025-10-11T12:20:00', N'Tarjeta', 779.10, N'Confirmado'),
    (N'VENTA', 122, NULL, NULL, '2025-10-16T15:00:00', N'Efectivo', 234.25, N'Confirmado'),
    (N'VENTA', 123, NULL, NULL, '2025-10-30T13:20:00', N'Yape', 395, N'Confirmado'),
    (N'VENTA', 124, NULL, NULL, '2025-10-31T15:45:00', N'Efectivo', 67.50, N'Confirmado'),
    (N'VENTA', 125, NULL, NULL, '2025-11-01T14:45:00', N'Plin', 232.75, N'Confirmado'),
    (N'VENTA', 126, NULL, NULL, '2025-11-15T12:50:00', N'Yape', 235.60, N'Confirmado'),
    (N'VENTA', 126, NULL, NULL, '2025-11-16T16:10:00', N'Transferencia', 353.40, N'Confirmado'),
    (N'VENTA', 127, NULL, NULL, '2025-11-22T12:00:00', N'Tarjeta', 304.75, N'Confirmado'),
    (N'VENTA', 128, NULL, NULL, '2025-12-05T09:20:00', N'Efectivo', 475, N'Confirmado'),
    (N'VENTA', 129, NULL, NULL, '2025-12-17T09:30:00', N'Tarjeta', 294, N'Confirmado'),
    (N'VENTA', 130, NULL, NULL, '2025-12-17T15:40:00', N'Yape', 710.50, N'Confirmado'),
    (N'VENTA', 131, NULL, NULL, '2026-01-10T16:20:00', N'Plin', 715, N'Confirmado'),
    (N'VENTA', 132, NULL, NULL, '2026-01-14T15:20:00', N'Yape', 890, N'Confirmado');
GO

INSERT INTO dbo.Pago (tipoOperacion, idVenta, idAlquiler, idPenalidad, fechaPago, metodoPago, monto, estadoPago) VALUES
    (N'VENTA', 133, NULL, NULL, '2026-01-16T13:45:00', N'Yape', 236.00, N'Confirmado'),
    (N'VENTA', 133, NULL, NULL, '2026-01-17T16:20:00', N'Tarjeta', 354.00, N'Confirmado'),
    (N'VENTA', 134, NULL, NULL, '2026-01-23T10:10:00', N'Efectivo', 191.55, N'Confirmado'),
    (N'VENTA', 135, NULL, NULL, '2026-01-29T15:10:00', N'Efectivo', 110, N'Confirmado'),
    (N'VENTA', 136, NULL, NULL, '2026-02-03T14:30:00', N'Efectivo', 308.00, N'Confirmado'),
    (N'VENTA', 137, NULL, NULL, '2026-02-10T09:40:00', N'Yape', 845, N'Confirmado'),
    (N'VENTA', 138, NULL, NULL, '2026-02-16T11:00:00', N'Tarjeta', 264.00, N'Confirmado'),
    (N'VENTA', 139, NULL, NULL, '2026-02-20T08:15:00', N'Plin', 855.50, N'Confirmado'),
    (N'VENTA', 140, NULL, NULL, '2026-03-03T16:15:00', N'Plin', 319.90, N'Confirmado'),
    (N'VENTA', 140, NULL, NULL, '2026-03-04T10:10:00', N'Tarjeta', 479.85, N'Confirmado'),
    (N'VENTA', 141, NULL, NULL, '2026-03-06T13:45:00', N'Yape', 364.50, N'Confirmado'),
    (N'VENTA', 142, NULL, NULL, '2026-03-12T16:45:00', N'Tarjeta', 810, N'Confirmado'),
    (N'VENTA', 143, NULL, NULL, '2026-03-17T17:40:00', N'Yape', 355, N'Confirmado'),
    (N'VENTA', 144, NULL, NULL, '2026-03-28T11:50:00', N'Plin', 369.10, N'Confirmado'),
    (N'VENTA', 145, NULL, NULL, '2026-04-03T17:20:00', N'Yape', 513.05, N'Confirmado'),
    (N'VENTA', 146, NULL, NULL, '2026-04-06T16:30:00', N'Tarjeta', 394.25, N'Confirmado'),
    (N'VENTA', 147, NULL, NULL, '2026-04-12T16:50:00', N'Yape', 176.70, N'Confirmado'),
    (N'VENTA', 147, NULL, NULL, '2026-04-13T10:45:00', N'Yape', 265.05, N'Confirmado'),
    (N'VENTA', 148, NULL, NULL, '2026-04-12T10:20:00', N'Tarjeta', 1506.00, N'Confirmado'),
    (N'VENTA', 149, NULL, NULL, '2026-04-23T10:50:00', N'Tarjeta', 605, N'Confirmado'),
    (N'VENTA', 150, NULL, NULL, '2026-05-04T12:20:00', N'Yape', 390, N'Confirmado'),
    (N'VENTA', 151, NULL, NULL, '2026-05-04T14:00:00', N'Tarjeta', 540, N'Confirmado'),
    (N'VENTA', 152, NULL, NULL, '2026-05-06T11:20:00', N'Tarjeta', 467.50, N'Confirmado'),
    (N'VENTA', 153, NULL, NULL, '2026-05-13T14:30:00', N'Transferencia', 454.50, N'Confirmado'),
    (N'VENTA', 154, NULL, NULL, '2026-05-27T13:10:00', N'Plin', 180.50, N'Confirmado'),
    (N'VENTA', 154, NULL, NULL, '2026-05-28T11:45:00', N'Plin', 270.75, N'Confirmado'),
    (N'VENTA', 155, NULL, NULL, '2026-06-03T13:50:00', N'Yape', 600, N'Confirmado'),
    (N'VENTA', 156, NULL, NULL, '2026-06-12T16:20:00', N'Tarjeta', 375.25, N'Confirmado'),
    (N'VENTA', 157, NULL, NULL, '2026-06-15T14:10:00', N'Tarjeta', 601.25, N'Confirmado'),
    (N'VENTA', 158, NULL, NULL, '2026-06-16T15:30:00', N'Tarjeta', 39, N'Confirmado'),
    (N'VENTA', 159, NULL, NULL, '2026-06-19T12:30:00', N'Efectivo', 166.25, N'Confirmado'),
    (N'VENTA', 160, NULL, NULL, '2026-06-22T15:10:00', N'Yape', 150, N'Confirmado'),
    (N'VENTA', 161, NULL, NULL, '2026-06-25T14:20:00', N'Tarjeta', 220.00, N'Confirmado'),
    (N'VENTA', 161, NULL, NULL, '2026-06-26T16:50:00', N'Tarjeta', 330.00, N'Confirmado'),
    (N'VENTA', 162, NULL, NULL, '2026-07-01T14:20:00', N'Tarjeta', 925, N'Confirmado'),
    (N'VENTA', 163, NULL, NULL, '2026-07-02T16:45:00', N'Tarjeta', 240, N'Confirmado'),
    (N'VENTA', 164, NULL, NULL, '2026-07-06T11:20:00', N'Tarjeta', 410, N'Confirmado'),
    (N'VENTA', 165, NULL, NULL, '2026-07-25T16:15:00', N'Yape', 990, N'Confirmado'),
    (N'VENTA', 166, NULL, NULL, '2026-07-29T13:00:00', N'Yape', 560.50, N'Confirmado'),
    (N'VENTA', 167, NULL, NULL, '2026-08-02T14:30:00', N'Efectivo', 690, N'Confirmado'),
    (N'VENTA', 168, NULL, NULL, '2026-08-13T10:15:00', N'Tarjeta', 175.20, N'Confirmado'),
    (N'VENTA', 168, NULL, NULL, '2026-08-14T12:30:00', N'Efectivo', 262.80, N'Confirmado'),
    (N'VENTA', 169, NULL, NULL, '2026-08-16T09:20:00', N'Tarjeta', 440, N'Confirmado'),
    (N'VENTA', 170, NULL, NULL, '2026-08-18T12:15:00', N'Transferencia', 563.50, N'Confirmado'),
    (N'VENTA', 171, NULL, NULL, '2026-08-30T11:20:00', N'Tarjeta', 385.50, N'Confirmado'),
    (N'VENTA', 172, NULL, NULL, '2026-08-30T13:10:00', N'Tarjeta', 473.75, N'Confirmado'),
    (N'VENTA', 173, NULL, NULL, '2026-09-01T17:40:00', N'Yape', 166.25, N'Confirmado'),
    (N'VENTA', 174, NULL, NULL, '2026-09-01T16:45:00', N'Tarjeta', 430, N'Confirmado'),
    (N'VENTA', 175, NULL, NULL, '2026-09-13T14:50:00', N'Transferencia', 216.00, N'Confirmado'),
    (N'VENTA', 175, NULL, NULL, '2026-09-14T13:45:00', N'Plin', 324.00, N'Confirmado'),
    (N'VENTA', 176, NULL, NULL, '2026-09-18T17:15:00', N'Plin', 261.00, N'Confirmado'),
    (N'VENTA', 177, NULL, NULL, '2026-09-18T08:30:00', N'Tarjeta', 210, N'Confirmado'),
    (N'VENTA', 178, NULL, NULL, '2026-09-24T17:50:00', N'Yape', 750, N'Confirmado'),
    (N'VENTA', 179, NULL, NULL, '2026-09-25T14:15:00', N'Tarjeta', 75, N'Confirmado'),
    (N'VENTA', 180, NULL, NULL, '2026-09-29T09:20:00', N'Tarjeta', 378.00, N'Confirmado'),
    (N'VENTA', 181, NULL, NULL, '2026-10-03T12:30:00', N'Plin', 880.50, N'Confirmado'),
    (N'VENTA', 182, NULL, NULL, '2026-10-04T11:20:00', N'Efectivo', 408.00, N'Confirmado'),
    (N'VENTA', 182, NULL, NULL, '2026-10-05T11:45:00', N'Transferencia', 612.00, N'Confirmado'),
    (N'VENTA', 183, NULL, NULL, '2026-10-04T13:10:00', N'Efectivo', 261.25, N'Confirmado'),
    (N'VENTA', 184, NULL, NULL, '2026-10-06T14:20:00', N'Efectivo', 14.50, N'Confirmado'),
    (N'VENTA', 185, NULL, NULL, '2026-10-13T15:00:00', N'Plin', 917.00, N'Confirmado'),
    (N'ALQUILER', NULL, 1, NULL, '2024-01-08T16:10:00', N'Efectivo', 220, N'Confirmado'),
    (N'ALQUILER', NULL, 2, NULL, '2024-01-18T10:45:00', N'Tarjeta', 66.50, N'Confirmado'),
    (N'ALQUILER', NULL, 3, NULL, '2024-01-19T16:15:00', N'Yape', 150, N'Confirmado'),
    (N'ALQUILER', NULL, 4, NULL, '2024-01-26T14:10:00', N'Efectivo', 145, N'Confirmado'),
    (N'ALQUILER', NULL, 5, NULL, '2024-01-26T08:15:00', N'Plin', 120, N'Confirmado'),
    (N'ALQUILER', NULL, 6, NULL, '2024-01-28T12:20:00', N'Plin', 71.00, N'Confirmado'),
    (N'ALQUILER', NULL, 6, NULL, '2024-02-03T13:00:00', N'Efectivo', 71.00, N'Confirmado'),
    (N'ALQUILER', NULL, 7, NULL, '2024-02-01T17:00:00', N'Tarjeta', 270, N'Confirmado'),
    (N'ALQUILER', NULL, 8, NULL, '2024-02-02T08:45:00', N'Transferencia', 120, N'Confirmado'),
    (N'ALQUILER', NULL, 9, NULL, '2024-02-12T16:30:00', N'Yape', 52.25, N'Confirmado'),
    (N'ALQUILER', NULL, 10, NULL, '2024-02-14T10:00:00', N'Yape', 58.50, N'Confirmado'),
    (N'ALQUILER', NULL, 11, NULL, '2024-02-17T16:10:00', N'Yape', 80, N'Confirmado'),
    (N'ALQUILER', NULL, 12, NULL, '2024-02-18T15:15:00', N'Yape', 132.50, N'Confirmado'),
    (N'ALQUILER', NULL, 12, NULL, '2024-02-21T12:45:00', N'Yape', 132.50, N'Confirmado'),
    (N'ALQUILER', NULL, 13, NULL, '2024-03-05T10:45:00', N'Tarjeta', 260, N'Confirmado'),
    (N'ALQUILER', NULL, 14, NULL, '2024-03-17T14:50:00', N'Transferencia', 70, N'Confirmado'),
    (N'ALQUILER', NULL, 15, NULL, '2024-03-23T11:40:00', N'Transferencia', 185, N'Confirmado'),
    (N'ALQUILER', NULL, 16, NULL, '2024-03-26T16:10:00', N'Efectivo', 90, N'Confirmado'),
    (N'ALQUILER', NULL, 17, NULL, '2024-03-28T13:00:00', N'Tarjeta', 184.50, N'Confirmado'),
    (N'ALQUILER', NULL, 18, NULL, '2024-04-03T10:10:00', N'Efectivo', 127.50, N'Confirmado'),
    (N'ALQUILER', NULL, 18, NULL, '2024-04-06T11:45:00', N'Yape', 127.50, N'Confirmado'),
    (N'ALQUILER', NULL, 19, NULL, '2024-04-04T09:45:00', N'Plin', 120, N'Confirmado'),
    (N'ALQUILER', NULL, 20, NULL, '2024-04-04T08:10:00', N'Yape', 55, N'Confirmado'),
    (N'ALQUILER', NULL, 21, NULL, '2024-04-13T08:45:00', N'Yape', 120, N'Confirmado'),
    (N'ALQUILER', NULL, 22, NULL, '2024-04-22T13:50:00', N'Efectivo', 62.25, N'Confirmado'),
    (N'ALQUILER', NULL, 23, NULL, '2024-04-28T09:20:00', N'Efectivo', 120, N'Confirmado'),
    (N'ALQUILER', NULL, 24, NULL, '2024-05-01T15:00:00', N'Yape', 90.00, N'Confirmado'),
    (N'ALQUILER', NULL, 24, NULL, '2024-05-06T16:15:00', N'Plin', 90.00, N'Confirmado'),
    (N'ALQUILER', NULL, 25, NULL, '2024-05-05T16:50:00', N'Yape', 345.25, N'Confirmado'),
    (N'ALQUILER', NULL, 26, NULL, '2024-05-12T10:30:00', N'Plin', 275, N'Confirmado'),
    (N'ALQUILER', NULL, 27, NULL, '2024-05-17T08:50:00', N'Tarjeta', 150, N'Confirmado'),
    (N'ALQUILER', NULL, 28, NULL, '2024-05-18T15:15:00', N'Transferencia', 240.75, N'Confirmado'),
    (N'ALQUILER', NULL, 29, NULL, '2024-05-29T14:40:00', N'Efectivo', 150, N'Confirmado'),
    (N'ALQUILER', NULL, 30, NULL, '2024-05-29T15:40:00', N'Tarjeta', 95.00, N'Confirmado'),
    (N'ALQUILER', NULL, 30, NULL, '2024-06-04T10:00:00', N'Tarjeta', 95.00, N'Confirmado'),
    (N'ALQUILER', NULL, 31, NULL, '2024-06-02T16:10:00', N'Tarjeta', 55, N'Confirmado'),
    (N'ALQUILER', NULL, 32, NULL, '2024-06-03T16:00:00', N'Plin', 175, N'Confirmado'),
    (N'ALQUILER', NULL, 33, NULL, '2024-06-05T16:50:00', N'Yape', 145, N'Confirmado'),
    (N'ALQUILER', NULL, 34, NULL, '2024-06-08T10:10:00', N'Tarjeta', 164.75, N'Confirmado'),
    (N'ALQUILER', NULL, 35, NULL, '2024-06-14T14:50:00', N'Yape', 85.50, N'Confirmado'),
    (N'ALQUILER', NULL, 36, NULL, '2024-06-14T12:30:00', N'Tarjeta', 125.00, N'Confirmado'),
    (N'ALQUILER', NULL, 36, NULL, '2024-06-17T10:00:00', N'Yape', 125.00, N'Confirmado'),
    (N'ALQUILER', NULL, 37, NULL, '2024-06-23T14:50:00', N'Plin', 255, N'Confirmado'),
    (N'ALQUILER', NULL, 38, NULL, '2024-07-03T08:45:00', N'Tarjeta', 70, N'Confirmado'),
    (N'ALQUILER', NULL, 39, NULL, '2024-07-04T16:45:00', N'Tarjeta', 120, N'Confirmado'),
    (N'ALQUILER', NULL, 40, NULL, '2024-07-14T14:00:00', N'Tarjeta', 255, N'Confirmado'),
    (N'ALQUILER', NULL, 41, NULL, '2024-07-17T16:50:00', N'Tarjeta', 52.25, N'Confirmado'),
    (N'ALQUILER', NULL, 42, NULL, '2024-07-19T08:50:00', N'Plin', 92.50, N'Confirmado'),
    (N'ALQUILER', NULL, 42, NULL, '2024-07-26T09:30:00', N'Yape', 92.50, N'Confirmado'),
    (N'ALQUILER', NULL, 43, NULL, '2024-07-25T12:30:00', N'Tarjeta', 310, N'Confirmado'),
    (N'ALQUILER', NULL, 44, NULL, '2024-07-29T10:20:00', N'Tarjeta', 205.50, N'Confirmado'),
    (N'ALQUILER', NULL, 45, NULL, '2024-07-30T13:15:00', N'Yape', 110, N'Confirmado'),
    (N'ALQUILER', NULL, 46, NULL, '2024-08-10T08:20:00', N'Yape', 145, N'Confirmado'),
    (N'ALQUILER', NULL, 47, NULL, '2024-08-12T09:40:00', N'Efectivo', 185, N'Confirmado'),
    (N'ALQUILER', NULL, 48, NULL, '2024-08-23T12:50:00', N'Efectivo', 107.12, N'Confirmado'),
    (N'ALQUILER', NULL, 48, NULL, '2024-08-26T12:45:00', N'Yape', 107.13, N'Confirmado'),
    (N'ALQUILER', NULL, 49, NULL, '2024-08-31T11:10:00', N'Yape', 190, N'Confirmado'),
    (N'ALQUILER', NULL, 50, NULL, '2024-09-15T15:20:00', N'Efectivo', 260, N'Confirmado'),
    (N'ALQUILER', NULL, 51, NULL, '2024-09-20T16:15:00', N'Yape', 115, N'Confirmado'),
    (N'ALQUILER', NULL, 52, NULL, '2024-09-22T12:15:00', N'Efectivo', 258.00, N'Confirmado'),
    (N'ALQUILER', NULL, 53, NULL, '2024-09-23T12:10:00', N'Efectivo', 160, N'Confirmado'),
    (N'ALQUILER', NULL, 54, NULL, '2024-09-24T10:10:00', N'Yape', 72.50, N'Confirmado'),
    (N'ALQUILER', NULL, 54, NULL, '2024-09-29T15:00:00', N'Yape', 72.50, N'Confirmado'),
    (N'ALQUILER', NULL, 55, NULL, '2024-09-29T17:30:00', N'Plin', 415, N'Confirmado'),
    (N'ALQUILER', NULL, 56, NULL, '2024-09-29T15:20:00', N'Tarjeta', 380.75, N'Confirmado'),
    (N'ALQUILER', NULL, 57, NULL, '2024-09-30T17:20:00', N'Yape', 264.00, N'Confirmado'),
    (N'ALQUILER', NULL, 58, NULL, '2024-10-09T12:10:00', N'Tarjeta', 175, N'Confirmado'),
    (N'ALQUILER', NULL, 59, NULL, '2024-10-16T14:50:00', N'Tarjeta', 120, N'Confirmado'),
    (N'ALQUILER', NULL, 60, NULL, '2024-10-18T17:20:00', N'Tarjeta', 87.50, N'Confirmado'),
    (N'ALQUILER', NULL, 60, NULL, '2024-10-22T10:45:00', N'Efectivo', 87.50, N'Confirmado'),
    (N'ALQUILER', NULL, 61, NULL, '2024-10-31T10:50:00', N'Plin', 55, N'Confirmado'),
    (N'ALQUILER', NULL, 62, NULL, '2024-11-02T08:45:00', N'Plin', 70, N'Confirmado'),
    (N'ALQUILER', NULL, 63, NULL, '2024-11-04T15:40:00', N'Plin', 151, N'Confirmado'),
    (N'ALQUILER', NULL, 64, NULL, '2024-11-07T10:40:00', N'Transferencia', 55, N'Confirmado'),
    (N'ALQUILER', NULL, 65, NULL, '2024-11-13T09:40:00', N'Efectivo', 125, N'Confirmado'),
    (N'ALQUILER', NULL, 66, NULL, '2024-11-21T12:50:00', N'Yape', 57.50, N'Confirmado'),
    (N'ALQUILER', NULL, 66, NULL, '2024-11-26T11:45:00', N'Tarjeta', 57.50, N'Confirmado'),
    (N'ALQUILER', NULL, 67, NULL, '2024-11-22T15:30:00', N'Yape', 155, N'Confirmado'),
    (N'ALQUILER', NULL, 68, NULL, '2024-11-24T08:45:00', N'Plin', 52.25, N'Confirmado'),
    (N'ALQUILER', NULL, 69, NULL, '2024-12-04T11:00:00', N'Yape', 194.75, N'Confirmado'),
    (N'ALQUILER', NULL, 70, NULL, '2024-12-11T16:00:00', N'Efectivo', 190, N'Confirmado'),
    (N'ALQUILER', NULL, 71, NULL, '2025-01-10T16:00:00', N'Yape', 209.50, N'Confirmado'),
    (N'ALQUILER', NULL, 72, NULL, '2025-01-10T12:10:00', N'Plin', 60.00, N'Confirmado'),
    (N'ALQUILER', NULL, 72, NULL, '2025-01-12T13:15:00', N'Plin', 60.00, N'Confirmado'),
    (N'ALQUILER', NULL, 73, NULL, '2025-01-10T08:45:00', N'Tarjeta', 231.50, N'Confirmado'),
    (N'ALQUILER', NULL, 74, NULL, '2025-01-19T08:45:00', N'Plin', 109.25, N'Confirmado'),
    (N'ALQUILER', NULL, 75, NULL, '2025-01-21T11:30:00', N'Yape', 145, N'Confirmado'),
    (N'ALQUILER', NULL, 76, NULL, '2025-01-21T13:15:00', N'Efectivo', 335, N'Confirmado'),
    (N'ALQUILER', NULL, 77, NULL, '2025-01-22T16:15:00', N'Efectivo', 277.00, N'Confirmado');
GO

INSERT INTO dbo.Pago (tipoOperacion, idVenta, idAlquiler, idPenalidad, fechaPago, metodoPago, monto, estadoPago) VALUES
    (N'ALQUILER', NULL, 78, NULL, '2025-01-27T08:00:00', N'Plin', 114.75, N'Confirmado'),
    (N'ALQUILER', NULL, 78, NULL, '2025-01-31T12:00:00', N'Yape', 114.75, N'Confirmado'),
    (N'ALQUILER', NULL, 79, NULL, '2025-02-05T13:45:00', N'Yape', 182, N'Confirmado'),
    (N'ALQUILER', NULL, 80, NULL, '2025-02-06T10:20:00', N'Plin', 65, N'Confirmado'),
    (N'ALQUILER', NULL, 81, NULL, '2025-02-06T16:50:00', N'Efectivo', 290, N'Confirmado'),
    (N'ALQUILER', NULL, 82, NULL, '2025-02-07T14:45:00', N'Efectivo', 185, N'Confirmado'),
    (N'ALQUILER', NULL, 83, NULL, '2025-02-09T09:00:00', N'Tarjeta', 180, N'Confirmado'),
    (N'ALQUILER', NULL, 84, NULL, '2025-02-16T12:15:00', N'Tarjeta', 95.00, N'Confirmado'),
    (N'ALQUILER', NULL, 84, NULL, '2025-02-20T11:15:00', N'Yape', 95.00, N'Confirmado'),
    (N'ALQUILER', NULL, 85, NULL, '2025-03-01T13:45:00', N'Plin', 390, N'Confirmado'),
    (N'ALQUILER', NULL, 86, NULL, '2025-03-09T12:45:00', N'Transferencia', 55, N'Confirmado'),
    (N'ALQUILER', NULL, 87, NULL, '2025-03-13T08:40:00', N'Yape', 155, N'Confirmado'),
    (N'ALQUILER', NULL, 88, NULL, '2025-03-13T17:00:00', N'Yape', 120, N'Confirmado'),
    (N'ALQUILER', NULL, 89, NULL, '2025-03-20T09:15:00', N'Tarjeta', 115, N'Confirmado'),
    (N'ALQUILER', NULL, 90, NULL, '2025-04-04T12:50:00', N'Yape', 107.50, N'Confirmado'),
    (N'ALQUILER', NULL, 90, NULL, '2025-04-07T09:45:00', N'Yape', 107.50, N'Confirmado'),
    (N'ALQUILER', NULL, 91, NULL, '2025-04-09T13:45:00', N'Efectivo', 245, N'Confirmado'),
    (N'ALQUILER', NULL, 92, NULL, '2025-04-10T12:00:00', N'Efectivo', 325, N'Confirmado'),
    (N'ALQUILER', NULL, 93, NULL, '2025-04-14T09:15:00', N'Tarjeta', 215, N'Confirmado'),
    (N'ALQUILER', NULL, 94, NULL, '2025-04-20T13:10:00', N'Yape', 193.50, N'Confirmado'),
    (N'ALQUILER', NULL, 95, NULL, '2025-05-02T08:30:00', N'Efectivo', 120, N'Confirmado'),
    (N'ALQUILER', NULL, 96, NULL, '2025-05-03T12:50:00', N'Yape', 237.50, N'Confirmado'),
    (N'ALQUILER', NULL, 96, NULL, '2025-05-09T15:15:00', N'Yape', 237.50, N'Confirmado'),
    (N'ALQUILER', NULL, 97, NULL, '2025-05-05T16:50:00', N'Efectivo', 215, N'Confirmado'),
    (N'ALQUILER', NULL, 98, NULL, '2025-05-08T15:45:00', N'Transferencia', 221.50, N'Confirmado'),
    (N'ALQUILER', NULL, 99, NULL, '2025-05-21T13:45:00', N'Tarjeta', 147, N'Confirmado'),
    (N'ALQUILER', NULL, 100, NULL, '2025-05-30T14:30:00', N'Transferencia', 227.25, N'Confirmado'),
    (N'ALQUILER', NULL, 101, NULL, '2025-06-03T10:50:00', N'Efectivo', 180.50, N'Confirmado'),
    (N'ALQUILER', NULL, 102, NULL, '2025-06-18T08:00:00', N'Yape', 87.88, N'Confirmado'),
    (N'ALQUILER', NULL, 102, NULL, '2025-06-21T12:15:00', N'Tarjeta', 87.87, N'Confirmado'),
    (N'ALQUILER', NULL, 103, NULL, '2025-06-19T13:10:00', N'Yape', 171.00, N'Confirmado'),
    (N'ALQUILER', NULL, 104, NULL, '2025-06-25T16:10:00', N'Yape', 225, N'Confirmado'),
    (N'ALQUILER', NULL, 105, NULL, '2025-06-28T17:50:00', N'Yape', 150, N'Confirmado'),
    (N'ALQUILER', NULL, 106, NULL, '2025-06-30T15:10:00', N'Transferencia', 65, N'Confirmado'),
    (N'ALQUILER', NULL, 107, NULL, '2025-07-03T10:10:00', N'Transferencia', 66.50, N'Confirmado'),
    (N'ALQUILER', NULL, 108, NULL, '2025-07-13T17:10:00', N'Transferencia', 99.75, N'Confirmado'),
    (N'ALQUILER', NULL, 108, NULL, '2025-07-17T14:30:00', N'Efectivo', 99.75, N'Confirmado'),
    (N'ALQUILER', NULL, 109, NULL, '2025-07-13T08:40:00', N'Yape', 325, N'Confirmado'),
    (N'ALQUILER', NULL, 110, NULL, '2025-07-15T09:30:00', N'Yape', 290, N'Confirmado'),
    (N'ALQUILER', NULL, 111, NULL, '2025-07-17T13:40:00', N'Tarjeta', 250, N'Confirmado'),
    (N'ALQUILER', NULL, 112, NULL, '2025-07-24T15:10:00', N'Tarjeta', 140, N'Confirmado'),
    (N'ALQUILER', NULL, 113, NULL, '2025-07-27T10:15:00', N'Efectivo', 52.25, N'Confirmado'),
    (N'ALQUILER', NULL, 114, NULL, '2025-08-02T11:10:00', N'Yape', 60.00, N'Confirmado'),
    (N'ALQUILER', NULL, 114, NULL, '2025-08-08T13:00:00', N'Efectivo', 60.00, N'Confirmado'),
    (N'ALQUILER', NULL, 115, NULL, '2025-08-06T12:30:00', N'Transferencia', 230, N'Confirmado'),
    (N'ALQUILER', NULL, 116, NULL, '2025-08-07T08:00:00', N'Yape', 245, N'Confirmado'),
    (N'ALQUILER', NULL, 117, NULL, '2025-08-11T14:10:00', N'Tarjeta', 190, N'Confirmado'),
    (N'ALQUILER', NULL, 118, NULL, '2025-08-15T08:40:00', N'Plin', 150, N'Confirmado'),
    (N'ALQUILER', NULL, 119, NULL, '2025-08-18T15:40:00', N'Tarjeta', 230, N'Confirmado'),
    (N'ALQUILER', NULL, 120, NULL, '2025-08-22T14:10:00', N'Efectivo', 97.38, N'Confirmado'),
    (N'ALQUILER', NULL, 120, NULL, '2025-08-25T15:30:00', N'Yape', 97.37, N'Confirmado'),
    (N'ALQUILER', NULL, 121, NULL, '2025-08-22T17:10:00', N'Efectivo', 265, N'Confirmado'),
    (N'ALQUILER', NULL, 122, NULL, '2025-08-30T10:45:00', N'Yape', 49.50, N'Confirmado'),
    (N'ALQUILER', NULL, 123, NULL, '2025-09-05T12:15:00', N'Efectivo', 452.50, N'Confirmado'),
    (N'ALQUILER', NULL, 124, NULL, '2025-09-06T08:50:00', N'Tarjeta', 144.00, N'Confirmado'),
    (N'ALQUILER', NULL, 125, NULL, '2025-09-08T09:50:00', N'Plin', 160, N'Confirmado'),
    (N'ALQUILER', NULL, 126, NULL, '2025-09-12T11:45:00', N'Efectivo', 95.00, N'Confirmado'),
    (N'ALQUILER', NULL, 126, NULL, '2025-09-15T15:00:00', N'Tarjeta', 95.00, N'Confirmado'),
    (N'ALQUILER', NULL, 127, NULL, '2025-09-17T17:45:00', N'Plin', 114.00, N'Confirmado'),
    (N'ALQUILER', NULL, 128, NULL, '2025-09-18T14:30:00', N'Yape', 280, N'Confirmado'),
    (N'ALQUILER', NULL, 129, NULL, '2025-09-18T16:20:00', N'Yape', 135.00, N'Confirmado'),
    (N'ALQUILER', NULL, 130, NULL, '2025-09-19T16:45:00', N'Yape', 180, N'Confirmado'),
    (N'ALQUILER', NULL, 131, NULL, '2025-09-25T11:00:00', N'Yape', 139.50, N'Confirmado'),
    (N'ALQUILER', NULL, 132, NULL, '2025-10-01T16:20:00', N'Plin', 52.50, N'Confirmado'),
    (N'ALQUILER', NULL, 132, NULL, '2025-10-03T09:15:00', N'Transferencia', 52.50, N'Confirmado'),
    (N'ALQUILER', NULL, 133, NULL, '2025-10-06T11:00:00', N'Efectivo', 126.25, N'Confirmado'),
    (N'ALQUILER', NULL, 134, NULL, '2025-10-07T14:45:00', N'Tarjeta', 245.50, N'Confirmado'),
    (N'ALQUILER', NULL, 135, NULL, '2025-10-07T11:15:00', N'Yape', 255.00, N'Confirmado'),
    (N'ALQUILER', NULL, 136, NULL, '2025-10-09T13:00:00', N'Plin', 109.25, N'Confirmado'),
    (N'ALQUILER', NULL, 137, NULL, '2025-10-09T17:20:00', N'Plin', 333.25, N'Confirmado'),
    (N'ALQUILER', NULL, 138, NULL, '2025-10-10T11:10:00', N'Plin', 67.50, N'Confirmado'),
    (N'ALQUILER', NULL, 138, NULL, '2025-10-16T16:45:00', N'Efectivo', 67.50, N'Confirmado'),
    (N'ALQUILER', NULL, 139, NULL, '2025-10-10T13:10:00', N'Transferencia', 235, N'Confirmado'),
    (N'ALQUILER', NULL, 140, NULL, '2025-10-12T14:10:00', N'Tarjeta', 225, N'Confirmado'),
    (N'ALQUILER', NULL, 141, NULL, '2025-10-15T15:15:00', N'Yape', 345, N'Confirmado'),
    (N'ALQUILER', NULL, 142, NULL, '2025-10-21T11:50:00', N'Yape', 321.75, N'Confirmado'),
    (N'ALQUILER', NULL, 143, NULL, '2025-10-23T15:15:00', N'Yape', 65, N'Confirmado'),
    (N'ALQUILER', NULL, 144, NULL, '2025-10-24T10:15:00', N'Efectivo', 27.50, N'Confirmado'),
    (N'ALQUILER', NULL, 144, NULL, '2025-10-29T11:45:00', N'Yape', 27.50, N'Confirmado'),
    (N'ALQUILER', NULL, 145, NULL, '2025-10-31T15:00:00', N'Tarjeta', 150, N'Confirmado'),
    (N'ALQUILER', NULL, 146, NULL, '2025-11-20T09:00:00', N'Tarjeta', 65, N'Confirmado'),
    (N'ALQUILER', NULL, 147, NULL, '2025-11-21T11:00:00', N'Transferencia', 194.75, N'Confirmado'),
    (N'ALQUILER', NULL, 148, NULL, '2025-11-21T09:30:00', N'Yape', 215, N'Confirmado'),
    (N'ALQUILER', NULL, 149, NULL, '2025-11-24T10:00:00', N'Tarjeta', 170, N'Confirmado'),
    (N'ALQUILER', NULL, 150, NULL, '2025-11-27T11:10:00', N'Yape', 62.50, N'Confirmado'),
    (N'ALQUILER', NULL, 150, NULL, '2025-12-01T11:30:00', N'Yape', 62.50, N'Confirmado'),
    (N'ALQUILER', NULL, 151, NULL, '2025-11-28T11:15:00', N'Transferencia', 140, N'Confirmado'),
    (N'ALQUILER', NULL, 152, NULL, '2025-11-28T15:30:00', N'Transferencia', 380, N'Confirmado'),
    (N'ALQUILER', NULL, 153, NULL, '2025-12-05T13:20:00', N'Yape', 125, N'Confirmado'),
    (N'ALQUILER', NULL, 154, NULL, '2025-12-08T13:10:00', N'Tarjeta', 232.50, N'Confirmado'),
    (N'ALQUILER', NULL, 155, NULL, '2025-12-09T17:50:00', N'Transferencia', 215, N'Confirmado'),
    (N'ALQUILER', NULL, 156, NULL, '2025-12-11T16:40:00', N'Tarjeta', 110.00, N'Confirmado'),
    (N'ALQUILER', NULL, 156, NULL, '2025-12-13T14:45:00', N'Tarjeta', 110.00, N'Confirmado'),
    (N'ALQUILER', NULL, 157, NULL, '2025-12-17T13:30:00', N'Yape', 420.50, N'Confirmado'),
    (N'ALQUILER', NULL, 158, NULL, '2025-12-22T17:50:00', N'Yape', 24, N'Confirmado'),
    (N'ALQUILER', NULL, 159, NULL, '2026-01-13T13:50:00', N'Tarjeta', 115, N'Confirmado'),
    (N'ALQUILER', NULL, 160, NULL, '2026-01-18T08:00:00', N'Yape', 180, N'Confirmado'),
    (N'ALQUILER', NULL, 161, NULL, '2026-01-22T17:15:00', N'Efectivo', 175, N'Confirmado'),
    (N'ALQUILER', NULL, 162, NULL, '2026-01-22T10:00:00', N'Efectivo', 126.50, N'Confirmado'),
    (N'ALQUILER', NULL, 162, NULL, '2026-01-27T10:15:00', N'Efectivo', 126.50, N'Confirmado'),
    (N'ALQUILER', NULL, 163, NULL, '2026-01-26T10:00:00', N'Transferencia', 180, N'Confirmado'),
    (N'ALQUILER', NULL, 164, NULL, '2026-01-27T11:40:00', N'Yape', 180, N'Confirmado'),
    (N'ALQUILER', NULL, 165, NULL, '2026-01-27T09:10:00', N'Tarjeta', 355, N'Confirmado'),
    (N'ALQUILER', NULL, 166, NULL, '2026-01-30T08:50:00', N'Efectivo', 70, N'Confirmado'),
    (N'ALQUILER', NULL, 167, NULL, '2026-02-03T13:50:00', N'Yape', 180, N'Confirmado'),
    (N'ALQUILER', NULL, 168, NULL, '2026-02-09T12:40:00', N'Plin', 177.50, N'Confirmado'),
    (N'ALQUILER', NULL, 168, NULL, '2026-02-16T13:45:00', N'Yape', 177.50, N'Confirmado'),
    (N'ALQUILER', NULL, 169, NULL, '2026-02-15T10:10:00', N'Efectivo', 140, N'Confirmado'),
    (N'ALQUILER', NULL, 170, NULL, '2026-02-16T11:00:00', N'Yape', 215, N'Confirmado'),
    (N'ALQUILER', NULL, 171, NULL, '2026-02-19T13:00:00', N'Efectivo', 323.75, N'Confirmado'),
    (N'ALQUILER', NULL, 172, NULL, '2026-02-22T12:10:00', N'Efectivo', 376.25, N'Confirmado'),
    (N'ALQUILER', NULL, 173, NULL, '2026-02-23T08:10:00', N'Yape', 135, N'Confirmado'),
    (N'ALQUILER', NULL, 174, NULL, '2026-02-28T17:00:00', N'Yape', 103.25, N'Confirmado'),
    (N'ALQUILER', NULL, 174, NULL, '2026-03-05T13:45:00', N'Efectivo', 103.25, N'Confirmado'),
    (N'ALQUILER', NULL, 175, NULL, '2026-03-04T13:40:00', N'Efectivo', 205, N'Confirmado'),
    (N'ALQUILER', NULL, 176, NULL, '2026-03-07T13:50:00', N'Yape', 104.50, N'Confirmado'),
    (N'ALQUILER', NULL, 177, NULL, '2026-03-23T15:50:00', N'Yape', 99.75, N'Confirmado'),
    (N'ALQUILER', NULL, 178, NULL, '2026-03-27T12:40:00', N'Yape', 260, N'Confirmado'),
    (N'ALQUILER', NULL, 179, NULL, '2026-03-30T08:10:00', N'Yape', 205, N'Confirmado'),
    (N'ALQUILER', NULL, 180, NULL, '2026-04-06T13:45:00', N'Plin', 3.00, N'Confirmado'),
    (N'ALQUILER', NULL, 180, NULL, '2026-04-12T14:15:00', N'Yape', 3.00, N'Confirmado'),
    (N'ALQUILER', NULL, 181, NULL, '2026-04-15T11:50:00', N'Efectivo', 114.00, N'Confirmado'),
    (N'ALQUILER', NULL, 182, NULL, '2026-04-17T11:10:00', N'Yape', 292.00, N'Confirmado'),
    (N'ALQUILER', NULL, 183, NULL, '2026-04-25T11:15:00', N'Tarjeta', 65, N'Confirmado'),
    (N'ALQUILER', NULL, 184, NULL, '2026-04-26T10:15:00', N'Yape', 99.75, N'Confirmado'),
    (N'ALQUILER', NULL, 185, NULL, '2026-04-28T16:45:00', N'Tarjeta', 208, N'Confirmado'),
    (N'ALQUILER', NULL, 186, NULL, '2026-04-30T08:50:00', N'Yape', 75.00, N'Confirmado'),
    (N'ALQUILER', NULL, 186, NULL, '2026-05-04T13:45:00', N'Yape', 75.00, N'Confirmado'),
    (N'ALQUILER', NULL, 187, NULL, '2026-05-02T14:40:00', N'Efectivo', 340, N'Confirmado'),
    (N'ALQUILER', NULL, 188, NULL, '2026-05-04T09:50:00', N'Efectivo', 194.75, N'Confirmado'),
    (N'ALQUILER', NULL, 189, NULL, '2026-05-12T10:00:00', N'Tarjeta', 240, N'Confirmado'),
    (N'ALQUILER', NULL, 190, NULL, '2026-05-22T13:10:00', N'Efectivo', 250, N'Confirmado'),
    (N'ALQUILER', NULL, 191, NULL, '2026-05-24T15:00:00', N'Yape', 112.50, N'Confirmado'),
    (N'ALQUILER', NULL, 192, NULL, '2026-05-28T09:40:00', N'Plin', 62.50, N'Confirmado'),
    (N'ALQUILER', NULL, 192, NULL, '2026-06-03T13:00:00', N'Plin', 62.50, N'Confirmado'),
    (N'ALQUILER', NULL, 193, NULL, '2026-05-31T13:50:00', N'Tarjeta', 243.75, N'Confirmado'),
    (N'ALQUILER', NULL, 194, NULL, '2026-06-02T16:15:00', N'Yape', 55, N'Confirmado'),
    (N'ALQUILER', NULL, 195, NULL, '2026-06-16T09:50:00', N'Transferencia', 110, N'Confirmado'),
    (N'ALQUILER', NULL, 196, NULL, '2026-06-16T17:40:00', N'Tarjeta', 294.00, N'Confirmado'),
    (N'ALQUILER', NULL, 197, NULL, '2026-06-19T16:15:00', N'Efectivo', 300, N'Confirmado'),
    (N'ALQUILER', NULL, 198, NULL, '2026-06-20T17:50:00', N'Efectivo', 97.50, N'Confirmado'),
    (N'ALQUILER', NULL, 198, NULL, '2026-06-24T10:30:00', N'Yape', 97.50, N'Confirmado'),
    (N'ALQUILER', NULL, 199, NULL, '2026-06-24T10:50:00', N'Tarjeta', 245, N'Confirmado'),
    (N'ALQUILER', NULL, 200, NULL, '2026-06-27T13:00:00', N'Efectivo', 195, N'Confirmado'),
    (N'ALQUILER', NULL, 201, NULL, '2026-06-29T12:40:00', N'Plin', 145, N'Confirmado'),
    (N'ALQUILER', NULL, 202, NULL, '2026-06-29T12:00:00', N'Plin', 180.50, N'Confirmado'),
    (N'ALQUILER', NULL, 203, NULL, '2026-07-02T09:10:00', N'Efectivo', 135, N'Confirmado'),
    (N'ALQUILER', NULL, 204, NULL, '2026-07-06T11:00:00', N'Tarjeta', 235.00, N'Confirmado'),
    (N'ALQUILER', NULL, 204, NULL, '2026-07-09T15:45:00', N'Yape', 235.00, N'Confirmado'),
    (N'ALQUILER', NULL, 205, NULL, '2026-07-06T16:00:00', N'Plin', 305, N'Confirmado');
GO

INSERT INTO dbo.Pago (tipoOperacion, idVenta, idAlquiler, idPenalidad, fechaPago, metodoPago, monto, estadoPago) VALUES
    (N'ALQUILER', NULL, 206, NULL, '2026-07-07T11:45:00', N'Efectivo', 195, N'Confirmado'),
    (N'ALQUILER', NULL, 207, NULL, '2026-07-09T15:45:00', N'Plin', 167.50, N'Confirmado'),
    (N'ALQUILER', NULL, 208, NULL, '2026-07-09T15:40:00', N'Yape', 61.75, N'Confirmado'),
    (N'ALQUILER', NULL, 209, NULL, '2026-07-12T12:10:00', N'Yape', 55, N'Confirmado'),
    (N'ALQUILER', NULL, 210, NULL, '2026-07-15T16:45:00', N'Tarjeta', 22.50, N'Confirmado'),
    (N'ALQUILER', NULL, 210, NULL, '2026-07-22T15:45:00', N'Transferencia', 22.50, N'Confirmado'),
    (N'ALQUILER', NULL, 211, NULL, '2026-07-20T09:40:00', N'Plin', 205, N'Confirmado'),
    (N'ALQUILER', NULL, 212, NULL, '2026-07-21T15:15:00', N'Yape', 295, N'Confirmado'),
    (N'ALQUILER', NULL, 213, NULL, '2026-07-25T10:30:00', N'Yape', 87.25, N'Confirmado'),
    (N'ALQUILER', NULL, 214, NULL, '2026-07-29T15:20:00', N'Plin', 60, N'Confirmado'),
    (N'ALQUILER', NULL, 215, NULL, '2026-08-02T11:40:00', N'Yape', 135, N'Confirmado'),
    (N'ALQUILER', NULL, 216, NULL, '2026-08-02T15:20:00', N'Tarjeta', 90.00, N'Confirmado'),
    (N'ALQUILER', NULL, 216, NULL, '2026-08-07T16:15:00', N'Plin', 90.00, N'Confirmado'),
    (N'ALQUILER', NULL, 217, NULL, '2026-08-09T08:50:00', N'Efectivo', 180, N'Confirmado'),
    (N'ALQUILER', NULL, 218, NULL, '2026-08-10T11:15:00', N'Tarjeta', 168, N'Confirmado'),
    (N'ALQUILER', NULL, 219, NULL, '2026-08-15T15:50:00', N'Transferencia', 172.25, N'Confirmado'),
    (N'ALQUILER', NULL, 220, NULL, '2026-08-19T10:00:00', N'Yape', 80, N'Confirmado'),
    (N'ALQUILER', NULL, 221, NULL, '2026-08-21T15:40:00', N'Tarjeta', 300, N'Confirmado'),
    (N'ALQUILER', NULL, 222, NULL, '2026-08-21T11:45:00', N'Tarjeta', 144.38, N'Confirmado'),
    (N'ALQUILER', NULL, 222, NULL, '2026-08-26T13:00:00', N'Tarjeta', 144.37, N'Confirmado'),
    (N'ALQUILER', NULL, 223, NULL, '2026-08-22T15:40:00', N'Tarjeta', 245, N'Confirmado'),
    (N'ALQUILER', NULL, 224, NULL, '2026-08-26T13:20:00', N'Tarjeta', 340, N'Confirmado'),
    (N'ALQUILER', NULL, 225, NULL, '2026-08-29T17:20:00', N'Transferencia', 255, N'Confirmado'),
    (N'ALQUILER', NULL, 226, NULL, '2026-09-08T11:45:00', N'Tarjeta', 150, N'Confirmado'),
    (N'ALQUILER', NULL, 227, NULL, '2026-09-13T09:00:00', N'Yape', 125, N'Confirmado'),
    (N'ALQUILER', NULL, 228, NULL, '2026-09-20T12:40:00', N'Efectivo', 92.50, N'Confirmado'),
    (N'ALQUILER', NULL, 228, NULL, '2026-09-24T16:45:00', N'Efectivo', 92.50, N'Confirmado'),
    (N'ALQUILER', NULL, 229, NULL, '2026-10-07T17:00:00', N'Efectivo', 230.75, N'Confirmado'),
    (N'ALQUILER', NULL, 230, NULL, '2026-10-08T09:40:00', N'Tarjeta', 118.75, N'Confirmado'),
    (N'ALQUILER', NULL, 231, NULL, '2026-10-09T10:30:00', N'Efectivo', 70.00, N'Confirmado'),
    (N'ALQUILER', NULL, 232, NULL, '2026-10-10T13:15:00', N'Yape', 123.50, N'Confirmado'),
    (N'ALQUILER', NULL, 233, NULL, '2026-10-11T10:50:00', N'Plin', 105.00, N'Confirmado'),
    (N'ALQUILER', NULL, 234, NULL, '2026-10-11T11:00:00', N'Transferencia', 42.25, N'Confirmado'),
    (N'ALQUILER', NULL, 235, NULL, '2026-10-12T11:15:00', N'Plin', 183.25, N'Confirmado'),
    (N'ALQUILER', NULL, 236, NULL, '2026-10-13T09:40:00', N'Tarjeta', 55.00, N'Confirmado'),
    (N'ALQUILER', NULL, 237, NULL, '2026-10-13T10:00:00', N'Plin', 40.25, N'Confirmado'),
    (N'ALQUILER', NULL, 238, NULL, '2026-10-14T09:20:00', N'Yape', 76.47, N'Confirmado'),
    (N'ALQUILER', NULL, 239, NULL, '2026-10-14T13:10:00', N'Yape', 33.07, N'Confirmado'),
    (N'ALQUILER', NULL, 240, NULL, '2026-10-15T16:20:00', N'Tarjeta', 104.65, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 1, '2024-01-31T14:15:00', N'Tarjeta', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 2, '2024-02-06T15:15:00', N'Tarjeta', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 3, '2024-02-06T15:15:00', N'Tarjeta', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 5, '2024-04-03T13:30:00', N'Efectivo', 50.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 6, '2024-04-10T11:45:00', N'Yape', 95.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 7, '2024-04-20T09:15:00', N'Efectivo', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 9, '2024-05-17T11:30:00', N'Tarjeta', 95.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 10, '2024-05-28T10:00:00', N'Tarjeta', 100.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 11, '2024-05-28T10:00:00', N'Tarjeta', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 13, '2024-06-08T11:15:00', N'Efectivo', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 14, '2024-06-08T12:30:00', N'Plin', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 15, '2024-06-11T10:15:00', N'Efectivo', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 17, '2024-06-19T14:00:00', N'Tarjeta', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 18, '2024-07-21T09:00:00', N'Plin', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 19, '2024-07-21T09:00:00', N'Plin', 95.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 21, '2024-08-03T15:00:00', N'Efectivo', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 22, '2024-08-26T12:45:00', N'Efectivo', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 23, '2024-09-07T09:00:00', N'Efectivo', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 25, '2024-10-01T14:15:00', N'Yape', 50.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 26, '2024-09-29T15:00:00', N'Transferencia', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 27, '2024-10-07T11:15:00', N'Tarjeta', 100.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 29, '2024-10-22T10:45:00', N'Efectivo', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 30, '2024-11-08T14:15:00', N'Efectivo', 75.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 31, '2024-11-13T15:15:00', N'Plin', 50.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 33, '2024-11-29T14:15:00', N'Plin', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 34, '2024-11-29T14:15:00', N'Yape', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 35, '2024-12-11T16:30:00', N'Tarjeta', 50.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 37, '2025-01-26T14:15:00', N'Yape', 95.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 38, '2025-01-25T11:15:00', N'Tarjeta', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 39, '2025-02-14T09:00:00', N'Efectivo', 50.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 41, '2025-02-14T15:30:00', N'Yape', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 42, '2025-03-18T09:30:00', N'Yape', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 43, '2025-04-17T12:45:00', N'Yape', 75.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 45, '2025-04-22T12:00:00', N'Plin', 95.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 46, '2025-05-08T10:15:00', N'Tarjeta', 50.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 47, '2025-05-09T15:15:00', N'Yape', 125.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 49, '2025-07-10T10:45:00', N'Plin', 100.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 50, '2025-07-06T09:00:00', N'Tarjeta', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 51, '2025-07-17T14:30:00', N'Tarjeta', 125.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 53, '2025-08-08T13:00:00', N'Transferencia', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 54, '2025-08-08T13:00:00', N'Transferencia', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 55, '2025-08-26T09:45:00', N'Plin', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 57, '2025-08-24T10:30:00', N'Tarjeta', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 58, '2025-09-04T13:00:00', N'Transferencia', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 59, '2025-09-09T15:45:00', N'Tarjeta', 125.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 61, '2025-09-22T15:30:00', N'Yape', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 62, '2025-09-21T11:30:00', N'Yape', 95.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 63, '2025-09-27T14:15:00', N'Plin', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 65, '2025-10-11T11:00:00', N'Plin', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 66, '2025-10-12T11:00:00', N'Efectivo', 125.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 67, '2025-10-17T13:45:00', N'Tarjeta', 75.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 69, '2025-10-18T13:30:00', N'Yape', 75.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 70, '2025-10-28T12:45:00', N'Efectivo', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 71, '2025-11-26T09:45:00', N'Efectivo', 50.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 73, '2025-12-03T16:15:00', N'Yape', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 74, '2025-12-03T16:15:00', N'Efectivo', 95.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 75, '2025-12-03T10:15:00', N'Plin', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 77, '2025-12-11T14:00:00', N'Yape', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 78, '2026-02-02T10:45:00', N'Tarjeta', 125.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 79, '2026-02-09T10:00:00', N'Transferencia', 125.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 81, '2026-02-20T13:00:00', N'Efectivo', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 82, '2026-03-05T13:45:00', N'Efectivo', 75.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 83, '2026-03-09T12:30:00', N'Plin', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 85, '2026-05-06T12:30:00', N'Transferencia', 125.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 86, '2026-05-18T14:45:00', N'Yape', 95.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 87, '2026-05-29T09:00:00', N'Yape', 75.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 89, '2026-06-28T15:45:00', N'Efectivo', 75.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 90, '2026-07-03T13:00:00', N'Tarjeta', 25.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 91, '2026-07-03T13:00:00', N'Yape', 95.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 93, '2026-07-16T14:15:00', N'Plin', 95.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 94, '2026-07-15T11:45:00', N'Transferencia', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 95, '2026-07-22T15:45:00', N'Tarjeta', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 97, '2026-07-31T13:15:00', N'Transferencia', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 98, '2026-08-07T16:15:00', N'Efectivo', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 99, '2026-08-28T14:30:00', N'Plin', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 101, '2026-09-11T16:15:00', N'Yape', 45.00, N'Confirmado'),
    (N'PENALIDAD', NULL, NULL, 102, '2026-10-13T11:15:00', N'Plin', 25.00, N'Confirmado');
GO


-- Calendario explícito para el modelo estrella (incluye fechas programadas de fin de 2026).
;WITH N AS (
 SELECT TOP (1096) ROW_NUMBER() OVER(ORDER BY a.object_id,b.object_id)-1 AS n
 FROM sys.all_objects a CROSS JOIN sys.all_objects b
), D AS (
 SELECT DATEADD(DAY,n,CONVERT(date,'20240101',112)) AS fecha FROM N
), F AS (
 SELECT fecha, ((DATEDIFF(DAY,CONVERT(date,'19000101',112),fecha)%7)+1) AS semana FROM D
)
INSERT INTO dbo.DimFecha (FechaKey,Fecha,Anio,Trimestre,MesNumero,MesNombre,AnioMes,DiaMes,DiaSemanaNumero,DiaSemanaNombre,EsFinSemana)
SELECT YEAR(fecha)*10000+MONTH(fecha)*100+DAY(fecha),fecha,YEAR(fecha),DATEPART(QUARTER,fecha),MONTH(fecha),
 CHOOSE(MONTH(fecha),N'Enero',N'Febrero',N'Marzo',N'Abril',N'Mayo',N'Junio',N'Julio',N'Agosto',N'Setiembre',N'Octubre',N'Noviembre',N'Diciembre'),
 CONVERT(CHAR(7),fecha,120),DAY(fecha),semana,
 CHOOSE(semana,N'Lunes',N'Martes',N'Miércoles',N'Jueves',N'Viernes',N'Sábado',N'Domingo'),
 CASE WHEN semana IN (6,7) THEN 1 ELSE 0 END
FROM F WHERE fecha<='2026-12-31';
GO

-- Validaciones financieras (THROW detiene la ejecución si se rompe la coherencia).
IF EXISTS (
 SELECT 1 FROM dbo.Venta v OUTER APPLY (SELECT SUM(d.subtotal) t FROM dbo.DetalleVenta d WHERE d.idVenta=v.idVenta) x
 WHERE ABS(v.total-ISNULL(x.t,0))>0.001
) THROW 51001, 'Total de venta distinto a suma de sus detalles.', 1;
IF EXISTS (
 SELECT 1 FROM dbo.Alquiler a OUTER APPLY (SELECT SUM(d.subtotal) t FROM dbo.DetalleAlquiler d WHERE d.idAlquiler=a.idAlquiler) x
 WHERE ABS(a.total-ISNULL(x.t,0))>0.001
) THROW 51002, 'Total de alquiler distinto a suma de sus detalles.', 1;
IF EXISTS (
 SELECT 1 FROM dbo.Venta v OUTER APPLY (SELECT SUM(p.monto) t FROM dbo.Pago p WHERE p.tipoOperacion=N'VENTA' AND p.idVenta=v.idVenta AND p.estadoPago=N'Confirmado') x
 WHERE ISNULL(x.t,0)>v.total
) THROW 51003, 'Pago de venta mayor al total de venta.', 1;
IF EXISTS (
 SELECT 1 FROM dbo.Alquiler a OUTER APPLY (SELECT SUM(p.monto) t FROM dbo.Pago p WHERE p.tipoOperacion=N'ALQUILER' AND p.idAlquiler=a.idAlquiler AND p.estadoPago=N'Confirmado') x
 WHERE ISNULL(x.t,0)>a.total
) THROW 51004, 'Pago de alquiler mayor al total de alquiler.', 1;
IF EXISTS (
 SELECT 1 FROM dbo.Penalidad e OUTER APPLY (SELECT SUM(p.monto) t FROM dbo.Pago p WHERE p.tipoOperacion=N'PENALIDAD' AND p.idPenalidad=e.idPenalidad AND p.estadoPago=N'Confirmado') x
 WHERE ISNULL(x.t,0)>e.monto
) THROW 51005, 'Pago de penalidad mayor a su monto.', 1;
IF EXISTS (
 SELECT 1 FROM dbo.Alquiler a JOIN dbo.Devolucion d ON a.idAlquiler=d.idAlquiler
 WHERE a.fechaDevolucionReal<>d.fechaDevolucion OR a.estado<>N'Devuelto'
) THROW 51006, 'Devolucion inconsistente con alquiler.', 1;
GO


-- VISTAS BI. Cada tabla de hechos tiene un grano específico; no combinar
-- detalles con pagos/penalidades en una sola consulta para evitar duplicaciones.
CREATE VIEW bi.DimCalendario AS
 SELECT FechaKey,Fecha,Anio,Trimestre,MesNumero,MesNombre,AnioMes,DiaMes,DiaSemanaNumero,DiaSemanaNombre,EsFinSemana
 FROM dbo.DimFecha;
GO
CREATE VIEW bi.DimCategoria AS
 SELECT idCategoria AS CategoriaKey,nombreCategoria AS Categoria,descripcion AS DescripcionCategoria
 FROM dbo.Categoria;
GO
CREATE VIEW bi.DimCliente AS
 SELECT idCliente AS ClienteKey, dni AS DNI,nombres AS Nombres,apellidos AS Apellidos,
 CONCAT(nombres,N' ',apellidos) AS Cliente,telefono AS Telefono,correo AS Correo,
 direccion AS Direccion,distrito AS Distrito,CONVERT(date,fechaRegistro) AS FechaRegistro
 FROM dbo.Cliente;
GO
CREATE VIEW bi.DimTrabajador AS
 SELECT idTrabajador AS TrabajadorKey, CONCAT(nombres,N' ',apellidos) AS Trabajador,
 cargo AS Cargo,estado AS EstadoTrabajador FROM dbo.Trabajador;
GO
CREATE VIEW bi.DimArticulo AS
 SELECT a.idArticulo AS ArticuloKey,a.idCategoria AS CategoriaKey,a.codigo AS Codigo,
 a.nombre AS Articulo,a.talla AS Talla,a.color AS Color,c.nombreCategoria AS Categoria,
 a.precioVenta AS PrecioListaVenta, a.precioAlquiler AS PrecioListaAlquiler,
 a.stock AS StockActual,a.stockMinimo AS StockMinimo,a.estado AS EstadoArticulo
 FROM dbo.Articulo a JOIN dbo.Categoria c ON c.idCategoria=a.idCategoria;
GO
-- GRANO: 1 fila = 1 artículo dentro de una venta.
CREATE VIEW bi.FactVenta AS
 SELECT d.idDetalleVenta AS DetalleVentaKey,v.idVenta AS VentaID,
 v.idCliente AS ClienteKey,v.idTrabajador AS TrabajadorKey,d.idArticulo AS ArticuloKey,
 YEAR(v.fechaVenta)*10000+MONTH(v.fechaVenta)*100+DAY(v.fechaVenta) AS FechaVentaKey,
 v.fechaVenta AS FechaVentaHora,v.tipoComprobante AS Comprobante,v.canalVenta AS CanalVenta,v.estado AS EstadoVenta,
 d.cantidad AS Cantidad,d.precioUnitario AS PrecioUnitario,
 d.subtotal AS ImporteVenta,d.costoUnitario*d.cantidad AS CostoMercaderia,
 d.subtotal-d.costoUnitario*d.cantidad AS MargenBrutoVenta
 FROM dbo.DetalleVenta d JOIN dbo.Venta v ON v.idVenta=d.idVenta;
GO
-- GRANO: 1 fila = 1 artículo dentro de un contrato de alquiler.
-- El importe del contrato (total) no se repite: se usa subtotal del detalle.
CREATE VIEW bi.FactAlquiler AS
 SELECT d.idDetalleAlquiler AS DetalleAlquilerKey,a.idAlquiler AS AlquilerID,
 a.idCliente AS ClienteKey,a.idTrabajador AS TrabajadorKey,d.idArticulo AS ArticuloKey,
 YEAR(a.fechaAlquiler)*10000+MONTH(a.fechaAlquiler)*100+DAY(a.fechaAlquiler) AS FechaAlquilerKey,
 CASE WHEN a.fechaEntrega IS NULL THEN NULL ELSE YEAR(a.fechaEntrega)*10000+MONTH(a.fechaEntrega)*100+DAY(a.fechaEntrega) END AS FechaEntregaKey,
 YEAR(a.fechaDevolucionProgramada)*10000+MONTH(a.fechaDevolucionProgramada)*100+DAY(a.fechaDevolucionProgramada) AS FechaDevolucionProgramadaKey,
 CASE WHEN a.fechaDevolucionReal IS NULL THEN NULL ELSE YEAR(a.fechaDevolucionReal)*10000+MONTH(a.fechaDevolucionReal)*100+DAY(a.fechaDevolucionReal) END AS FechaDevolucionRealKey,
 a.fechaAlquiler AS FechaAlquilerHora,a.fechaEntrega AS FechaEntregaHora,
 a.fechaDevolucionProgramada AS FechaDevolucionProgramadaHora,
 a.fechaDevolucionReal AS FechaDevolucionRealHora,
 a.estado AS EstadoAlquiler,a.tipoEvento AS TipoEvento,a.canalReserva AS CanalReserva,
 d.cantidad AS Cantidad,d.precioUnitario AS PrecioUnitario,
 d.subtotal AS ImporteAlquiler,
 CASE WHEN a.fechaDevolucionReal IS NOT NULL
 THEN CASE WHEN DATEDIFF(DAY,CONVERT(date,a.fechaDevolucionProgramada),CONVERT(date,a.fechaDevolucionReal))>0
 THEN DATEDIFF(DAY,CONVERT(date,a.fechaDevolucionProgramada),CONVERT(date,a.fechaDevolucionReal)) ELSE 0 END
 ELSE NULL END AS DiasRetraso,
 CASE WHEN a.fechaDevolucionReal IS NOT NULL
 THEN CASE WHEN CONVERT(date,a.fechaDevolucionReal)>CONVERT(date,a.fechaDevolucionProgramada) THEN 0 ELSE 1 END
 ELSE NULL END AS FuePuntual
 FROM dbo.DetalleAlquiler d JOIN dbo.Alquiler a ON a.idAlquiler=d.idAlquiler;
GO
-- GRANO: 1 fila = 1 cargo por mora, limpieza, reparación o reposición.
CREATE VIEW bi.FactPenalidad AS
 SELECT p.idPenalidad AS PenalidadID,p.idDevolucion AS DevolucionID,
 de.idAlquiler AS AlquilerID,a.idCliente AS ClienteKey,a.idTrabajador AS TrabajadorKey,
 p.idArticulo AS ArticuloKey,
 YEAR(p.fechaRegistro)*10000+MONTH(p.fechaRegistro)*100+DAY(p.fechaRegistro) AS FechaPenalidadKey,
 p.fechaRegistro AS FechaPenalidadHora,p.tipoPenalidad AS TipoPenalidad,
 p.descripcion AS MotivoPenalidad,p.diasRetraso AS DiasRetrasoPenalidad,
 p.monto AS MontoPenalidad,p.estadoPenalidad AS EstadoPenalidad
 FROM dbo.Penalidad p JOIN dbo.Devolucion de ON de.idDevolucion=p.idDevolucion
 JOIN dbo.Alquiler a ON a.idAlquiler=de.idAlquiler;
GO
-- GRANO: 1 fila = 1 gasto operativo.
CREATE VIEW bi.FactGasto AS
 SELECT idGasto AS GastoID,
 YEAR(fechaGasto)*10000+MONTH(fechaGasto)*100+DAY(fechaGasto) AS FechaGastoKey,
 fechaGasto AS FechaGastoHora,tipoGasto AS TipoGasto,
 descripcion AS DescripcionGasto,monto AS MontoGasto,
 idVenta AS VentaID,idAlquiler AS AlquilerID FROM dbo.Gasto;
GO
-- GRANO: 1 fila = 1 deuda individual (venta, alquiler o penalidad).
-- Permite evaluar saldos sin mezclar las distintas fechas de cobro.
CREATE VIEW bi.FactCobranza AS
WITH C AS (
 SELECT tipoOperacion, idVenta, idAlquiler, idPenalidad, SUM(monto) AS ImporteCobrado
 FROM dbo.Pago WHERE estadoPago=N'Confirmado'
 GROUP BY tipoOperacion,idVenta,idAlquiler,idPenalidad
)
SELECT N'VENTA' AS TipoOperacion, v.idVenta AS OperacionID, v.idCliente AS ClienteKey,
 v.idTrabajador AS TrabajadorKey,
 YEAR(v.fechaVenta)*10000+MONTH(v.fechaVenta)*100+DAY(v.fechaVenta) AS FechaEmisionKey,
 v.total AS ImporteFacturado,ISNULL(c.ImporteCobrado,0) AS ImporteCobrado,
 v.total-ISNULL(c.ImporteCobrado,0) AS SaldoPendiente
FROM dbo.Venta v LEFT JOIN C c ON c.tipoOperacion=N'VENTA' AND c.idVenta=v.idVenta
UNION ALL
SELECT N'ALQUILER',a.idAlquiler,a.idCliente,a.idTrabajador,
 YEAR(a.fechaAlquiler)*10000+MONTH(a.fechaAlquiler)*100+DAY(a.fechaAlquiler),
 a.total,ISNULL(c.ImporteCobrado,0),a.total-ISNULL(c.ImporteCobrado,0)
FROM dbo.Alquiler a LEFT JOIN C c ON c.tipoOperacion=N'ALQUILER' AND c.idAlquiler=a.idAlquiler
UNION ALL
SELECT N'PENALIDAD',pe.idPenalidad,a.idCliente,a.idTrabajador,
 YEAR(pe.fechaRegistro)*10000+MONTH(pe.fechaRegistro)*100+DAY(pe.fechaRegistro),
 pe.monto,ISNULL(c.ImporteCobrado,0),pe.monto-ISNULL(c.ImporteCobrado,0)
FROM dbo.Penalidad pe
JOIN dbo.Devolucion de ON de.idDevolucion=pe.idDevolucion
JOIN dbo.Alquiler a ON a.idAlquiler=de.idAlquiler
LEFT JOIN C c ON c.tipoOperacion=N'PENALIDAD' AND c.idPenalidad=pe.idPenalidad;
GO
-- GRANO: 1 fila = 1 movimiento de cobro (no un ingreso duplicado).
CREATE VIEW bi.FactPago AS
 SELECT p.idPago AS PagoID,
 YEAR(p.fechaPago)*10000+MONTH(p.fechaPago)*100+DAY(p.fechaPago) AS FechaPagoKey,
 p.fechaPago AS FechaPagoHora,p.tipoOperacion AS TipoOperacion,
 p.idVenta AS VentaID,p.idAlquiler AS AlquilerID,p.idPenalidad AS PenalidadID,
 COALESCE(v.idCliente,a.idCliente,ax.idCliente) AS ClienteKey,
 COALESCE(v.idTrabajador,a.idTrabajador,ax.idTrabajador) AS TrabajadorKey,
 p.metodoPago AS MetodoPago,p.monto AS MontoPago,p.estadoPago AS EstadoPago
 FROM dbo.Pago p
 LEFT JOIN dbo.Venta v ON p.idVenta=v.idVenta
 LEFT JOIN dbo.Alquiler a ON p.idAlquiler=a.idAlquiler
 LEFT JOIN dbo.Penalidad pe ON p.idPenalidad=pe.idPenalidad
 LEFT JOIN dbo.Devolucion de ON pe.idDevolucion=de.idDevolucion
 LEFT JOIN dbo.Alquiler ax ON de.idAlquiler=ax.idAlquiler;
GO
-- RECUENTOS Y CONTROL BASICO
SELECT N'Clientes' AS Tabla,COUNT(*) AS Registros FROM dbo.Cliente
UNION ALL SELECT N'Articulos',COUNT(*) FROM dbo.Articulo
UNION ALL SELECT N'Ventas',COUNT(*) FROM dbo.Venta
UNION ALL SELECT N'Detalle ventas',COUNT(*) FROM dbo.DetalleVenta
UNION ALL SELECT N'Alquileres',COUNT(*) FROM dbo.Alquiler
UNION ALL SELECT N'Detalle alquileres',COUNT(*) FROM dbo.DetalleAlquiler
UNION ALL SELECT N'Devoluciones',COUNT(*) FROM dbo.Devolucion
UNION ALL SELECT N'Penalidades',COUNT(*) FROM dbo.Penalidad
UNION ALL SELECT N'Pagos',COUNT(*) FROM dbo.Pago
UNION ALL SELECT N'Gastos',COUNT(*) FROM dbo.Gasto;
GO

-- ============================================================================
-- 1. TABLA DE AUDITORÍA
-- ============================================================================
DROP TABLE IF EXISTS dbo.AuditoriaCambios;
GO

CREATE TABLE dbo.AuditoriaCambios (
    idAuditoria   BIGINT IDENTITY(1,1) PRIMARY KEY,
    tablaAfectada SYSNAME NOT NULL,
    tipoOperacion VARCHAR(10) NOT NULL CHECK (tipoOperacion IN ('INSERT', 'UPDATE', 'DELETE')),
    idRegistro    NVARCHAR(50) NOT NULL,
    datosAnteriores NVARCHAR(MAX) NULL,
    datosNuevos     NVARCHAR(MAX) NULL,
    usuarioSQL    SYSNAME NOT NULL DEFAULT (SUSER_SNAME()),
    fechaCambio   DATETIME2(0) NOT NULL DEFAULT (SYSDATETIME())
);
GO

-- ============================================================================
-- 2. TRIGGERS: REGLAS DE NEGOCIO Y AUDITORÍA
-- ============================================================================

-- 2.1 Auditoría y regla automática de estado de stock en dbo.Articulo
CREATE OR ALTER TRIGGER dbo.trg_Articulo_AuditoriaYStock
ON dbo.Articulo
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @operacion VARCHAR(10) = CASE
        WHEN EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted) THEN 'UPDATE'
        WHEN EXISTS (SELECT 1 FROM inserted) THEN 'INSERT'
        ELSE 'DELETE'
    END;

    -- Regla de negocio: si el artículo está Activo y su stock <= stockMinimo, cambiar a 'Stock bajo'
    -- (Si se repone por encima de stockMinimo y estaba en 'Stock bajo', volver a 'Activo')
    IF @operacion IN ('INSERT', 'UPDATE')
    BEGIN
        UPDATE a
        SET a.estado = CASE
            WHEN a.estado = N'Activo' AND a.stock <= a.stockMinimo THEN N'Stock bajo'
            WHEN a.estado = N'Stock bajo' AND a.stock > a.stockMinimo THEN N'Activo'
            ELSE a.estado
        END
        FROM dbo.Articulo a
        INNER JOIN inserted i ON a.idArticulo = i.idArticulo;
    END;

    -- Registrar auditoría con valores previos y nuevos (JSON)
    INSERT INTO dbo.AuditoriaCambios (tablaAfectada, tipoOperacion, idRegistro, datosAnteriores, datosNuevos)
    SELECT
        N'dbo.Articulo',
        @operacion,
        CAST(COALESCE(i.idArticulo, d.idArticulo) AS NVARCHAR(50)),
        (SELECT d.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
        (SELECT a.* FROM dbo.Articulo a WHERE a.idArticulo = i.idArticulo FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM inserted i
    FULL OUTER JOIN deleted d ON i.idArticulo = d.idArticulo;
END;
GO

-- 2.2 Recalcular total de Venta y auditar cambios en dbo.DetalleVenta
CREATE OR ALTER TRIGGER dbo.trg_DetalleVenta_TotalYAuditoria
ON dbo.DetalleVenta
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @operacion VARCHAR(10) = CASE
        WHEN EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted) THEN 'UPDATE'
        WHEN EXISTS (SELECT 1 FROM inserted) THEN 'INSERT'
        ELSE 'DELETE'
    END;

    -- Recalcular total en dbo.Venta (suma de subtotales de sus detalles)
    ;WITH VentasAfectadas AS (
        SELECT DISTINCT idVenta FROM inserted
        UNION
        SELECT DISTINCT idVenta FROM deleted
    ),
    TotalesCalculados AS (
        SELECT
            va.idVenta,
            COALESCE(SUM(dv.subtotal), 0) AS nuevoTotal
        FROM VentasAfectadas va
        LEFT JOIN dbo.DetalleVenta dv ON dv.idVenta = va.idVenta
        GROUP BY va.idVenta
    )
    UPDATE v
    SET v.total = tc.nuevoTotal
    FROM dbo.Venta v
    INNER JOIN TotalesCalculados tc ON v.idVenta = tc.idVenta;

    -- Auditoría del detalle
    INSERT INTO dbo.AuditoriaCambios (tablaAfectada, tipoOperacion, idRegistro, datosAnteriores, datosNuevos)
    SELECT
        N'dbo.DetalleVenta',
        @operacion,
        CAST(COALESCE(i.idDetalleVenta, d.idDetalleVenta) AS NVARCHAR(50)),
        (SELECT d.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
        (SELECT i.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM inserted i
    FULL OUTER JOIN deleted d ON i.idDetalleVenta = d.idDetalleVenta;
END;
GO

-- 2.3 Recalcular total de Alquiler y auditar cambios en dbo.DetalleAlquiler
CREATE OR ALTER TRIGGER dbo.trg_DetalleAlquiler_TotalYAuditoria
ON dbo.DetalleAlquiler
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @operacion VARCHAR(10) = CASE
        WHEN EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted) THEN 'UPDATE'
        WHEN EXISTS (SELECT 1 FROM inserted) THEN 'INSERT'
        ELSE 'DELETE'
    END;

    ;WITH AlquileresAfectados AS (
        SELECT DISTINCT idAlquiler FROM inserted
        UNION
        SELECT DISTINCT idAlquiler FROM deleted
    ),
    TotalesCalculados AS (
        SELECT
            aa.idAlquiler,
            COALESCE(SUM(da.subtotal), 0) AS nuevoTotal
        FROM AlquileresAfectados aa
        LEFT JOIN dbo.DetalleAlquiler da ON da.idAlquiler = aa.idAlquiler
        GROUP BY aa.idAlquiler
    )
    UPDATE a
    SET a.total = tc.nuevoTotal
    FROM dbo.Alquiler a
    INNER JOIN TotalesCalculados tc ON a.idAlquiler = tc.idAlquiler;

    INSERT INTO dbo.AuditoriaCambios (tablaAfectada, tipoOperacion, idRegistro, datosAnteriores, datosNuevos)
    SELECT
        N'dbo.DetalleAlquiler',
        @operacion,
        CAST(COALESCE(i.idDetalleAlquiler, d.idDetalleAlquiler) AS NVARCHAR(50)),
        (SELECT d.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
        (SELECT i.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM inserted i
    FULL OUTER JOIN deleted d ON i.idDetalleAlquiler = d.idDetalleAlquiler;
END;
GO

-- 2.4 Auditoría de cambios de estado o monto en dbo.Penalidad
CREATE OR ALTER TRIGGER dbo.trg_Penalidad_Auditoria
ON dbo.Penalidad
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @operacion VARCHAR(10) = CASE
        WHEN EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted) THEN 'UPDATE'
        WHEN EXISTS (SELECT 1 FROM inserted) THEN 'INSERT'
        ELSE 'DELETE'
    END;

    INSERT INTO dbo.AuditoriaCambios (tablaAfectada, tipoOperacion, idRegistro, datosAnteriores, datosNuevos)
    SELECT
        N'dbo.Penalidad',
        @operacion,
        CAST(COALESCE(i.idPenalidad, d.idPenalidad) AS NVARCHAR(50)),
        (SELECT d.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
        (SELECT i.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM inserted i
    FULL OUTER JOIN deleted d ON i.idPenalidad = d.idPenalidad;
END;
GO

-- ============================================================================
-- 3. OPERACIONES DE VARIAS ETAPAS: TRY...CATCH + TRANSACCIONES
-- ============================================================================

-- Tipo de tabla para pasar múltiples artículos en una venta
IF TYPE_ID(N'dbo.TVP_ItemVenta') IS NULL
BEGIN
    CREATE TYPE dbo.TVP_ItemVenta AS TABLE (
        idArticulo     INT NOT NULL,
        cantidad       INT NOT NULL CHECK (cantidad > 0),
        precioUnitario DECIMAL(12,2) NOT NULL CHECK (precioUnitario >= 0)
    );
END;
GO

-- 3.1 Registrar Venta completa (Cabecera + Detalles + Descuento Stock + Pago)
CREATE OR ALTER PROCEDURE dbo.usp_RegistrarVentaCompleta
    @idCliente       INT,
    @idTrabajador    INT,
    @fechaVenta      DATETIME2(0),
    @tipoComprobante NVARCHAR(30),
    @canalVenta      NVARCHAR(30),
    @metodoPago      NVARCHAR(30),
    @montoPagado     DECIMAL(12,2),
    @items           dbo.TVP_ItemVenta READONLY,
    @idVentaGenerada INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @totalCalculado DECIMAL(12,2) = 0;

    BEGIN TRY
        -- Validaciones previas antes de abrir transacción
        IF NOT EXISTS (SELECT 1 FROM dbo.Cliente WHERE idCliente = @idCliente)
            THROW 51001, 'El cliente especificado no existe.', 1;

        IF NOT EXISTS (SELECT 1 FROM dbo.Trabajador WHERE idTrabajador = @idTrabajador AND estado = N'Activo')
            THROW 51002, 'El trabajador no existe o no está activo.', 1;

        IF NOT EXISTS (SELECT 1 FROM @items)
            THROW 51003, 'Debe incluir al menos un artículo en la venta.', 1;

        -- Verificar stock suficiente para todos los artículos
        IF EXISTS (
            SELECT 1
            FROM @items it
            INNER JOIN dbo.Articulo a ON a.idArticulo = it.idArticulo
            WHERE a.stock < it.cantidad
        )
            THROW 51004, 'Stock insuficiente para uno o más artículos solicitados.', 1;

        SELECT @totalCalculado = SUM(CAST(cantidad * precioUnitario AS DECIMAL(12,2)))
        FROM @items;

        IF @montoPagado <= 0 OR @montoPagado > @totalCalculado
            THROW 51005, 'El monto pagado debe ser mayor que 0 y no exceder el total de la venta.', 1;

        BEGIN TRANSACTION;

            -- Etapa 1: Insertar cabecera de Venta
            INSERT INTO dbo.Venta (
                idCliente, idTrabajador, fechaVenta, tipoComprobante, canalVenta, estado, total
            )
            VALUES (
                @idCliente,
                @idTrabajador,
                @fechaVenta,
                @tipoComprobante,
                @canalVenta,
                CASE WHEN @montoPagado = @totalCalculado THEN N'Pagada' ELSE N'Parcial' END,
                0.00 -- Será recalculado por trg_DetalleVenta_TotalYAuditoria
            );

            SET @idVentaGenerada = SCOPE_IDENTITY();

            -- Etapa 2: Insertar detalles de venta tomando costoUnitario actual de Articulo
            INSERT INTO dbo.DetalleVenta (
                idVenta, idArticulo, cantidad, precioUnitario, costoUnitario, subtotal
            )
            SELECT
                @idVentaGenerada,
                it.idArticulo,
                it.cantidad,
                it.precioUnitario,
                a.costoCompra,
                CAST(it.cantidad * it.precioUnitario AS DECIMAL(12,2))
            FROM @items it
            INNER JOIN dbo.Articulo a ON a.idArticulo = it.idArticulo;

            -- Etapa 3: Descontar stock (dispara trg_Articulo_AuditoriaYStock)
            UPDATE a
            SET a.stock = a.stock - it.cantidad
            FROM dbo.Articulo a
            INNER JOIN @items it ON a.idArticulo = it.idArticulo;

            -- Etapa 4: Registrar pago asociado a la venta
            INSERT INTO dbo.Pago (
                tipoOperacion, idVenta, idAlquiler, idPenalidad, fechaPago, metodoPago, monto, estadoPago
            )
            VALUES (
                N'VENTA', @idVentaGenerada, NULL, NULL, @fechaVenta, @metodoPago, @montoPagado, N'Confirmado'
            );

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        THROW;
    END CATCH;
END;
GO

-- 3.2 Registrar Devolución de Alquiler + Penalidades automáticas (Mora / Daño)
CREATE OR ALTER PROCEDURE dbo.usp_RegistrarDevolucionAlquiler
    @idAlquiler        INT,
    @fechaDevolucion   DATETIME2(0),
    @estadoArticulo    NVARCHAR(40), -- Ej: N'Bueno', N'Manchado', N'Rasgado', N'Dañado'
    @idArticuloDanado  INT = NULL,
    @observaciones     NVARCHAR(250) = NULL,
    @idDevolucionNueva INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @fechaProg      DATETIME2(0);
    DECLARE @fechaEntrega   DATETIME2(0);
    DECLARE @diasRetraso    INT = 0;
    DECLARE @montoMora      DECIMAL(12,2) = 0;
    DECLARE @montoDanio     DECIMAL(12,2) = 0;
    DECLARE @tipoPenalDanio NVARCHAR(40) = NULL;
    DECLARE @descDanio      NVARCHAR(250) = NULL;

    BEGIN TRY
        SELECT
            @fechaProg = fechaDevolucionProgramada,
            @fechaEntrega = fechaEntrega
        FROM dbo.Alquiler
        WHERE idAlquiler = @idAlquiler;

        IF @fechaProg IS NULL
            THROW 52001, 'El alquiler indicado no existe.', 1;

        IF EXISTS (SELECT 1 FROM dbo.Devolucion WHERE idAlquiler = @idAlquiler)
            THROW 52002, 'Este alquiler ya cuenta con una devolución registrada.', 1;

        IF @fechaEntrega IS NOT NULL AND @fechaDevolucion < @fechaEntrega
            THROW 52003, 'La fecha de devolución no puede ser anterior a la fecha de entrega.', 1;

        -- Calcular días de mora (S/ 25 por día de retraso según patrón de datos)
        IF @fechaDevolucion > @fechaProg
        BEGIN
            SET @diasRetraso = DATEDIFF(DAY, @fechaProg, @fechaDevolucion);
            IF @diasRetraso < 1 SET @diasRetraso = 1;
            SET @montoMora = CAST(@diasRetraso * 25.00 AS DECIMAL(12,2));
        END;

        -- Evaluar daño si aplica
        IF @estadoArticulo IN (N'Manchado', N'Rasgado', N'Dañado')
        BEGIN
            IF @idArticuloDanado IS NULL
                THROW 52004, 'Debe indicar idArticuloDanado cuando el artículo presenta incidencia.', 1;

            IF NOT EXISTS (
                SELECT 1 FROM dbo.DetalleAlquiler
                WHERE idAlquiler = @idAlquiler AND idArticulo = @idArticuloDanado
            )
                THROW 52005, 'El artículo indicado no pertenece a este alquiler.', 1;

            IF @estadoArticulo = N'Manchado'
            BEGIN
                SET @tipoPenalDanio = N'Limpieza';
                SET @montoDanio     = 45.00;
                SET @descDanio      = N'Limpieza especializada por manchas';
            END
            ELSE IF @estadoArticulo = N'Rasgado'
            BEGIN
                SET @tipoPenalDanio = N'Reparación';
                SET @montoDanio     = 95.00;
                SET @descDanio      = N'Reparación por rasgadura de tela';
            END
            ELSE IF @estadoArticulo = N'Dañado'
            BEGIN
                SET @tipoPenalDanio = N'Reparación';
                SET @montoDanio     = 125.00;
                SET @descDanio      = N'Reparación de costura o cierre';
            END;
        END;

        BEGIN TRANSACTION;

            -- Etapa 1: Insertar Devolución
            INSERT INTO dbo.Devolucion (idAlquiler, fechaDevolucion, estadoArticulo, observaciones)
            VALUES (
                @idAlquiler,
                @fechaDevolucion,
                @estadoArticulo,
                COALESCE(@observaciones, N'Devolución procesada mediante procedimiento')
            );

            SET @idDevolucionNueva = SCOPE_IDENTITY();

            -- Etapa 2: Insertar penalidad por mora si hubo retraso
            IF @diasRetraso > 0
            BEGIN
                INSERT INTO dbo.Penalidad (
                    idDevolucion, idArticulo, tipoPenalidad, descripcion, diasRetraso, monto, fechaRegistro, estadoPenalidad
                )
                VALUES (
                    @idDevolucionNueva,
                    NULL,
                    N'Mora',
                    CONCAT(N'Devolución con ', @diasRetraso, N' día(s) de atraso; S/ 25 por día'),
                    @diasRetraso,
                    @montoMora,
                    @fechaDevolucion,
                    N'Pendiente'
                );
            END;

            -- Etapa 3: Insertar penalidad por daño si aplica
            IF @tipoPenalDanio IS NOT NULL
            BEGIN
                INSERT INTO dbo.Penalidad (
                    idDevolucion, idArticulo, tipoPenalidad, descripcion, diasRetraso, monto, fechaRegistro, estadoPenalidad
                )
                VALUES (
                    @idDevolucionNueva,
                    @idArticuloDanado,
                    @tipoPenalDanio,
                    @descDanio,
                    0,
                    @montoDanio,
                    @fechaDevolucion,
                    N'Pendiente'
                );
            END;

            -- Etapa 4: Actualizar estado y fechaDevolucionReal en dbo.Alquiler
            UPDATE dbo.Alquiler
            SET
                fechaDevolucionReal = @fechaDevolucion,
                estado = N'Devuelto',
                observacion = CONCAT(
                    CASE WHEN @diasRetraso > 0 THEN N'Devolución registrada: fuera de plazo' ELSE N'Devolución registrada: dentro del plazo' END,
                    CASE WHEN @tipoPenalDanio IS NOT NULL THEN CONCAT(N'; incidencia por ', LOWER(@estadoArticulo)) ELSE N'; sin daños' END
                )
            WHERE idAlquiler = @idAlquiler;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        THROW;
    END CATCH;
END;
GO

-- A) Probar venta transaccional exitosa
DECLARE @itemsOk dbo.TVP_ItemVenta;
INSERT INTO @itemsOk (idArticulo, cantidad, precioUnitario) VALUES (29, 1, 49.00);

DECLARE @nuevaVenta INT;
EXEC dbo.usp_RegistrarVentaCompleta
    @idCliente = 1,
    @idTrabajador = 2,
    @fechaVenta = '2026-10-15T10:30:00',
    @tipoComprobante = N'Boleta',
    @canalVenta = N'Tienda física',
    @metodoPago = N'Yape',
    @montoPagado = 49.00,
    @items = @itemsOk,
    @idVentaGenerada = @nuevaVenta OUTPUT;

SELECT @nuevaVenta AS IdVentaGenerada;

-- B) Probar ROLLBACK ante falta de stock
DECLARE @itemsSinStock dbo.TVP_ItemVenta;
INSERT INTO @itemsSinStock (idArticulo, cantidad, precioUnitario) VALUES (1, 9999, 460.00);

DECLARE @ventaFallida INT;
BEGIN TRY
    EXEC dbo.usp_RegistrarVentaCompleta
        @idCliente = 1,
        @idTrabajador = 2,
        @fechaVenta = '2026-10-15T11:00:00',
        @tipoComprobante = N'Boleta',
        @canalVenta = N'Tienda física',
        @metodoPago = N'Efectivo',
        @montoPagado = 100.00,
        @items = @itemsSinStock,
        @idVentaGenerada = @ventaFallida OUTPUT;
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER() AS ErrorNum, ERROR_MESSAGE() AS MensajeError;
END CATCH;

-- C) Consultar registros de auditoría generados
SELECT TOP 20 *
FROM dbo.AuditoriaCambios
ORDER BY idAuditoria DESC;